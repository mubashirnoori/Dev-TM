-- Rollback for 05_allow_multiple_submission_batches.
-- Does not delete submission history. If multiple batches exist for one
-- user/period, restoring the old unique key is refused intentionally.
SET @duplicate_periods := (
    SELECT COUNT(*) FROM (
        SELECT `user_id`, `start_date`, `end_date`
        FROM `timesheets`
        GROUP BY `user_id`, `start_date`, `end_date`
        HAVING COUNT(*) > 1
    ) AS d
);

DELIMITER //
CREATE PROCEDURE `__tt_step12_rollback_check`()
BEGIN
    IF @duplicate_periods > 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Rollback refused: multiple submission batches exist for the same user and approval period; history must not be deleted.';
    END IF;
END//
DELIMITER ;
CALL `__tt_step12_rollback_check`();
DROP PROCEDURE `__tt_step12_rollback_check`;

ALTER TABLE `timesheets`
    DROP INDEX IF EXISTS `uq_timesheets_submission_token`;
ALTER TABLE `timesheets`
    DROP INDEX IF EXISTS `idx_timesheets_user_period`;
ALTER TABLE `timesheets`
    ADD UNIQUE INDEX IF NOT EXISTS `uq_timesheets_user_period` (`user_id`, `start_date`, `end_date`);
ALTER TABLE `timesheets`
    DROP COLUMN IF EXISTS `submission_token`;
