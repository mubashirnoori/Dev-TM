-- TimeTrack Phase 13 / Step 13
-- Add a self-reference from generated recurrence copies to their source schedule.
-- Safe to run repeatedly on MariaDB 11.8.

SET @db_name := DATABASE();

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name
          AND table_name = 'schedules'
          AND column_name = 'recurrence_parent_id'
    ),
    'SELECT 1',
    'ALTER TABLE `schedules` ADD COLUMN `recurrence_parent_id` INT UNSIGNED NULL AFTER `user_id`'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'schedules'
          AND index_name = 'idx_schedules_recurrence_parent'
    ),
    'SELECT 1',
    'ALTER TABLE `schedules` ADD INDEX `idx_schedules_recurrence_parent` (`recurrence_parent_id`)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_schema = @db_name
          AND table_name = 'schedules'
          AND constraint_name = 'fk_schedules_recurrence_parent'
          AND constraint_type = 'FOREIGN KEY'
    ),
    'SELECT 1',
    'ALTER TABLE `schedules` ADD CONSTRAINT `fk_schedules_recurrence_parent` FOREIGN KEY (`recurrence_parent_id`) REFERENCES `schedules` (`id`) ON DELETE SET NULL ON UPDATE CASCADE'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
