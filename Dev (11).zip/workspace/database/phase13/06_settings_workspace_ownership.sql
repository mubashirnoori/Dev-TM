-- TimeTrack Phase 13 / Step 14
-- Canonical settings ownership.
-- Global/system values remain in settings; workspace policy values live in workspace_settings.
-- Safe to run more than once.

START TRANSACTION;

-- Preserve the existing workspace name when it is already meaningful. If an older
-- install only has the generic/default name, migrate the legacy company name into it.
UPDATE workspaces w
JOIN settings s ON s.setting_key = 'company_name'
SET w.name = s.setting_value,
    w.updated_at = UTC_TIMESTAMP()
WHERE TRIM(w.name) = '' OR w.name IN ('TimeTrack', 'Your Company');

-- Legacy week_start_day -> workspace week_start. Existing workspace value wins.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id,
       'week_start',
       CASE
           WHEN s.setting_value = '0' THEN 'sunday'
           ELSE 'monday'
       END,
       UTC_TIMESTAMP()
FROM workspaces w
LEFT JOIN settings s ON s.setting_key = 'week_start_day'
LEFT JOIN workspace_settings ws
       ON ws.workspace_id = w.id AND ws.setting_key = 'week_start'
WHERE ws.workspace_id IS NULL;

-- Legacy working_hours_per_day -> workspace daily_capacity. Existing workspace value wins.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id,
       'daily_capacity',
       CASE
           WHEN s.setting_value REGEXP '^[0-9]+(\\.[0-9]+)?$'
               THEN CAST(LEAST(24, GREATEST(1, CAST(s.setting_value AS DECIMAL(10,2)))) AS CHAR)
           ELSE '8'
       END,
       UTC_TIMESTAMP()
FROM workspaces w
LEFT JOIN settings s ON s.setting_key = 'working_hours_per_day'
LEFT JOIN workspace_settings ws
       ON ws.workspace_id = w.id AND ws.setting_key = 'daily_capacity'
WHERE ws.workspace_id IS NULL;

-- Legacy time_rounding_minutes -> workspace time_rounding_minutes.
-- Canonical workspace policy permits 1..60, so legacy 0/off is normalized to 1.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id,
       'time_rounding_minutes',
       CASE
           WHEN s.setting_value REGEXP '^[0-9]+$'
               THEN CAST(LEAST(60, GREATEST(1, CAST(s.setting_value AS UNSIGNED))) AS CHAR)
           ELSE '1'
       END,
       UTC_TIMESTAMP()
FROM workspaces w
LEFT JOIN settings s ON s.setting_key = 'time_rounding_minutes'
LEFT JOIN workspace_settings ws
       ON ws.workspace_id = w.id AND ws.setting_key = 'time_rounding_minutes'
WHERE ws.workspace_id IS NULL;

-- Legacy timesheet_approval -> workspace time_approval_enabled.
-- timesheet_enabled remains a separate workspace feature switch.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id,
       'time_approval_enabled',
       CASE
           WHEN s.setting_value IN ('1','true','yes','on') THEN '1'
           ELSE '0'
       END,
       UTC_TIMESTAMP()
FROM workspaces w
LEFT JOIN settings s ON s.setting_key = 'timesheet_approval'
LEFT JOIN workspace_settings ws
       ON ws.workspace_id = w.id AND ws.setting_key = 'time_approval_enabled'
WHERE ws.workspace_id IS NULL;

-- Ensure canonical system keys exist. Never recreate the deleted legacy keys.
INSERT IGNORE INTO settings (setting_key, setting_value, setting_type, setting_group, description) VALUES
    ('app_name', 'TimeTrack', 'string', 'general', 'Name shown in the header and emails.'),
    ('company_email', 'hello@timetrack.local', 'string', 'general', 'Contact address for system emails.'),
    ('date_format', 'M j, Y', 'string', 'general', 'PHP date() format for dates.'),
    ('time_format', 'H:i', 'string', 'general', 'PHP date() format for times.'),
    ('default_timezone', 'UTC', 'string', 'general', 'Timezone used when a user has not chosen one.'),
    ('currency', 'USD', 'string', 'billing', 'ISO currency code for rates and budgets.'),
    ('currency_symbol', '$', 'string', 'billing', 'Symbol shown next to money amounts.'),
    ('default_hourly_rate', '0', 'string', 'billing', 'Rate applied to billable projects without their own rate.'),
    ('timer_max_hours', '12', 'int', 'time', 'Stop a running timer automatically after this many hours.'),
    ('allow_manual_time_entries', '1', 'bool', 'time', 'Let employees add time entries by hand.'),
    ('notifications_enabled', '1', 'bool', 'system', 'Create in-app notifications.'),
    ('maintenance_mode', '0', 'bool', 'system', 'Block non-admin sign-ins while maintenance is under way.');

-- Ensure every workspace has every canonical policy key.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id, v.setting_key, v.setting_value, UTC_TIMESTAMP()
FROM workspaces w
CROSS JOIN (
    SELECT 'timesheet_enabled' AS setting_key, '0' AS setting_value UNION ALL
    SELECT 'hide_tracker', '0' UNION ALL
    SELECT 'kiosk_enabled', '0' UNION ALL
    SELECT 'default_project_visibility', 'private' UNION ALL
    SELECT 'organize_time_by', 'project_task' UNION ALL
    SELECT 'duration_format', 'clock_seconds' UNION ALL
    SELECT 'week_start', 'monday' UNION ALL
    SELECT 'working_days', 'Mon,Tue,Wed,Thu,Fri' UNION ALL
    SELECT 'daily_capacity', '8' UNION ALL
    SELECT 'favorites_enabled', '0' UNION ALL
    SELECT 'favorite_entries_enabled', '0' UNION ALL
    SELECT 'required_fields', '' UNION ALL
    SELECT 'breaks_enabled', '0' UNION ALL
    SELECT 'time_rounding_minutes', '1' UNION ALL
    SELECT 'time_approval_enabled', '0' UNION ALL
    SELECT 'approval_period', 'weekly' UNION ALL
    SELECT 'expense_approval_enabled', '0' UNION ALL
    SELECT 'time_off_enabled', '0' UNION ALL
    SELECT 'invoicing_enabled', '0' UNION ALL
    SELECT 'expenses_enabled', '0' UNION ALL
    SELECT 'scheduling_enabled', '0' UNION ALL
    SELECT 'activity_monitoring_enabled', '0' UNION ALL
    SELECT 'gps_enabled', '0' UNION ALL
    SELECT 'screenshots_enabled', '0' UNION ALL
    SELECT 'audit_log_enabled', '1' UNION ALL
    SELECT 'billable_hours_enabled', '1' UNION ALL
    SELECT 'project_creation_policy', 'admins' UNION ALL
    SELECT 'task_creation_policy', 'admins_project_managers' UNION ALL
    SELECT 'tag_creation_policy', 'admins' UNION ALL
    SELECT 'regular_user_time_visibility', 'own' UNION ALL
    SELECT 'project_status_visibility', 'admins' UNION ALL
    SELECT 'hide_projects', '0' UNION ALL
    SELECT 'hide_team', '0' UNION ALL
    SELECT 'hide_reports', '0' UNION ALL
    SELECT 'timesheet_approver_policy', 'admins_team_managers' UNION ALL
    SELECT 'edit_time_others_policy', 'admins' UNION ALL
    SELECT 'invoice_manager_policy', 'admins' UNION ALL
    SELECT 'lock_time_enabled', '0' UNION ALL
    SELECT 'force_timer', '0'
) v;

-- Remove the legacy duplicates. These keys are no longer writable/read by Step 14.
DELETE FROM settings
WHERE setting_key IN (
    'company_name',
    'week_start_day',
    'working_hours_per_day',
    'time_rounding_minutes',
    'timesheet_approval'
);

COMMIT;
