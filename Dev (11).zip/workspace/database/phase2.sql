-- =====================================================================
--  TimeTrack: Phase 2 schema + sample data
--  Run AFTER Phase 1 (schema.sql + seed.sql) on an existing database.
--  Safe to re-run: tables use IF NOT EXISTS; sample rows are skipped
--  when they already exist.
--
--      mysql -u USER -p DATABASE < database/phase2.sql
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `clients` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`       VARCHAR(160) NOT NULL,
    `email`      VARCHAR(190) NULL,
    `phone`      VARCHAR(30)  NULL,
    `company`    VARCHAR(160) NULL,
    `address`    VARCHAR(255) NULL,
    `status`     ENUM('active','inactive') NOT NULL DEFAULT 'active',
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_clients_status` (`status`),
    KEY `idx_clients_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `projects` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `client_id`       INT UNSIGNED NOT NULL,
    `project_code`    VARCHAR(40)  NOT NULL,
    `name`            VARCHAR(160) NOT NULL,
    `description`     TEXT         NULL,
    `start_date`      DATE         NULL,
    `due_date`        DATE         NULL,
    `status`          ENUM('Planning','Active','On Hold','Completed','Cancelled','Archived') NOT NULL DEFAULT 'Planning',
    `priority`        ENUM('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
    `estimated_hours` DECIMAL(8,2)  NOT NULL DEFAULT 0.00,
    `budget`          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `hourly_rate`     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `is_billable`     TINYINT(1)    NOT NULL DEFAULT 1,
    `manager_id`      INT UNSIGNED  NULL,
    `created_by`      INT UNSIGNED  NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_projects_code` (`project_code`),
    KEY `idx_projects_client` (`client_id`),
    KEY `idx_projects_status` (`status`),
    KEY `idx_projects_priority` (`priority`),
    KEY `idx_projects_manager` (`manager_id`),
    KEY `idx_projects_created_by` (`created_by`),
    KEY `idx_projects_dates` (`start_date`, `due_date`),
    CONSTRAINT `fk_projects_client`
        FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_projects_manager`
        FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_projects_created_by`
        FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `project_members` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id`   INT UNSIGNED NOT NULL,
    `user_id`      INT UNSIGNED NOT NULL,
    `project_role` VARCHAR(40)  NOT NULL DEFAULT 'member',
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_project_members` (`project_id`, `user_id`),
    KEY `idx_project_members_user` (`user_id`),
    CONSTRAINT `fk_project_members_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_project_members_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `clients` (`name`, `email`, `phone`, `company`, `address`, `status`)
SELECT 'Northwind Traders', 'ops@northwind.example', '+1 206 555 0101', 'Northwind Traders LLC', '1 Harbor Way, Seattle, WA', 'active'
WHERE NOT EXISTS (SELECT 1 FROM `clients` WHERE `name` = 'Northwind Traders');

INSERT INTO `clients` (`name`, `email`, `phone`, `company`, `address`, `status`)
SELECT 'Acme Industries', 'hello@acme.example', '+1 415 555 0144', 'Acme Industries Inc.', '88 Market Street, San Francisco, CA', 'active'
WHERE NOT EXISTS (SELECT 1 FROM `clients` WHERE `name` = 'Acme Industries');

INSERT INTO `clients` (`name`, `email`, `phone`, `company`, `address`, `status`)
SELECT 'Harbor Digital', 'team@harbor.example', '+1 617 555 0199', 'Harbor Digital Co.', '12 Atlantic Ave, Boston, MA', 'active'
WHERE NOT EXISTS (SELECT 1 FROM `clients` WHERE `name` = 'Harbor Digital');

INSERT INTO `projects` (
    `client_id`, `project_code`, `name`, `description`, `start_date`, `due_date`,
    `status`, `priority`, `estimated_hours`, `budget`, `hourly_rate`, `is_billable`,
    `manager_id`, `created_by`
)
SELECT c.`id`, 'PRJ-0001', 'Website Redesign',
       'Rebuild the public marketing site with a new design system and CMS.',
       UTC_DATE() - INTERVAL 21 DAY, UTC_DATE() + INTERVAL 45 DAY,
       'Active', 'High', 120.00, 18000.00, 150.00, 1,
       (SELECT `id` FROM `users` WHERE `email` = 'manager@timetrack.local' LIMIT 1),
       (SELECT `id` FROM `users` WHERE `email` = 'admin@timetrack.local' LIMIT 1)
FROM `clients` c
WHERE c.`name` = 'Northwind Traders'
  AND NOT EXISTS (SELECT 1 FROM `projects` WHERE `project_code` = 'PRJ-0001');

INSERT INTO `projects` (
    `client_id`, `project_code`, `name`, `description`, `start_date`, `due_date`,
    `status`, `priority`, `estimated_hours`, `budget`, `hourly_rate`, `is_billable`,
    `manager_id`, `created_by`
)
SELECT c.`id`, 'PRJ-0002', 'Mobile App MVP',
       'First release of the iOS and Android companion app.',
       UTC_DATE() + INTERVAL 7 DAY, UTC_DATE() + INTERVAL 120 DAY,
       'Planning', 'Urgent', 320.00, 48000.00, 150.00, 1,
       (SELECT `id` FROM `users` WHERE `email` = 'manager@timetrack.local' LIMIT 1),
       (SELECT `id` FROM `users` WHERE `email` = 'admin@timetrack.local' LIMIT 1)
FROM `clients` c
WHERE c.`name` = 'Acme Industries'
  AND NOT EXISTS (SELECT 1 FROM `projects` WHERE `project_code` = 'PRJ-0002');

INSERT INTO `projects` (
    `client_id`, `project_code`, `name`, `description`, `start_date`, `due_date`,
    `status`, `priority`, `estimated_hours`, `budget`, `hourly_rate`, `is_billable`,
    `manager_id`, `created_by`
)
SELECT c.`id`, 'PRJ-0003', 'Brand Refresh',
       'Logo, colour system and template update across sales materials.',
       UTC_DATE() - INTERVAL 90 DAY, UTC_DATE() - INTERVAL 10 DAY,
       'Completed', 'Medium', 64.00, 8000.00, 125.00, 1,
       (SELECT `id` FROM `users` WHERE `email` = 'manager@timetrack.local' LIMIT 1),
       (SELECT `id` FROM `users` WHERE `email` = 'admin@timetrack.local' LIMIT 1)
FROM `clients` c
WHERE c.`name` = 'Harbor Digital'
  AND NOT EXISTS (SELECT 1 FROM `projects` WHERE `project_code` = 'PRJ-0003');

INSERT INTO `projects` (
    `client_id`, `project_code`, `name`, `description`, `start_date`, `due_date`,
    `status`, `priority`, `estimated_hours`, `budget`, `hourly_rate`, `is_billable`,
    `manager_id`, `created_by`
)
SELECT c.`id`, 'PRJ-0004', 'Q4 Support Retainer',
       'Ongoing support and small enhancements. Paused pending budget approval.',
       UTC_DATE() - INTERVAL 14 DAY, UTC_DATE() + INTERVAL 76 DAY,
       'On Hold', 'Low', 40.00, 5000.00, 125.00, 1,
       (SELECT `id` FROM `users` WHERE `email` = 'manager@timetrack.local' LIMIT 1),
       (SELECT `id` FROM `users` WHERE `email` = 'manager@timetrack.local' LIMIT 1)
FROM `clients` c
WHERE c.`name` = 'Northwind Traders'
  AND NOT EXISTS (SELECT 1 FROM `projects` WHERE `project_code` = 'PRJ-0004');

INSERT INTO `project_members` (`project_id`, `user_id`, `project_role`)
SELECT p.`id`, u.`id`, 'manager'
FROM `projects` p
INNER JOIN `users` u ON u.`email` = 'manager@timetrack.local'
WHERE p.`project_code` IN ('PRJ-0001', 'PRJ-0002', 'PRJ-0003', 'PRJ-0004')
  AND NOT EXISTS (
      SELECT 1 FROM `project_members` pm
      WHERE pm.`project_id` = p.`id` AND pm.`user_id` = u.`id`
  );

INSERT INTO `project_members` (`project_id`, `user_id`, `project_role`)
SELECT p.`id`, u.`id`, 'member'
FROM `projects` p
INNER JOIN `users` u ON u.`email` = 'john@timetrack.local'
WHERE p.`project_code` IN ('PRJ-0001', 'PRJ-0002')
  AND NOT EXISTS (
      SELECT 1 FROM `project_members` pm
      WHERE pm.`project_id` = p.`id` AND pm.`user_id` = u.`id`
  );

INSERT INTO `project_members` (`project_id`, `user_id`, `project_role`)
SELECT p.`id`, u.`id`, 'member'
FROM `projects` p
INNER JOIN `users` u ON u.`email` = 'sarah@timetrack.local'
WHERE p.`project_code` IN ('PRJ-0001', 'PRJ-0003')
  AND NOT EXISTS (
      SELECT 1 FROM `project_members` pm
      WHERE pm.`project_id` = p.`id` AND pm.`user_id` = u.`id`
  );
