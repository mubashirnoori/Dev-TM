<?php
/**
 * Global/system settings form. Workspace identity and policies are managed on /workspace.
 *
 * @var array<string, string> $settings
 * @var list<string> $timezones
 * @var list<string> $currencies
 * @var list<string> $dateFormats
 * @var list<string> $timeFormats
 */

$val = static fn (string $key, string $default = ''): string => old($key, (string) ($settings[$key] ?? $default));
$on = static fn (string $key): bool => old($key, (string) ($settings[$key] ?? '0')) === '1';
$selectedZone = old('default_timezone', (string) ($settings['default_timezone'] ?? 'UTC'));
$selectedCurrency = old('currency', (string) ($settings['currency'] ?? 'USD'));
$selectedDate = old('date_format', (string) ($settings['date_format'] ?? 'M j, Y'));
$selectedTime = old('time_format', (string) ($settings['time_format'] ?? 'H:i'));
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">System settings</h2>
        <p class="page-lead">Global application, billing and timezone defaults. Workspace policies live under Workspace.</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-xl-8">
        <form method="post" action="<?= e(url('/settings')) ?>" novalidate data-single-submit>
            <?= csrf_field() ?>
            <section class="panel mb-4">
                <div class="panel-head">
                    <h2 class="panel-title">General</h2>
                </div>
                <div class="panel-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="app_name" class="form-label">Application name</label>
                            <input type="text" id="app_name" name="app_name" maxlength="80" required
                                   class="form-control<?= field_error('app_name') ? ' is-invalid' : '' ?>" value="<?= e($val('app_name', 'TimeTrack')) ?>">
                            <?php if (field_error('app_name')): ?><div class="invalid-feedback"><?= e(field_error('app_name')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="company_email" class="form-label">Company email</label>
                            <input type="email" id="company_email" name="company_email" maxlength="190" required
                                   class="form-control<?= field_error('company_email') ? ' is-invalid' : '' ?>" value="<?= e($val('company_email')) ?>">
                            <?php if (field_error('company_email')): ?><div class="invalid-feedback"><?= e(field_error('company_email')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label for="date_format" class="form-label">Date format</label>
                            <select id="date_format" name="date_format" class="form-select<?= field_error('date_format') ? ' is-invalid' : '' ?>" required>
                                <?php foreach ($dateFormats as $format): ?>
                                    <option value="<?= e($format) ?>"<?= $selectedDate === $format ? ' selected' : '' ?>><?= e($format) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('date_format')): ?><div class="invalid-feedback"><?= e(field_error('date_format')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label for="time_format" class="form-label">Time format</label>
                            <select id="time_format" name="time_format" class="form-select<?= field_error('time_format') ? ' is-invalid' : '' ?>" required>
                                <?php foreach ($timeFormats as $format): ?>
                                    <option value="<?= e($format) ?>"<?= $selectedTime === $format ? ' selected' : '' ?>><?= e($format) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('time_format')): ?><div class="invalid-feedback"><?= e(field_error('time_format')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label for="default_timezone" class="form-label">Default timezone</label>
                            <select id="default_timezone" name="default_timezone" class="form-select<?= field_error('default_timezone') ? ' is-invalid' : '' ?>" required>
                                <?php foreach ($timezones as $zone): ?>
                                    <option value="<?= e($zone) ?>"<?= $zone === $selectedZone ? ' selected' : '' ?>><?= e(str_replace('_', ' ', $zone)) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('default_timezone')): ?><div class="invalid-feedback"><?= e(field_error('default_timezone')) ?></div><?php endif; ?>
                            <div class="form-text">Stored data stays in UTC. Users can override this on their profile.</div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="panel mb-4">
                <div class="panel-head">
                    <h2 class="panel-title">Billing</h2>
                </div>
                <div class="panel-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label for="currency" class="form-label">Currency code</label>
                            <select id="currency" name="currency" class="form-select<?= field_error('currency') ? ' is-invalid' : '' ?>">
                                <?php foreach ($currencies as $currency): ?>
                                    <option value="<?= e($currency) ?>"<?= $selectedCurrency === $currency ? ' selected' : '' ?>><?= e($currency) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('currency')): ?><div class="invalid-feedback"><?= e(field_error('currency')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-3">
                            <label for="currency_symbol" class="form-label">Currency symbol</label>
                            <input type="text" id="currency_symbol" name="currency_symbol" maxlength="6" required
                                   class="form-control<?= field_error('currency_symbol') ? ' is-invalid' : '' ?>" value="<?= e($val('currency_symbol', '$')) ?>">
                            <?php if (field_error('currency_symbol')): ?><div class="invalid-feedback"><?= e(field_error('currency_symbol')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="default_hourly_rate" class="form-label">Default hourly rate</label>
                            <input type="number" id="default_hourly_rate" name="default_hourly_rate" min="0" step="0.01" inputmode="decimal" required
                                   class="form-control<?= field_error('default_hourly_rate') ? ' is-invalid' : '' ?>" value="<?= e($val('default_hourly_rate', '0')) ?>">
                            <?php if (field_error('default_hourly_rate')): ?><div class="invalid-feedback"><?= e(field_error('default_hourly_rate')) ?></div><?php endif; ?>
                            <div class="form-text">Used when a project or person has no rate of their own.</div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <h2 class="panel-title">Time and system</h2>
                </div>
                <div class="panel-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="timer_max_hours" class="form-label">Timer maximum hours</label>
                            <input type="number" id="timer_max_hours" name="timer_max_hours" min="1" max="24" step="1" required
                                   class="form-control<?= field_error('timer_max_hours') ? ' is-invalid' : '' ?>" value="<?= e($val('timer_max_hours', '12')) ?>">
                            <?php if (field_error('timer_max_hours')): ?><div class="invalid-feedback"><?= e(field_error('timer_max_hours')) ?></div><?php endif; ?>
                            <div class="form-text">The server stops a running timer after this many hours.</div>
                        </div>
                        <div class="col-md-6 d-flex flex-column justify-content-end gap-2">
                            <label class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="allow_manual_time_entries" value="1" <?= $on('allow_manual_time_entries') ? 'checked' : '' ?>>
                                <span class="form-check-label">Allow manual time entries</span>
                            </label>
                            <label class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="notifications_enabled" value="1" <?= $on('notifications_enabled') ? 'checked' : '' ?>>
                                <span class="form-check-label">In-app notifications</span>
                            </label>
                            <label class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="maintenance_mode" value="1" <?= $on('maintenance_mode') ? 'checked' : '' ?>>
                                <span class="form-check-label">Maintenance mode</span>
                            </label>
                        </div>
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">Save settings</button>
                        <a class="btn btn-outline-secondary ms-2" href="<?= e(url('/workspace?tab=features')) ?>">Workspace policies</a>
                    </div>
                </div>
            </section>
        </form>
    </div>
</div>
