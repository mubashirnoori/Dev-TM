<?php
/**
 * Manager matrix: planned hours and blocks per person for one week.
 *
 * @var DateTimeImmutable $weekStart
 * @var list<DateTimeImmutable> $days
 * @var list<array<string, mixed>> $workload
 * @var array<int, list<array<string, mixed>>> $byUser
 * @var string $prevWeek
 * @var string $nextWeek
 * @var bool $canCreate
 */

$weekStart = $weekStart ?? new DateTimeImmutable(WorkspacePolicy::weekModifier());
$days      = $days ?? [];
$workload  = $workload ?? [];
$byUser    = $byUser ?? [];
$canCreate = $canCreate ?? false;
$todayKey  = (new DateTimeImmutable('today', $weekStart->getTimezone()))->format('Y-m-d');
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Team schedule</h2>
        <p class="page-lead">Planned hours for the week of <?= e($weekStart->format('M j, Y')) ?>.</p>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-secondary" href="<?= e(url('/schedule/team?week=' . $prevWeek)) ?>">Previous</a>
        <a class="btn btn-outline-secondary" href="<?= e(url('/schedule/team')) ?>">This week</a>
        <a class="btn btn-outline-secondary" href="<?= e(url('/schedule/team?week=' . $nextWeek)) ?>">Next</a>
        <?php if ($canCreate): ?>
            <button type="button" class="btn btn-primary" id="scheduleNewBtn">Plan work</button>
        <?php endif; ?>
    </div>
</div>

<nav class="filter-tabs" aria-label="Schedule views">
    <a class="filter-tab" href="<?= e(url('/schedule')) ?>">Calendar</a>
    <a class="filter-tab" href="<?= e(url('/schedule/my')) ?>">My upcoming</a>
    <a class="filter-tab is-active" href="<?= e(url('/schedule/team')) ?>">Team</a>
</nav>

<div class="kpi-grid mb-4">
    <?php foreach ($workload as $row): ?>
        <?php $hours = ((int) $row['planned_seconds']) / 3600; ?>
        <article class="kpi-card">
            <p class="kpi-label"><?= e($row['name']) ?></p>
            <p class="kpi-value"><?= e(number_format($hours, 1)) ?>h</p>
            <p class="kpi-sub"><?= (int) $row['block_count'] ?> block<?= (int) $row['block_count'] === 1 ? '' : 's' ?> this week</p>
        </article>
    <?php endforeach; ?>
</div>

<section class="panel">
    <div class="table-responsive">
        <table class="table data-table team-matrix mb-0">
            <thead>
                <tr>
                    <th>Person</th>
                    <?php foreach ($days as $day): ?>
                        <th class="<?= $day->format('Y-m-d') === $todayKey ? 'is-today' : '' ?>">
                            <?= e($day->format('D')) ?><br>
                            <span class="fw-normal"><?= e($day->format('M j')) ?></span>
                        </th>
                    <?php endforeach; ?>
                    <th>Week</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($workload as $person): ?>
                    <?php
                    $uid = (int) $person['user_id'];
                    $blocks = $byUser[$uid] ?? [];
                    $byDay = [];
                    foreach ($blocks as $block) {
                        $key = FormatHelper::datetime((string) $block['start_datetime'], 'Y-m-d');
                        $byDay[$key][] = $block;
                    }
                    ?>
                    <tr>
                        <td>
                            <strong><?= e($person['name']) ?></strong>
                            <div class="small text-secondary"><?= e($person['job_title'] ?: $person['role']) ?></div>
                        </td>
                        <?php foreach ($days as $day): ?>
                            <?php $key = $day->format('Y-m-d'); ?>
                            <td class="team-cell<?= $key === $todayKey ? ' is-today' : '' ?>">
                                <?php foreach ($byDay[$key] ?? [] as $block): ?>
                                    <a class="team-chip" href="<?= e(url('/schedule?view=day&user_id=' . (int) $block['user_id'])) ?>"
                                       style="background: <?= e($block['color']) ?>"
                                       title="<?= e($block['project_name']) ?>">
                                        <span><?= e(FormatHelper::datetime((string) $block['start_datetime'], 'H:i')) ?></span>
                                        <?= e(FormatHelper::truncate((string) $block['project_name'], 22)) ?>
                                    </a>
                                <?php endforeach; ?>
                            </td>
                        <?php endforeach; ?>
                        <td class="mono"><?= e(number_format(((int) $person['planned_seconds']) / 3600, 1)) ?>h</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<div id="scheduleCalendar"
     hidden
     data-view="week"
     data-user-id="all"
     data-events-url="<?= e(url('/schedule/events')) ?>"
     data-store-url="<?= e(url('/schedule')) ?>"
     data-tasks-url="<?= e(url('/schedule/tasks')) ?>"
     data-assignees-url="<?= e(url('/schedule/assignees')) ?>"
     data-timezone="<?= e(FormatHelper::displayTimezone()) ?>"
     data-can-create="<?= $canCreate ? '1' : '0' ?>"
     data-can-edit="<?= !empty($canEdit) ? '1' : '0' ?>"
     data-can-delete="<?= !empty($canDelete) ? '1' : '0' ?>"
     data-has-tasks="<?= !empty($hasTasks) ? '1' : '0' ?>">
</div>

<?php require APP_PATH . '/Views/schedule/modal_form.php'; ?>
