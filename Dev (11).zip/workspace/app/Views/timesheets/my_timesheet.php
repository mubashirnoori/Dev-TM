<?php
/**
 * Weekly timesheet matrix (Project | Task | Mon–Sun | Total) and monthly overview.
 *
 * @var string $activeTab
 * @var DateTimeImmutable $weekStart
 * @var string $prevWeek
 * @var string $nextWeek
 * @var string $thisWeek
 * @var array<string, mixed>|null $matrix
 * @var array<string, mixed>|null $month
 * @var array<string, mixed>|null $timesheet
 * @var string $status
 * @var bool $locked
 * @var bool $canSubmit
 * @var bool $canApprove
 * @var string $view
 */

$view       = $view ?? 'week';
$matrix     = $matrix ?? null;
$month      = $month ?? null;
$timesheet  = $timesheet ?? null;
$canSubmit  = $canSubmit ?? false;
$canApprove = $canApprove ?? false;
$submittable = $submittable ?? [];
$unsubmitted = $unsubmitted ?? [];
$period = $period ?? null;
$approvalSettings = $approvalSettings ?? ['approval_period' => 'weekly', 'week_start' => 'monday'];
$locked     = $locked ?? false;
$status     = $status ?? Timesheet::STATUS_DRAFT;
$weekStart  = $weekStart ?? new DateTimeImmutable(WorkspacePolicy::weekModifier());

$statusClass = static fn (string $s): string => match ($s) {
    Timesheet::STATUS_APPROVED  => 'completed',
    Timesheet::STATUS_REJECTED  => 'cancelled',
    Timesheet::STATUS_SUBMITTED => 'hold',
    default                     => 'planning',
};

$cellHours = static function (int $seconds): string {
    if ($seconds <= 0) {
        return '';
    }

    return FormatHelper::hours($seconds);
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Timesheet</h2>
        <p class="page-lead">
            <?php if ($view === 'month' && is_array($month)): ?>
                Hours for <?= e($month['month_label']) ?>.
            <?php else: ?>
                Week of <?= e($weekStart->format('M j, Y')) ?>
                <?php if (is_array($matrix)): ?>
                    &ndash; <?= e((new DateTimeImmutable($matrix['week_end']))->format('M j, Y')) ?>.
                <?php endif; ?>
            <?php endif; ?>
        </p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if ($view === 'month'): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets/month?month=' . $prevWeek)) ?>">Previous</a>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets/month')) ?>">This month</a>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets/month?month=' . $nextWeek)) ?>">Next</a>
        <?php else: ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets?week=' . $prevWeek)) ?>">Previous</a>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets')) ?>">This week</a>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets?week=' . $nextWeek)) ?>">Next</a>
        <?php endif; ?>
        <?php if ($submittable !== []): ?>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#timesheetSubmitWorkModal">
                <i class="fa-solid fa-paper-plane me-1" aria-hidden="true"></i>Submit for approval
            </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($view === 'week' && is_array($period)): ?>
    <?php
    $periodLabel = (new DateTimeImmutable($period['start_local']->format('Y-m-d')))->format('M j')
        . ' – ' . (new DateTimeImmutable($period['end_local']->format('Y-m-d')))->format('M j, Y');
    $periodType = match ((string) ($approvalSettings['approval_period'] ?? 'weekly')) {
        'monthly' => 'monthly',
        'semi-monthly' => 'semi-monthly',
        default => 'weekly',
    };
    ?>
    <div class="alert alert-info mb-3" role="status">
        <div class="fw-semibold">Approval period: <?= e($periodLabel) ?></div>
        <div class="small">This is a <?= e($periodType) ?> approval period. Submitted work is locked entry-by-entry; new work in this period remains available.</div>
    </div>
    <?php if ($unsubmitted !== []): ?>
        <div class="alert alert-warning mb-3" role="alert">
            <div class="fw-semibold mb-1"><i class="fa-solid fa-triangle-exclamation me-1" aria-hidden="true"></i>Earlier work is still unsubmitted</div>
            <div class="small">You have unsubmitted work in <?= e((string) count($unsubmitted)) ?> earlier approval period<?= count($unsubmitted) === 1 ? '' : 's' ?>. Review those periods before leaving work behind.</div>
            <div class="small mt-2">
                <?php foreach (array_slice($unsubmitted, 0, 3) as $oldPeriod): ?>
                    <a class="me-3" href="<?= e(url('/timesheets?week=' . (string) $oldPeriod['start_date'])) ?>"><?= e((string) $oldPeriod['start_date']) ?> – <?= e((string) $oldPeriod['end_date']) ?> (<?= e((string) $oldPeriod['entry_count']) ?> entries)</a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<nav class="filter-tabs" aria-label="Timesheet views">
    <a class="filter-tab<?= $view === 'week' ? ' is-active' : '' ?>" href="<?= e(url('/timesheets?week=' . $weekStart->format('Y-m-d'))) ?>">Week</a>
    <a class="filter-tab<?= $view === 'month' ? ' is-active' : '' ?>" href="<?= e(url('/timesheets/month')) ?>">Month</a>
    <?php if ($canApprove && FeatureFlagsHelper::timeApprovalEnabled()): ?>
        <a class="filter-tab" href="<?= e(url('/timesheets/team')) ?>">Team approval</a>
    <?php endif; ?>
</nav>

<?php if ($view === 'week' && is_array($matrix)): ?>
    <?php
    $days   = $matrix['days'];
    $rows   = $matrix['rows'];
    $status = (string) (($matrix['timesheet']['status'] ?? '') ?: $status);
    ?>

    <?php if ($status === Timesheet::STATUS_REJECTED && !empty($timesheet['rejection_reason'])): ?>
        <div class="alert alert-warning timesheet-reject-alert" role="alert">
            <div class="fw-semibold mb-1"><i class="fa-solid fa-triangle-exclamation me-1" aria-hidden="true"></i>This approval period was sent back</div>
            <p class="mb-1"><?= e((string) $timesheet['rejection_reason']) ?></p>
            <p class="mb-0 small">
                <?php if (!empty($timesheet['approved_by_name'])): ?>
                    <?= e((string) $timesheet['approved_by_name']) ?>
                    &middot;
                <?php endif; ?>
                <?= e(FormatHelper::datetime((string) ($timesheet['approved_at'] ?? ''), 'M j, Y H:i')) ?>
            </p>
        </div>
    <?php endif; ?>

    <div class="kpi-grid mb-4">
        <article class="kpi-card">
            <p class="kpi-label">Status</p>
            <p class="kpi-value"><span class="status-badge status-<?= e($statusClass($status)) ?>"><?= e($status) ?></span></p>
            <p class="kpi-sub">
                <?php if ($status === Timesheet::STATUS_SUBMITTED && !empty($timesheet['submitted_at'])): ?>
                    Sent <?= e(FormatHelper::datetime((string) $timesheet['submitted_at'], 'M j, H:i')) ?>
                <?php elseif ($status === Timesheet::STATUS_APPROVED && !empty($timesheet['approved_at'])): ?>
                    Approved <?= e(FormatHelper::datetime((string) $timesheet['approved_at'], 'M j, H:i')) ?>
                <?php elseif ($locked): ?>
                    Entries are locked
                <?php else: ?>
                    Not submitted
                <?php endif; ?>
            </p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Tracked</p>
            <p class="kpi-value"><?= e(FormatHelper::hours((int) $matrix['grand_total'])) ?>h</p>
            <p class="kpi-sub"><?= e(FormatHelper::duration((int) $matrix['grand_total'])) ?> &middot; <?= (int) $matrix['entry_count'] ?> entries</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Billable</p>
            <p class="kpi-value"><?= e(FormatHelper::hours((int) $matrix['billable_total'])) ?>h</p>
            <p class="kpi-sub"><?= e(FormatHelper::duration((int) $matrix['billable_total'])) ?></p>
        </article>
    </div>

    <?php if ($submittable !== []): ?>
        <section class="panel mb-4">
            <div class="panel-head">
                <div>
                    <h2 class="panel-title">Work awaiting approval</h2>
                    <p class="panel-subtitle mb-0">Select the work you want to submit. Already submitted or approved work is not shown.</p>
                </div>
                <div class="small text-secondary"><span data-timesheet-selected-count>0</span> selected</div>
            </div>
            <div class="table-responsive">
                <table class="table data-table mb-0">
                    <thead><tr><th class="text-center"><input type="checkbox" class="form-check-input" data-timesheet-select-all aria-label="Select all work"></th><th>Date</th><th>Project</th><th>Task</th><th>Note</th><th class="text-end">Duration</th></tr></thead>
                    <tbody>
                    <?php foreach ($submittable as $entry): ?>
                        <tr>
                            <td class="text-center text-secondary">&mdash;</td>
                            <td><?= e(FormatHelper::datetime((string) $entry['start_time'], 'M j, Y')) ?></td>
                            <td><?= e((string) $entry['project_name']) ?></td>
                            <td><?= !empty($entry['task_name']) ? e((string) $entry['task_name']) : '—' ?></td>
                            <td><?= !empty($entry['description']) ? e((string) $entry['description']) : '—' ?></td>
                            <td class="text-end mono"><?= e(FormatHelper::duration((int) $entry['duration_seconds'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endif; ?>

    <section class="panel timesheet-panel">
        <div class="panel-head">
            <h2 class="panel-title">Weekly grid</h2>
            <?php if ($locked): ?>
                <span class="count-pill">Locked</span>
            <?php endif; ?>
        </div>
        <?php if ($rows === []): ?>
            <div class="empty-state">
                <i class="fa-regular fa-clock" aria-hidden="true"></i>
                <p>No time entries this week. Track time or add an entry, then submit.</p>
                <?php if (FeatureFlagsHelper::trackerVisible()): ?>
                <p class="mt-3 mb-0"><a class="btn btn-outline-primary" href="<?= e(url('/time')) ?>">Open time tracker</a></p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table data-table timesheet-matrix mb-0">
                    <thead>
                        <tr>
                            <th>Project</th>
                            <th>Task</th>
                            <?php foreach ($days as $day): ?>
                                <th class="text-end<?= $day['is_today'] ? ' is-today' : '' ?><?= $day['is_weekend'] ? ' is-weekend' : '' ?>">
                                    <?= e($day['label']) ?>
                                    <span class="d-block fw-normal"><?= e($day['short']) ?></span>
                                </th>
                            <?php endforeach; ?>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <td>
                                    <a href="<?= e(url('/projects/' . (int) $row['project_id'])) ?>" class="fw-medium"><?= e($row['project_name']) ?></a>
                                    <?php if (!empty($row['project_code'])): ?>
                                        <div class="small text-secondary"><?= e($row['project_code']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><?= $row['task_name'] !== '' ? e($row['task_name']) : '—' ?></td>
                                <?php foreach ($days as $day): ?>
                                    <?php $secs = (int) ($row['days'][$day['key']] ?? 0); ?>
                                    <td class="text-end mono<?= $day['is_today'] ? ' is-today' : '' ?><?= $day['is_weekend'] ? ' is-weekend' : '' ?><?= $secs > 0 ? ' has-time' : '' ?>">
                                        <?= e($cellHours($secs)) ?>
                                    </td>
                                <?php endforeach; ?>
                                <td class="text-end mono fw-semibold"><?= e(FormatHelper::hours((int) $row['total_seconds'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="2">Daily total</th>
                            <?php foreach ($days as $day): ?>
                                <?php $secs = (int) ($matrix['column_totals'][$day['key']] ?? 0); ?>
                                <th class="text-end mono<?= $day['is_today'] ? ' is-today' : '' ?>">
                                    <?= e($cellHours($secs)) ?>
                                </th>
                            <?php endforeach; ?>
                            <th class="text-end mono"><?= e(FormatHelper::hours((int) $matrix['grand_total'])) ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </section>

<?php elseif ($view === 'month' && is_array($month)): ?>
    <div class="kpi-grid mb-4">
        <article class="kpi-card">
            <p class="kpi-label">Month</p>
            <p class="kpi-value"><?= e($month['month_label']) ?></p>
            <p class="kpi-sub"><?= count($month['weeks']) ?> weeks</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Tracked</p>
            <p class="kpi-value"><?= e(FormatHelper::hours((int) $month['grand_total'])) ?>h</p>
            <p class="kpi-sub"><?= e(FormatHelper::duration((int) $month['grand_total'])) ?></p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Billable</p>
            <p class="kpi-value"><?= e(FormatHelper::hours((int) $month['billable_total'])) ?>h</p>
            <p class="kpi-sub"><?= e(FormatHelper::duration((int) $month['billable_total'])) ?></p>
        </article>
    </div>

    <section class="panel">
        <div class="panel-head">
            <h2 class="panel-title">Weeks</h2>
        </div>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <th>Week</th>
                        <th>Entries</th>
                        <th>Tracked</th>
                        <th>Billable</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($month['weeks'] as $weekRow): ?>
                        <tr>
                            <td>
                                <?php
                                $ws = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $weekRow['week_start']);
                                $we = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $weekRow['week_end']);
                                ?>
                                <?= e($ws ? $ws->format('M j') : $weekRow['week_start']) ?>
                                &ndash;
                                <?= e($we ? $we->format('M j') : $weekRow['week_end']) ?>
                            </td>
                            <td><?= (int) $weekRow['entry_count'] ?></td>
                            <td class="mono"><?= e(FormatHelper::hours((int) $weekRow['total_seconds'])) ?>h</td>
                            <td class="mono"><?= e(FormatHelper::hours((int) $weekRow['billable_seconds'])) ?>h</td>
                            <td><span class="status-badge status-<?= e($statusClass((string) $weekRow['status'])) ?>"><?= e($weekRow['status']) ?></span></td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/timesheets?week=' . $weekRow['week_start'])) ?>">Open</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php endif; ?>

<?php if ($submittable !== []): ?>
<div class="modal fade" id="timesheetSubmitWorkModal" tabindex="-1" aria-labelledby="timesheetSubmitWorkModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <div><h2 class="modal-title h5 mb-1" id="timesheetSubmitWorkModalTitle">Submit work for approval</h2><p class="small text-secondary mb-0">Select only the work you want to submit now. The rest remains unsubmitted.</p></div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="<?= e(url('/timesheets/submit-selected')) ?>" id="timesheetSubmitWorkForm" data-single-submit data-confirm="Submit the selected work for approval?">
        <?= csrf_field() ?>
        <div class="modal-body">
          <div class="d-flex justify-content-between align-items-center mb-2"><label class="form-check mb-0"><input type="checkbox" class="form-check-input me-1" data-submit-modal-select-all> Select all</label><span class="small text-secondary"><span data-submit-modal-count>0</span> selected</span></div>
          <div class="table-responsive"><table class="table data-table mb-0"><thead><tr><th></th><th>Date</th><th>Project</th><th>Task</th><th>Note</th><th class="text-end">Duration</th></tr></thead><tbody>
          <?php foreach ($submittable as $entry): ?><tr><td class="text-center"><input type="checkbox" class="form-check-input" name="entry_ids[]" value="<?= (int) $entry['id'] ?>" data-submit-modal-work></td><td><?= e(FormatHelper::datetime((string) $entry['start_time'], 'M j, Y H:i')) ?></td><td><?= e((string) $entry['project_name']) ?></td><td><?= !empty($entry['task_name']) ? e((string) $entry['task_name']) : '&mdash;' ?></td><td><?= !empty($entry['description']) ? e((string) $entry['description']) : '&mdash;' ?></td><td class="text-end mono"><?= e(FormatHelper::duration((int) $entry['duration_seconds'])) ?></td></tr><?php endforeach; ?>
          </tbody></table></div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary" data-submit-modal-button disabled><i class="fa-solid fa-paper-plane me-1" aria-hidden="true"></i>Submit selected</button></div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded',function(){var a=document.querySelector('[data-submit-modal-select-all]'),c=document.querySelector('[data-submit-modal-count]'),s=document.querySelector('[data-submit-modal-button]'),b=function(){return Array.prototype.slice.call(document.querySelectorAll('[data-submit-modal-work]'));},sync=function(){var x=b(),n=x.filter(function(i){return i.checked;}).length;if(c)c.textContent=n;if(s)s.disabled=n===0;if(a)a.checked=x.length>0&&n===x.length;};if(a)a.addEventListener('change',function(){b().forEach(function(i){i.checked=a.checked;});sync();});document.addEventListener('change',function(e){if(e.target.matches&&e.target.matches('[data-submit-modal-work]'))sync();});sync();});
</script>
