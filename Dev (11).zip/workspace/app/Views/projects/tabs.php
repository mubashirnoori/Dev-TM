<?php
/**
 * Clockify-style project tabs: TASKS / ACCESS / STATUS / FORECAST / NOTE / SETTINGS.
 *
 * @var array<string, mixed> $project
 * @var string $activeProjectTab
 * @var bool $tasksReady
 * @var bool $canEdit
 */

$base = url('/projects/' . (int) $project['id']);

$tabs = [
    'tasks'    => ['Tasks',    $tasksReady],
    'access'   => ['Access',   true],
    'status'   => ['Status',   true],
    'forecast' => ['Forecast', true],
    'note'     => ['Note',     true],
    'settings' => ['Settings', !empty($canEdit)],
];
?>
<nav class="cf-tabs" aria-label="Project sections">
    <?php foreach ($tabs as $key => [$label, $show]): ?>
        <?php if (!$show) { continue; } ?>
        <a class="cf-tab<?= ($activeProjectTab ?? '') === $key ? ' is-active' : '' ?>"
           href="<?= e($base . '?tab=' . $key) ?>"
           <?= ($activeProjectTab ?? '') === $key ? 'aria-current="page"' : '' ?>><?= e($label) ?></a>
    <?php endforeach; ?>
</nav>
