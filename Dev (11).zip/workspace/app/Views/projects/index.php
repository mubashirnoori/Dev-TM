<?php
/**
 * Project list, Clockify layout: filter bar, sortable table, row click opens the project page.
 *
 * @var string $tab
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, counts: array<string, int>} $result
 * @var list<array<string, mixed>> $clients
 * @var list<array<string, mixed>> $managers
 * @var array{status: string, client_id: int, manager_id: int, q: string, members: list<int>, sort: string, dir: string} $filters
 * @var list<array<string, mixed>> $memberOptions
 * @var bool $canCreate
 * @var bool $canEdit
 * @var bool $canArchive
 * @var bool $canDelete
 * @var bool $isAdmin
 * @var int  $userId
 */

$items = $result['items'];

/** Build a /projects query string, overriding any of the current filter values. */
$qs = static function (array $extra = []) use ($tab, $filters): string {
    $data = array_filter([
        'tab'        => $extra['tab']    ?? $tab,
        'status'     => $filters['status'],
        'client_id'  => $extra['client_id'] ?? ($filters['client_id'] ?: ''),
        'manager_id' => $filters['manager_id'] ?: '',
        'members'    => $filters['members'] ?: null,
        'q'          => $filters['q'],
        'sort'       => $extra['sort']   ?? $filters['sort'],
        'dir'        => $extra['dir']    ?? $filters['dir'],
        'page'       => $extra['page']   ?? null,
    ], static fn ($v) => $v !== null && $v !== '' && $v !== 0 && $v !== '0');

    // The defaults are implied, keep URLs short.
    if (($data['tab'] ?? '') === 'active') { unset($data['tab']); }
    if (($data['sort'] ?? '') === 'name' && ($data['dir'] ?? 'asc') === 'asc') { unset($data['sort'], $data['dir']); }

    return $data === [] ? '' : '?' . http_build_query($data);
};

/** Header cell with a sort link and the up/down arrows. */
$sortLink = static function (string $key, string $label) use ($filters, $qs): string {
    $active = $filters['sort'] === $key;
    $next   = $active && $filters['dir'] === 'asc' ? 'desc' : 'asc';
    $icon   = !$active ? 'fa-sort' : ($filters['dir'] === 'asc' ? 'fa-sort-up' : 'fa-sort-down');

    return '<a class="cf-sort" href="' . e(url('/projects') . $qs(['sort' => $key, 'dir' => $next, 'page' => 1])) . '">'
        . e($label) . ' <i class="fa-solid ' . $icon . '" aria-hidden="true"></i></a>';
};

$statusTabs = ['active' => 'Active', 'completed' => 'Completed', 'archived' => 'Archived', 'all' => 'All'];
$backPath   = '/projects' . $qs();
?>
<div class="cf-page cfl">
    <div class="cfl-head">
        <h1 class="cfl-title">Projects</h1>
        <?php if ($canCreate): ?>
            <a class="cf-btn cf-btn-primary cfl-create" href="<?= e(url('/projects/create')) ?>">Create new project</a>
        <?php endif; ?>
    </div>

    <form method="get" action="<?= e(url('/projects')) ?>" class="cfl-filter">
        <span class="cfl-filter-label">Filter</span>

        <label class="cfl-select">
            <span class="visually-hidden">Status</span>
            <select name="tab">
                <?php foreach ($statusTabs as $key => $label): ?>
                    <option value="<?= e($key) ?>"<?= $tab === $key ? ' selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label class="cfl-select">
            <span class="visually-hidden">Client</span>
            <select name="client_id">
                <option value="">Client</option>
                <?php foreach ($clients as $client): ?>
                    <option value="<?= (int) $client['id'] ?>"<?= (int) $filters['client_id'] === (int) $client['id'] ? ' selected' : '' ?>><?= e($client['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <?php $selectedCount = count($filters['members']); ?>
        <div class="dropdown cfl-select cfl-access-filter">
            <button type="button" class="cfl-access-btn<?= $selectedCount ? ' has-value' : '' ?>" data-bs-toggle="dropdown"
                    data-bs-auto-close="outside" data-bs-popper-config='{"strategy":"fixed"}' aria-expanded="false">
                <span data-access-label>Access<?= $selectedCount ? ' (' . $selectedCount . ')' : '' ?></span>
                <i class="cfl-caret" aria-hidden="true"></i>
            </button>
            <div class="dropdown-menu cf-menu cfl-access-menu">
                <?php if ($memberOptions === []): ?>
                    <p class="cf-menu-hint m-2">No members yet.</p>
                <?php else: ?>
                    <label class="cf-check cfl-access-all">
                        <input type="checkbox" data-access-all>
                        <span>All members</span>
                    </label>
                    <div class="cfl-access-list">
                        <?php foreach ($memberOptions as $member): ?>
                            <label class="cf-check">
                                <input type="checkbox" name="members[]" value="<?= (int) $member['id'] ?>" data-access-item
                                       <?= in_array((int) $member['id'], $filters['members'], true) ? 'checked' : '' ?>>
                                <span><?= e($member['name']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <p class="cf-menu-hint">Pick people, then press Apply filter.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="cf-search cf-search-block cfl-search">
            <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
            <label for="project-q" class="visually-hidden">Find by name</label>
            <input type="search" id="project-q" name="q" placeholder="Find by name" value="<?= e($filters['q']) ?>" autocomplete="off">
        </div>

        <?php if ($filters['sort'] !== 'name' || $filters['dir'] !== 'asc'): ?>
            <input type="hidden" name="sort" value="<?= e($filters['sort']) ?>">
            <input type="hidden" name="dir" value="<?= e($filters['dir']) ?>">
        <?php endif; ?>
        <button type="submit" class="cfl-apply">Apply filter</button>
    </form>

    <section class="cfl-card" data-export-scope>
        <div class="cfl-band">
            <span>Projects</span>
            <div class="dropdown cfl-export">
                <button type="button" class="cf-band-select" data-bs-toggle="dropdown" aria-expanded="false">
                    Export <i class="fa-solid fa-caret-down" aria-hidden="true"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end cf-menu">
                    <li><button type="button" class="dropdown-item" data-export-csv="projects">Save as CSV</button></li>
                </ul>
            </div>
        </div>

        <div class="cf-table-wrap">
            <table class="cf-table cfl-table" data-export-table>
                <thead>
                    <tr>
                        <th class="cfl-col-check"><input type="checkbox" class="cfl-checkbox" data-select-all aria-label="Select all projects"></th>
                        <th class="cfl-col-name"><?= $sortLink('name', 'Name') ?></th>
                        <th><?= $sortLink('client', 'Client') ?></th>
                        <th><?= $sortLink('tracked', 'Tracked') ?></th>
                        <th><?= $sortLink('progress', 'Progress') ?></th>
                        <th>Access</th>
                        <th class="cfl-col-star"></th>
                        <th class="cfl-col-more"></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($items === []): ?>
                    <tr class="cfl-empty-row"><td colspan="8" class="cf-empty">
                        <?= $filters['q'] !== '' || $filters['client_id'] || $filters['members'] !== [] ? 'No projects match these filters.' : 'No projects in this view yet.' ?>
                    </td></tr>
                <?php endif; ?>
                <?php foreach ($items as $project): ?>
                    <?php
                    $pid          = (int) $project['id'];
                    $href         = url('/projects/' . $pid . '?tab=tasks');
                    $color        = preg_match('/^#[0-9a-fA-F]{6}$/', (string) ($project['color'] ?? '')) ? (string) $project['color'] : '#03a9f4';
                    $tracked      = (float) ($project['tracked_hours'] ?? 0);
                    $estimated    = (float) ($project['estimated_hours'] ?? 0);
                    $progress     = (int) ($project['progress'] ?? 0);
                    $isPublic     = array_key_exists('is_public', $project) ? (int) $project['is_public'] === 1 : null;
                    $accessLabel  = $isPublic === null ? '—' : ($isPublic ? 'Public' : 'Private');
                    $isFavorite   = (int) ($project['is_favorite'] ?? 0) > 0;
                    $trackedText  = number_format($tracked, 2, '.', '') . 'h';
                    $canManageRow = $isAdmin || (int) ($project['manager_id'] ?? 0) === $userId;
                    ?>
                    <tr class="cfl-row" data-project-href="<?= e($href) ?>">
                        <td class="cfl-col-check"><input type="checkbox" class="cfl-checkbox" data-select-row aria-label="Select <?= e($project['name']) ?>"></td>
                        <td class="cfl-col-name" data-export="<?= e($project['name']) ?>">
                            <a class="cfl-name" href="<?= e($href) ?>">
                                <span class="cfl-dot" style="background: <?= e($color) ?>" aria-hidden="true"></span><?= e($project['name']) ?>
                            </a>
                        </td>
                        <td class="cfl-client" data-export="<?= e($project['client_name'] ?? '') ?>"><?= e($project['client_name'] ?? '') !== '' ? e($project['client_name']) : '–' ?></td>
                        <td data-export="<?= e($trackedText) ?>"><?= e($trackedText) ?></td>
                        <td data-export="<?= $progress . '%' ?>">
                            <div class="cfl-progress" title="<?= $progress ?>%">
                                <div class="cfl-progress-bar" role="progressbar" aria-valuenow="<?= $progress ?>" aria-valuemin="0" aria-valuemax="100">
                                    <span style="width: <?= $progress ?>%"></span>
                                </div>
                                <span class="cfl-progress-text"><?= $progress ?>%</span>
                            </div>
                        </td>
                        <td class="cfl-access" data-export="<?= e($accessLabel) ?>"><?= e($accessLabel) ?></td>
                        <td class="cfl-col-star">
                            <form method="post" action="<?= e(url('/projects/' . $pid . '/favorite')) ?>" class="m-0">
                                <?= csrf_field() ?>
                                <input type="hidden" name="back" value="<?= e($backPath) ?>">
                                <button type="submit" class="cfl-star<?= $isFavorite ? ' is-on' : '' ?>"
                                        aria-label="<?= $isFavorite ? 'Remove from favorites' : 'Add to favorites' ?>"
                                        title="<?= $isFavorite ? 'Remove from favorites' : 'Add to favorites' ?>">
                                    <i class="<?= $isFavorite ? 'fa-solid' : 'fa-regular' ?> fa-star" aria-hidden="true"></i>
                                </button>
                            </form>
                        </td>
                        <td class="cfl-col-more">
                            <div class="dropdown">
                                <button type="button" class="cf-kebab" data-bs-toggle="dropdown"
                                        data-bs-popper-config='{"strategy":"fixed"}'
                                        aria-expanded="false" aria-label="Actions for <?= e($project['name']) ?>">
                                    <span class="cf-dots" aria-hidden="true"><i></i><i></i><i></i></span>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end cf-menu">
                                    <li><a class="dropdown-item" href="<?= e($href) ?>">Open project</a></li>
                                    <li><a class="dropdown-item" href="<?= e(url('/projects/' . $pid . '/dashboard')) ?>">Project dashboard</a></li>
                                    <?php if ($canEdit && $canManageRow): ?>
                                        <li><a class="dropdown-item" href="<?= e(url('/projects/' . $pid . '?tab=settings')) ?>">Settings</a></li>
                                    <?php endif; ?>
                                    <?php if ($canArchive && $canManageRow && (string) $project['status'] !== 'Archived'): ?>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                            <form method="post" action="<?= e(url('/projects/' . $pid . '/archive')) ?>"
                                                  data-confirm="Archive <?= e($project['name']) ?>? It will be hidden from the active project list.">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="dropdown-item">Archive</button>
                                            </form>
                                        </li>
                                    <?php elseif (!empty($canDelete) && $canManageRow && (string) $project['status'] === 'Archived'): ?>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                            <form method="post" action="<?= e(url('/projects/' . $pid . '/delete')) ?>"
                                                  data-confirm="Permanently delete <?= e($project['name']) ?>? This is only allowed when the project has no time entries and no timers.">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="dropdown-item text-danger">Delete</button>
                                            </form>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($result['pages'] > 1): ?>
            <nav class="cfl-pager" aria-label="Project pages">
                <span class="cf-muted"><?= (int) $result['total'] ?> projects</span>
                <span class="cfl-pages">
                    <?php for ($p = 1; $p <= $result['pages']; $p++): ?>
                        <a class="cfl-page<?= $p === (int) $result['page'] ? ' is-active' : '' ?>"
                           href="<?= e(url('/projects') . $qs(['page' => $p])) ?>"><?= $p ?></a>
                    <?php endfor; ?>
                </span>
            </nav>
        <?php endif; ?>
    </section>
</div>
