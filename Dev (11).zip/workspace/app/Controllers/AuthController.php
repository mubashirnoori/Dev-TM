<?php
/**
 * Sign in, sign out, own profile and password change.
 *
 * Login pages must be reachable without a session, while the profile pages need one,
 * so this controller is public at construction time and the profile actions call
 * requireLogin() themselves (same AuthMiddleware every other controller uses).
 *
 * SECURITY decisions:
 *  - One generic message for unknown e-mail and wrong password (no account enumeration),
 *    and password_verify() always runs so response time does not reveal which one failed.
 *  - Per-account lockout (security.login_max_attempts / login_lockout_minutes) plus a
 *    per-IP failure ceiling, so guessing across many accounts is slowed down too.
 *  - The session id is regenerated on login (AuthHelper::login) and on password change.
 *  - Passwords are bcrypt (cost 12) and are transparently re-hashed when the cost changes.
 */

declare(strict_types=1);

final class AuthController extends Controller
{
    private const HASH_OPTIONS = ['cost' => 12];

    /** Verified when the e-mail is unknown, so both paths cost the same time. Matches no real password. */
    private const DUMMY_HASH = '$2y$12$p.7X0qLnAWjRnqT2VII6ZONXReZ4OcoroAl43p63vN1oea.mnNk9y';

    private const BAD_CREDENTIALS = 'These credentials do not match our records.';

    public function __construct()
    {
        parent::__construct(false); // public by default; see requireLogin()
    }

    /* ------------------------------------------------------------------ login */

    /** GET /login */
    public function login(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            $this->redirect('/dashboard');
        }

        $this->render('auth/login', ['pageTitle' => 'Sign in'], 'auth');
    }

    /** POST /login */
    public function authenticate(Request $request, array $params): void
    {
        $data = $this->validate([
            'email'    => 'required|email|max:190',
            'password' => 'required|string|max:200',
        ], '/login', ['email' => 'Email', 'password' => 'Password']);

        $email = strtolower((string) $data['email']);
        $ip    = $request->ip();

        if ($this->tooManyFailuresFromIp($ip)) {
            LoggerHelper::warning('Login blocked: too many failures from IP', ['ip' => $ip]);
            $this->backWithErrors('/login', ['email' => 'Too many failed sign-in attempts. Please wait a few minutes and try again.']);
        }

        $user = Database::fetchOne(
            'SELECT id, name, email, password, role, status, timezone, locked_until
             FROM users WHERE email = :email LIMIT 1',
            ['email' => $email]
        );

        // Locked accounts are refused before the password is checked, even if it is correct.
        if ($user !== null && $user['locked_until'] !== null) {
            $remaining = strtotime($user['locked_until'] . ' UTC') - time();

            if ($remaining > 0) {
                $minutes = (int) ceil($remaining / 60);
                $this->recordFailure($user, $email, 'locked');
                $this->backWithErrors('/login', [
                    'email' => 'Too many failed attempts. Try again in ' . $minutes . ($minutes === 1 ? ' minute.' : ' minutes.'),
                ]);
            }
        }

        // Always run a bcrypt comparison, against a dummy hash when the account does not exist.
        $passwordOk = password_verify((string) $data['password'], $user['password'] ?? self::DUMMY_HASH);

        if ($user === null || !$passwordOk) {
            $this->recordFailure($user, $email, 'bad_credentials');
            $this->backWithErrors('/login', ['email' => self::BAD_CREDENTIALS]);
        }

        if ($user['status'] !== 'active') {
            LoggerHelper::audit('auth.login_blocked', 'user', (int) $user['id'], ['status' => $user['status']]);
            $this->backWithErrors('/login', ['email' => 'This account is not active. Please contact your administrator.']);
        }

        if ($user['role'] !== AuthHelper::ROLE_ADMIN && $this->maintenanceModeOn()) {
            $this->backWithErrors('/login', ['email' => 'The system is in maintenance mode. Please try again later.']);
        }

        Database::execute(
            'UPDATE users
             SET failed_login_attempts = 0, locked_until = NULL,
                 last_login_at = UTC_TIMESTAMP(), last_login_ip = :ip
             WHERE id = :id',
            ['ip' => $ip, 'id' => (int) $user['id']]
        );

        if (password_needs_rehash($user['password'], PASSWORD_BCRYPT, self::HASH_OPTIONS)) {
            Database::execute(
                'UPDATE users SET password = :password WHERE id = :id',
                ['password' => password_hash((string) $data['password'], PASSWORD_BCRYPT, self::HASH_OPTIONS), 'id' => (int) $user['id']]
            );
        }

        AuthHelper::login($user); // regenerates the session id and the CSRF token
        LoggerHelper::audit('auth.login', 'user', (int) $user['id']);

        $this->redirect(AuthHelper::pullIntended('/dashboard'));
    }

    /** POST /logout */
    public function logout(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            LoggerHelper::audit('auth.logout', 'user', AuthHelper::id());
        }

        AuthHelper::logout();

        // logout() destroys the session; open a clean one so the flash message and CSRF token work.
        session_start();
        session_regenerate_id(true);
        $_SESSION['_created'] = time();
        $_SESSION['_last']    = time();
        $_SESSION['_ua']      = hash('sha256', $request->userAgent());
        $this->flash('info', 'You have been signed out.');

        $this->redirect('/login');
    }

    /* ---------------------------------------------------------------- profile */

    /** GET /profile */
    public function profile(Request $request, array $params): void
    {
        $this->requireLogin();

        $account = Database::fetchOne(
            'SELECT u.id, u.name, u.email, u.phone, u.job_title, u.timezone, u.last_login_at,
                    u.password_changed_at, u.created_at, r.display_name AS role_name
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.id = :id LIMIT 1',
            ['id' => (int) AuthHelper::id()]
        );

        if ($account === null) {
            $this->notFound();
        }

        $this->render('auth/profile', [
            'pageTitle' => 'My profile',
            'account'   => $account,
            'timezones' => DateTimeZone::listIdentifiers(),
        ]);
    }

    /** POST /profile  (name, phone, job title, timezone) */
    public function updateProfile(Request $request, array $params): void
    {
        $this->requireLogin();

        $data = $this->validate([
            'name'      => 'required|string|max:120',
            'phone'     => ['nullable', 'string', 'max:30', 'regex:/^[0-9+().\-\s]+$/'],
            'job_title' => 'nullable|string|max:100',
            'timezone'  => 'required|timezone',
        ], '/profile', ['name' => 'Name', 'phone' => 'Phone', 'job_title' => 'Job title', 'timezone' => 'Timezone']);

        Database::execute(
            'UPDATE users SET name = :name, phone = :phone, job_title = :job_title, timezone = :timezone WHERE id = :id',
            [
                'name'      => $data['name'],
                'phone'     => $data['phone'],
                'job_title' => $data['job_title'],
                'timezone'  => $data['timezone'],
                'id'        => (int) AuthHelper::id(),
            ]
        );

        // Refresh the cached display fields so the new name and timezone show immediately.
        $row = Database::fetchOne(
            'SELECT id, name, email, role, timezone FROM users WHERE id = :id LIMIT 1',
            ['id' => (int) AuthHelper::id()]
        );
        if ($row !== null) {
            AuthHelper::syncFromDatabase($row);
        }

        LoggerHelper::audit('profile.updated', 'user', AuthHelper::id());
        $this->flash('success', 'Your profile has been updated.');
        $this->redirect('/profile');
    }

    /** POST /profile/password */
    public function updatePassword(Request $request, array $params): void
    {
        $this->requireLogin();

        $data = $this->validate([
            'current_password' => 'required|string|max:200',
            'password'         => 'required|string|strong_password|confirmed',
        ], '/profile', [
            'current_password' => 'Current password',
            'password'         => 'New password',
        ]);

        $userId  = (int) AuthHelper::id();
        $current = (string) Database::fetchValue('SELECT password FROM users WHERE id = :id LIMIT 1', ['id' => $userId]);

        if (!password_verify((string) $data['current_password'], $current)) {
            LoggerHelper::audit('auth.password_change_failed', 'user', $userId);
            $this->backWithErrors('/profile', ['current_password' => 'The current password is not correct.']);
        }

        if (password_verify((string) $data['password'], $current)) {
            $this->backWithErrors('/profile', ['password' => 'Choose a password you have not used for this account before.']);
        }

        Database::execute(
            'UPDATE users SET password = :password, password_changed_at = UTC_TIMESTAMP() WHERE id = :id',
            ['password' => password_hash((string) $data['password'], PASSWORD_BCRYPT, self::HASH_OPTIONS), 'id' => $userId]
        );

        // A privilege-sensitive change: rotate the session id and CSRF token.
        session_regenerate_id(true);
        CsrfHelper::regenerate();

        LoggerHelper::audit('auth.password_changed', 'user', $userId);
        $this->flash('success', 'Your password has been changed.');
        $this->redirect('/profile');
    }

    /* ---------------------------------------------------------------- helpers */

    private function requireLogin(): void
    {
        (new AuthMiddleware())->handle();
    }

    /**
     * Count a failed attempt. For a real account this feeds the lockout counter:
     * reaching the limit sets locked_until and resets the counter.
     *
     * @param array<string, mixed>|null $user
     */
    private function recordFailure(?array $user, string $email, string $reason): void
    {
        if ($user !== null && $reason === 'bad_credentials') {
            $max     = max(1, (int) Config::get('security.login_max_attempts', 5));
            $minutes = max(1, (int) Config::get('security.login_lockout_minutes', 15));

            // locked_until is assigned first: MySQL evaluates SET left to right, and it must
            // still see the old attempt counter. Each placeholder is used once (native prepares).
            Database::execute(
                'UPDATE users
                 SET locked_until = IF(failed_login_attempts + 1 >= ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? MINUTE), locked_until),
                     failed_login_attempts = IF(failed_login_attempts + 1 >= ?, 0, failed_login_attempts + 1)
                 WHERE id = ?',
                [$max, $minutes, $max, (int) $user['id']]
            );
        }

        LoggerHelper::audit('auth.login_failed', 'user', $user !== null ? (int) $user['id'] : null, [
            'email'  => substr($email, 0, 190),
            'reason' => $reason,
        ]);
    }

    /** More failures from one address than several legitimate users could cause in the lockout window. */
    private function tooManyFailuresFromIp(string $ip): bool
    {
        $limit   = max(1, (int) Config::get('security.login_max_attempts', 5)) * 4;
        $minutes = max(1, (int) Config::get('security.login_lockout_minutes', 15));

        $count = (int) Database::fetchValue(
            "SELECT COUNT(*) FROM activity_logs
             WHERE action = 'auth.login_failed' AND ip_address = ?
               AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL ? MINUTE)",
            [$ip, $minutes]
        );

        return $count >= $limit;
    }

    private function maintenanceModeOn(): bool
    {
        return SettingsService::systemBool('maintenance_mode', false);
    }
}
