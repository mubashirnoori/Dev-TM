<?php
/**
 * Thrown anywhere in the request cycle to abort with an HTTP status.
 * The Router converts it into a redirect, JSON error, or HTML error page.
 */

declare(strict_types=1);

final class HttpException extends RuntimeException
{
    /**
     * @param array<string, string> $headers Extra response headers (e.g. Allow for 405)
     */
    public function __construct(
        private readonly int $status,
        string $message = '',
        private readonly array $headers = [],
    ) {
        parent::__construct($message !== '' ? $message : self::defaultMessage($status), $status);
    }

    public function status(): int
    {
        return $this->status;
    }

    /** @return array<string, string> */
    public function headers(): array
    {
        return $this->headers;
    }

    private static function defaultMessage(int $status): string
    {
        return match ($status) {
            400 => 'Bad request.',
            401 => 'Authentication required.',
            403 => 'You do not have permission to access this resource.',
            404 => 'The page you requested could not be found.',
            405 => 'Method not allowed.',
            409 => 'This resource is locked and cannot be changed.',
            413 => 'Request body is too large.',
            422 => 'The request could not be processed.',
            419 => 'Your session expired or the security token is invalid. Please reload the page and try again.',
            429 => 'Too many requests. Please slow down.',
            default => 'An unexpected error occurred.',
        };
    }
}
