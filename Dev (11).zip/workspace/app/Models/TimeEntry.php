<?php
/**
 * Completed time entries: timer stops and manual adds.
 *
 * duration_seconds = (end_time - start_time) - (break_minutes * 60).
 * Validation: end_time > start_time and duration_seconds > 0.
 */

declare(strict_types=1);

final class TimeEntry extends Model
{
    public const STATUS_PENDING  = 'Pending';
    public const STATUS_APPROVED = 'Approved';
    public const STATUS_REJECTED = 'Rejected';

    public const STATUSES = [
        self::STATUS_PENDING,
        self::STATUS_APPROVED,
        self::STATUS_REJECTED,
    ];

    protected string $table = 'time_entries';

    protected array $columns = [
        'id', 'user_id', 'project_id', 'task_id', 'schedule_id',
        'start_time', 'end_time', 'started_at', 'ended_at', 'stopped_at',
        'duration_seconds', 'duration', 'break_minutes',
        'description', 'is_billable', 'billable', 'billable_rate', 'status',
        'approved_by', 'approved_at', 'auto_stopped', 'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'user_id', 'project_id', 'task_id', 'schedule_id',
        'start_time', 'end_time', 'started_at', 'ended_at', 'stopped_at',
        'duration_seconds', 'duration', 'break_minutes',
        'description', 'is_billable', 'billable', 'billable_rate', 'status',
        'approved_by', 'approved_at', 'auto_stopped',
    ];

    /** @var array<string, list<string>> logical field => physical column candidates */
    private const COLUMN_ALIASES = [
        'start_time'       => ['start_time', 'started_at', 'start'],
        'end_time'         => ['end_time', 'ended_at', 'stopped_at', 'end'],
        'duration_seconds' => ['duration_seconds', 'duration', 'seconds'],
        'break_minutes'    => ['break_minutes', 'break_mins', 'break'],
        'is_billable'      => ['is_billable', 'billable'],
        'billable_rate'    => ['billable_rate', 'hourly_rate', 'rate'],
        'task_id'          => ['task_id'],
        'schedule_id'      => ['schedule_id'],
        'status'           => ['status'],
        'description'      => ['description', 'notes', 'note'],
        'user_id'          => ['user_id'],
        'project_id'       => ['project_id'],
        'approved_by'      => ['approved_by'],
        'approved_at'      => ['approved_at'],
        'auto_stopped'    => ['auto_stopped'],
        'created_at'       => ['created_at'],
        'updated_at'       => ['updated_at'],
    ];

    /** True when the time_entries table has been installed. */
    public static function installed(): bool
    {
        static $installed = null;

        if ($installed === null) {
            try {
                $installed = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name = 'time_entries'"
                ) > 0;
            } catch (Throwable) {
                $installed = false;
            }
        }

        return $installed;
    }

    /**
     * Create a manual (or timer-stop) entry after validating times.
     *
     * @param array{
     *     user_id: int,
     *     project_id: int,
     *     task_id?: int|null,
     *     schedule_id?: int|null,
     *     start_time: string,
     *     end_time: string,
     *     break_minutes?: int,
     *     description?: string|null,
     *     is_billable?: int|bool,
     *     billable_rate?: float|int|string|null,
     *     status?: string,
     auto_stopped?: int|bool
     * } $data
     * @return array<string, mixed>
     */
    public function createEntry(array $data, bool $checkActiveTimer = true): array
    {
        $validated = $this->validatedPayload($data);
        $userId = (int) $validated['user_id'];
        $startUtc = (string) $validated['start_time'];
        $endUtc = (string) $validated['end_time'];

        return Database::transaction(function (PDO $pdo) use ($validated, $userId, $startUtc, $endUtc, $checkActiveTimer): array {
            $this->lockUser($pdo, $userId);
            $this->assertWritablePeriod($userId, $startUtc);
            if ($checkActiveTimer) {
                $this->assertDailyCapacity($userId, $startUtc, (int) $validated['duration_seconds']);
            }
            $this->assertNoOverlap($userId, $startUtc, $endUtc, null, $checkActiveTimer);

            $payload = $this->filterExisting($validated);
            $id      = $this->create($payload);
            $entry   = $this->findWithRelations($id);

            if ($entry === null) {
                throw new RuntimeException('Time entry could not be saved.');
            }

            return $entry;
        });
    }

    /**
     * Update an existing entry. Approved/locked entries cannot be changed here.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function updateEntry(int $id, array $data): array
    {
        $existing = $this->find($id);
        if ($existing === null) {
            throw new RuntimeException('Time entry was not found.');
        }

        if ($this->isLocked($existing)) {
            throw new RuntimeException('This entry is locked on a submitted or approved timesheet and cannot be changed.');
        }

        $merged = array_merge($existing, $data);
        $payload = $this->validatedPayload([
            'user_id'       => (int) ($merged['user_id'] ?? 0),
            'project_id'    => (int) ($merged['project_id'] ?? 0),
            'task_id'       => $merged['task_id'] ?? null,
            'schedule_id'   => $merged['schedule_id'] ?? null,
            'start_time'    => (string) ($merged['start_time'] ?? $merged['started_at'] ?? ''),
            'end_time'      => (string) ($merged['end_time'] ?? $merged['ended_at'] ?? $merged['stopped_at'] ?? ''),
            'break_minutes' => (int) ($merged['break_minutes'] ?? 0),
            'description'   => $merged['description'] ?? $merged['notes'] ?? null,
            'is_billable'   => $merged['is_billable'] ?? $merged['billable'] ?? 1,
            'billable_rate' => $merged['billable_rate'] ?? 0,
            'status'        => (string) ($merged['status'] ?? self::STATUS_PENDING),
        ]);

        return Database::transaction(function (PDO $pdo) use ($id, $existing, $payload): array {
            $this->lockUser($pdo, (int) $existing['user_id']);
            // Re-check under the transaction lock so an approval cannot race this edit.
            $locked = $this->lockMutableEntry($pdo, $id);
            if ($locked === null) {
                throw new RuntimeException('Time entry was not found.');
            }
            if ((int) $locked['user_id'] !== (int) $existing['user_id']) {
                throw new RuntimeException("You cannot change another user's time entry.");
            }

            $this->assertWritablePeriod((int) $existing['user_id'], (string) $payload['start_time']);
            $this->assertDailyCapacity(
                (int) $existing['user_id'],
                (string) $payload['start_time'],
                (int) $payload['duration_seconds'],
                $id
            );
            $this->assertNoOverlap(
                (int) $existing['user_id'],
                (string) $payload['start_time'],
                (string) $payload['end_time'],
                $id,
                true
            );

            unset($payload['user_id']);
            $this->update($id, $this->filterExisting($payload));

            $entry = $this->findWithRelations($id);
            if ($entry === null) {
                throw new RuntimeException('Time entry could not be updated.');
            }

            return $entry;
        });
    }

    /**
     * Change only the note of an entry. Locked entries (submitted/approved) are refused.
     */
    public function updateDescription(int $id, ?string $description): void
    {
        $existing = $this->find($id);
        if ($existing === null) {
            throw new RuntimeException('Time entry was not found.');
        }

        if ($this->isLocked($existing)) {
            throw new RuntimeException('This entry is locked on a submitted or approved timesheet and cannot be changed.');
        }

        $description = $description === null ? '' : trim($description);
        Database::transaction(function (PDO $pdo) use ($id, $existing, $description): void {
            $locked = $this->lockMutableEntry($pdo, $id);
            if ($locked === null) {
                throw new RuntimeException('Time entry was not found.');
            }
            $this->assertWritablePeriod(
                (int) $existing['user_id'],
                (string) ($existing['start_time'] ?? $existing['started_at'] ?? '')
            );

            $data = $this->filterExisting(['description' => $description === '' ? null : $description]);
            if ($data !== []) {
                $this->update($id, $data);
            }
        });
    }

    /**
     * Delete an entry unless it is locked on an approved timesheet.
     *
     * @param array<string, mixed>|null $existing
     */
    public function deleteEntry(int $id, ?array $existing = null): bool
    {
        $row = $existing ?? $this->find($id);
        if ($row === null) {
            return false;
        }

        if ($this->isLocked($row)) {
            throw new RuntimeException('This entry is locked on a submitted or approved timesheet and cannot be deleted.');
        }

        $startUtc = (string) ($row['start_time'] ?? $row['started_at'] ?? '');
        $userId = (int) ($row['user_id'] ?? 0);

        return Database::transaction(function (PDO $pdo) use ($id, $userId, $startUtc): bool {
            $this->lockMutableEntry($pdo, $id);
            $this->assertWritablePeriod($userId, $startUtc);
            return $this->delete($id);
        });
    }

    /**
     * Lock an entry for mutation and enforce the authoritative timesheet lock.
     * A Submitted/Approved timesheet locks only entries linked through
     * timesheet_entries; it does not lock the user's entire week.
     *
     * @return array<string, mixed>|null
     */
    private function lockMutableEntry(PDO $pdo, int $id): ?array
    {
        $row = Database::fetchOne(
            'SELECT * FROM time_entries WHERE id = :id LIMIT 1 FOR UPDATE',
            ['id' => $id]
        );
        if ($row === null) {
            return null;
        }

        if (class_exists('Timesheet') && Timesheet::installed()) {
            $locked = Database::fetchOne(
                "SELECT t.id, t.status
                 FROM timesheet_entries tse
                 INNER JOIN timesheets t ON t.id = tse.timesheet_id
                 WHERE tse.time_entry_id = :id
                   AND t.status IN ('Submitted','Approved')
                 LIMIT 1",
                ['id' => $id]
            );
            if ($locked !== null) {
                throw new RuntimeException('This entry is locked on a submitted or approved timesheet and cannot be changed.');
            }
        }

        return $row;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findWithRelations(int $id): ?array
    {
        if ($id < 1 || !self::installed()) {
            return null;
        }

        return Database::fetchOne(
            $this->selectSql() . ' WHERE te.id = :id LIMIT 1',
            ['id' => $id]
        );
    }

    /**
     * List entries with filters: date range, project, task, billable, user.
     *
     * @param array{
     *     from?: string,
     *     to?: string,
     *     project_id?: int,
     *     task_id?: int,
     *     billable?: string|int|null,
     *     user_id?: int|null,
     *     status?: string,
     auto_stopped?: int|bool
     * } $filters
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, totals: array{seconds: int, billable_seconds: int, count: int}}
     */
    public function listFiltered(array $filters, int $page, int $perPage): array
    {
        $perPage = min(100, max(1, $perPage));
        [$whereSql, $params] = $this->filterClause($filters);

        $total = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM time_entries te INNER JOIN projects p ON p.id = te.project_id' . $whereSql,
            $params
        );

        $pages = max(1, (int) ceil($total / $perPage));
        $page  = min(max(1, $page), $pages);

        $durationCol = $this->physicalName('duration_seconds');
        $billableCol = $this->physicalName('is_billable');
        $durationExpr = $durationCol !== null ? "te.`{$durationCol}`" : '0';
        $billableExpr = $billableCol !== null ? "te.`{$billableCol}` = 1" : '0';

        $sum = Database::fetchOne(
            "SELECT COALESCE(SUM({$durationExpr}), 0) AS seconds,
                    COALESCE(SUM(CASE WHEN {$billableExpr} THEN {$durationExpr} ELSE 0 END), 0) AS billable_seconds
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id" . $whereSql,
            $params
        ) ?? ['seconds' => 0, 'billable_seconds' => 0];

        $params['limit']  = $perPage;
        $params['offset'] = ($page - 1) * $perPage;

        $orderCol = $this->physicalName('start_time') ?? 'id';

        $items = Database::fetchAll(
            $this->selectSql() . $whereSql . "
             ORDER BY te.`{$orderCol}` DESC, te.id DESC
             LIMIT :limit OFFSET :offset",
            $params
        );

        return [
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => $pages,
            'totals'   => [
                'seconds'          => (int) ($sum['seconds'] ?? 0),
                'billable_seconds' => (int) ($sum['billable_seconds'] ?? 0),
                'count'            => $total,
            ],
        ];
    }

    /**
     * Projects the user may track time against (open statuses, membership).
     *
     * @return list<array<string, mixed>>
     */
    public function trackableProjects(int $userId, bool $viewAll): array
    {
        $where  = ["p.status IN ('Planning','Active','On Hold')"];
        $params = [];

        // Regular users may start a timer only on Projects they are explicitly
        // assigned to. Public projects, project creators and managers do not
        // implicitly make a project trackable.
        if (!$viewAll) {
            $where[] = 'EXISTS (
                SELECT 1 FROM project_members pm
                WHERE pm.project_id = p.id AND pm.user_id = :uid_member
            )';
            $params['uid_member'] = $userId;
        }

        return Database::fetchAll(
            'SELECT p.id, p.name, p.project_code, p.is_billable, p.hourly_rate, c.name AS client_name
             FROM projects p
             INNER JOIN clients c ON c.id = p.client_id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY p.name ASC',
            $params
        );
    }

    /**
     * Tasks a user may select while tracking time.
     *
     * A Task must be explicitly assigned to the user. A blank Task remains
     * available in the UI so a user can track time against the Project and
     * enter a description instead.
     *
     * @return list<array{id: int, name: string}>
     */
    public function tasksForProject(int $projectId, ?int $userId = null, bool $viewAll = false): array
    {
        if (!Task::installed()) {
            return [];
        }

        $where = ["t.project_id = :project_id", "t.status <> 'Done'"];
        $params = ['project_id' => $projectId];

        if (!$viewAll && $userId !== null && $userId > 0) {
            if (Task::hasColumn('assigned_to')) {
                $where[] = '(t.assigned_to = :task_uid OR EXISTS (
                    SELECT 1 FROM task_assignees ta
                    WHERE ta.task_id = t.id AND ta.user_id = :task_uid_assignee
                ))';
                $params['task_uid'] = $userId;
                $params['task_uid_assignee'] = $userId;
            } else {
                $where[] = 'EXISTS (
                    SELECT 1 FROM task_assignees ta
                    WHERE ta.task_id = t.id AND ta.user_id = :task_uid_assignee
                )';
                $params['task_uid_assignee'] = $userId;
            }
        }

        $rows = Database::fetchAll(
            'SELECT t.id, t.name FROM tasks t
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY t.name ASC',
            $params
        );

        return array_map(static fn (array $row): array => [
            'id'   => (int) $row['id'],
            'name' => (string) $row['name'],
        ], $rows);
    }

    /**
     * An entry is locked when it is Approved, or locked into a submitted/approved timesheet.
     *
     * @param array<string, mixed> $row
     */
    public function isLocked(array $row): bool
    {
        if ((string) ($row['status'] ?? '') === self::STATUS_APPROVED) {
            return true;
        }

        if (isset($row['timesheet_id']) && (int) $row['timesheet_id'] > 0) {
            return true;
        }

        $id = (int) ($row['id'] ?? 0);
        if ($id < 1 || !class_exists('Timesheet') || !Timesheet::installed()) {
            return false;
        }

        try {
            return (int) Database::fetchValue(
                "SELECT COUNT(*) FROM timesheet_entries tse
                 INNER JOIN timesheets t ON t.id = tse.timesheet_id
                 WHERE tse.time_entry_id = :id
                   AND t.status IN ('Submitted','Approved')",
                ['id' => $id]
            ) > 0;
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * duration_seconds = (end - start) - (break_minutes * 60).
     *
     * @return array{duration: int, start: string, end: string}
     */
    public static function computeDuration(string $startUtc, string $endUtc, int $breakMinutes): array
    {
        $startTs = strtotime($startUtc . ' UTC');
        $endTs   = strtotime($endUtc . ' UTC');

        if ($startTs === false || $endTs === false) {
            throw new InvalidArgumentException('Start and end times must be valid.');
        }

        if ($endTs <= $startTs) {
            throw new InvalidArgumentException('End time must be after start time.');
        }

        $breakMinutes = max(0, $breakMinutes);
        $duration     = ($endTs - $startTs) - ($breakMinutes * 60);
        $duration     = WorkspacePolicy::roundSeconds($duration);

        if ($duration <= 0) {
            throw new InvalidArgumentException('Duration must be greater than zero after breaks and rounding.');
        }

        return [
            'duration' => $duration,
            'start'    => gmdate('Y-m-d H:i:s', $startTs),
            'end'      => gmdate('Y-m-d H:i:s', $endTs),
        ];
    }

    /**
     * When lock_time_enabled is on, a Submitted/Approved timesheet for the
     * approval period that contains $startUtc blocks new writes on that day.
     * When off, only entries linked through timesheet_entries stay locked.
     */
    public function assertWritablePeriod(int $userId, string $startUtc): void
    {
        if ($userId < 1 || $startUtc === '' || !FeatureFlagsHelper::lockTimeEnabled()) {
            return;
        }

        if (!class_exists('Timesheet') || !Timesheet::installed()) {
            return;
        }

        if ((new Timesheet())->isPeriodLocked($userId, $startUtc)) {
            throw new HttpException(409, 'This period is locked. Time on a submitted or approved timesheet cannot be changed.');
        }
    }

    /**
     * Reject when the local calendar day would exceed workspace daily_capacity.
     */
    public function assertDailyCapacity(int $userId, string $startUtc, int $newSeconds, ?int $ignoreId = null): void
    {
        if ($userId < 1 || $startUtc === '' || $newSeconds < 1 || !self::installed()) {
            return;
        }

        $limit = WorkspacePolicy::dailyCapacitySeconds();
        $used = $this->secondsOnLocalDay($userId, $startUtc, $ignoreId);
        if ($used + $newSeconds <= $limit) {
            return;
        }

        $hours = WorkspacePolicy::dailyCapacityHours();
        $label = rtrim(rtrim(number_format($hours, 2, '.', ''), '0'), '.');
        throw new HttpException(
            422,
            'This entry exceeds the daily work capacity of ' . $label . ' hours.'
        );
    }

    /**
     * Sum duration_seconds for the viewer-local calendar day of $startUtc.
     */
    public function secondsOnLocalDay(int $userId, string $startUtc, ?int $ignoreId = null): int
    {
        if ($userId < 1 || $startUtc === '' || !self::installed()) {
            return 0;
        }

        $startCol = self::column('start_time');
        $durCol = self::column('duration_seconds');
        if ($startCol === null || $durCol === null) {
            return 0;
        }

        try {
            $zone = new DateTimeZone(FormatHelper::displayTimezone());
            $moment = new DateTimeImmutable($startUtc, new DateTimeZone('UTC'));
            $dayStart = $moment->setTimezone($zone)->setTime(0, 0, 0);
            $dayEnd = $dayStart->modify('+1 day');
            $fromUtc = $dayStart->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
            $toUtc = $dayEnd->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return 0;
        }

        $sql = "SELECT COALESCE(SUM(`{$durCol}`), 0)
                FROM time_entries
                WHERE user_id = :user_id
                  AND `{$startCol}` >= :from_utc
                  AND `{$startCol}` < :to_utc";
        $params = [
            'user_id'  => $userId,
            'from_utc' => $fromUtc,
            'to_utc'   => $toUtc,
        ];
        if ($ignoreId !== null && $ignoreId > 0) {
            $sql .= ' AND id <> :ignore_id';
            $params['ignore_id'] = $ignoreId;
        }

        try {
            return (int) Database::fetchValue($sql, $params);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return 0;
        }
    }

    /**
     * Reject overlapping completed work for the same user. A time entry represents
     * one continuous worked interval; paused/break time is not treated as another
     * task. To switch tasks, stop the current timer and start the next one.
     *
     * Boundary-touching entries are allowed: 01:00-01:30 followed by 01:30-02:00
     * is valid, while 01:00-02:00 overlapping 01:30-02:15 is not.
     */
    /**
     * Find a completed-entry overlap for a user. The caller must already hold the
     * per-user write lock when this is part of a write transaction.
     *
     * @return array<string, mixed>|null
     */
    public function findEntryOverlap(int $userId, string $startUtc, string $endUtc, ?int $ignoreId = null, bool $forUpdate = false): ?array
    {
        if ($userId < 1) {
            return null;
        }

        $startTs = strtotime($startUtc . ' UTC');
        $endTs   = strtotime($endUtc . ' UTC');
        if ($startTs === false || $endTs === false || $endTs <= $startTs || !self::installed()) {
            return null;
        }

        $startCol = self::column('start_time');
        $endCol   = self::column('end_time');
        if ($startCol === null || $endCol === null) {
            return null;
        }

        $sql = "SELECT id, `{$startCol}` AS start_time, `{$endCol}` AS end_time
                FROM time_entries
                WHERE user_id = :user_id
                  AND `{$startCol}` < :new_end
                  AND `{$endCol}` > :new_start";
        $params = [
            'user_id'   => $userId,
            'new_start' => $startUtc,
            'new_end'   => $endUtc,
        ];
        if ($ignoreId !== null && $ignoreId > 0) {
            $sql .= ' AND id <> :ignore_id';
            $params['ignore_id'] = $ignoreId;
        }
        $sql .= ' ORDER BY `' . $startCol . '` ASC, id ASC LIMIT 1';
        if ($forUpdate) {
            $sql .= ' FOR UPDATE';
        }

        return Database::fetchOne($sql, $params);
    }

    /**
     * Find the user's active timer as an interval from its started_at to server-now.
     * This intentionally treats the whole active_timers row as occupied time, including
     * a paused timer, so a manual entry cannot be placed inside an unresolved timer row.
     *
     * @return array<string, mixed>|null
     */
    public function findActiveTimerOverlap(int $userId, string $startUtc, string $endUtc, bool $forUpdate = false): ?array
    {
        if ($userId < 1 || !self::installed()) {
            return null;
        }

        $startTs = strtotime($startUtc . ' UTC');
        $endTs   = strtotime($endUtc . ' UTC');
        if ($startTs === false || $endTs === false || $endTs <= $startTs) {
            return null;
        }

        $nowUtc = gmdate('Y-m-d H:i:s', time());
        $sql = 'SELECT id, started_at, :now_utc AS active_end
                FROM active_timers
                WHERE user_id = :user_id
                  AND started_at < :new_end
                  AND :now_utc_2 > :new_start
                LIMIT 1';
        if ($forUpdate) {
            $sql .= ' FOR UPDATE';
        }

        return Database::fetchOne($sql, [
            'user_id'    => $userId,
            'new_start'  => $startUtc,
            'new_end'    => $endUtc,
            'now_utc'    => $nowUtc,
            'now_utc_2'  => $nowUtc,
        ]);
    }

    /**
     * Reject overlapping completed work and, for manual/edit writes, the user's
     * still-active timer. All callers that mutate entries hold the per-user lock.
     */
    private function assertNoOverlap(
        int $userId,
        string $startUtc,
        string $endUtc,
        ?int $ignoreId,
        bool $checkActiveTimer = true
    ): void {
        $conflict = $this->findEntryOverlap($userId, $startUtc, $endUtc, $ignoreId, true);
        if ($conflict !== null) {
            $existingStart = FormatHelper::datetime((string) $conflict['start_time'], 'M j, Y H:i');
            $existingEnd   = FormatHelper::datetime((string) $conflict['end_time'], 'H:i');
            throw new InvalidArgumentException(
                'This time overlaps an existing entry (' . $existingStart . '–' . $existingEnd . '). Stop the earlier task first or choose a non-overlapping time.'
            );
        }

        if ($checkActiveTimer) {
            $active = $this->findActiveTimerOverlap($userId, $startUtc, $endUtc, true);
            if ($active !== null) {
                $activeStart = FormatHelper::datetime((string) $active['started_at'], 'M j, Y H:i');
                $activeEnd   = FormatHelper::datetime((string) $active['active_end'], 'H:i');
                throw new InvalidArgumentException(
                    'This time overlaps your active timer (' . $activeStart . '–' . $activeEnd . '). Stop or resolve the active timer first.'
                );
            }
        }
    }

    /** Serialize time-entry writes for one user so overlap checks cannot race. */
    private function lockUser(PDO $pdo, int $userId): void
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A valid user is required.');
        }

        $stmt = $pdo->prepare('SELECT id FROM users WHERE id = :user_id LIMIT 1 FOR UPDATE');
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        if ($stmt->fetchColumn() === false) {
            throw new InvalidArgumentException('User account was not found.');
        }
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function validatedPayload(array $data): array
    {
        $userId    = (int) ($data['user_id'] ?? 0);
        $projectId = (int) ($data['project_id'] ?? 0);
        $taskId    = isset($data['task_id']) && (int) $data['task_id'] > 0 ? (int) $data['task_id'] : null;
        $scheduleId = isset($data['schedule_id']) && (int) $data['schedule_id'] > 0 ? (int) $data['schedule_id'] : null;
        $break     = max(0, (int) ($data['break_minutes'] ?? 0));
        $start     = (string) ($data['start_time'] ?? '');
        $end       = (string) ($data['end_time'] ?? '');
        $computed  = self::computeDuration($start, $end, $break);

        $description = trim((string) ($data['description'] ?? ''));
        $description = $description !== '' ? mb_substr($description, 0, 255, 'UTF-8') : null;

        $status = (string) ($data['status'] ?? self::STATUS_PENDING);
        if (!in_array($status, self::STATUSES, true)) {
            $status = self::STATUS_PENDING;
        }

        $isBillable = !empty($data['is_billable']) && (int) $data['is_billable'] !== 0 ? 1 : 0;
        $rate       = isset($data['billable_rate']) ? (float) $data['billable_rate'] : 0.0;

        return [
            'user_id'          => $userId,
            'project_id'       => $projectId,
            'task_id'          => $taskId,
            'schedule_id'      => $scheduleId,
            'start_time'       => $computed['start'],
            'end_time'         => $computed['end'],
            'duration_seconds' => $computed['duration'],
            'break_minutes'    => $break,
            'description'      => $description,
            'is_billable'      => $isBillable,
            'billable_rate'    => max(0, $rate),
            'status'           => $status,
            'auto_stopped'     => !empty($data['auto_stopped']) ? 1 : 0,
        ];
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function filterClause(array $filters): array
    {
        $where  = ['1 = 1'];
        $params = [];

        $userId = (int) ($filters['user_id'] ?? 0);
        if ($userId > 0) {
            $where[]           = 'te.user_id = :user_id';
            $params['user_id'] = $userId;
        }

        $projectId = (int) ($filters['project_id'] ?? 0);
        if ($projectId > 0) {
            $where[]              = 'te.project_id = :project_id';
            $params['project_id'] = $projectId;
        }

        $taskId = (int) ($filters['task_id'] ?? 0);
        if ($taskId > 0) {
            $where[]           = 'te.task_id = :task_id';
            $params['task_id'] = $taskId;
        }

        $startCol = $this->physicalName('start_time');
        $from = (string) ($filters['from'] ?? '');
        if ($startCol !== null && $from !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) === 1) {
            $fromUtc = FormatHelper::toUtc($from . ' 00:00:00');
            if ($fromUtc !== null) {
                $where[]           = "te.`{$startCol}` >= :from_at";
                $params['from_at'] = $fromUtc;
            }
        }

        $to = (string) ($filters['to'] ?? '');
        if ($startCol !== null && $to !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $to) === 1) {
            $toUtc = FormatHelper::toUtc($to . ' 23:59:59');
            if ($toUtc !== null) {
                $where[]         = "te.`{$startCol}` <= :to_at";
                $params['to_at'] = $toUtc;
            }
        }

        $billableCol = $this->physicalName('is_billable');
        $billable = $filters['billable'] ?? '';
        if ($billableCol !== null && ($billable === '1' || $billable === 1 || $billable === 'billable')) {
            $where[] = "te.`{$billableCol}` = 1";
        } elseif ($billableCol !== null && ($billable === '0' || $billable === 0 || $billable === 'nonbillable')) {
            $where[] = "te.`{$billableCol}` = 0";
        }

        $status = (string) ($filters['status'] ?? '');
        if ($status !== '' && in_array($status, self::STATUSES, true)) {
            $where[]          = 'te.status = :status';
            $params['status'] = $status;
        }

        $viewerId = (int) ($filters['viewer_id'] ?? 0);
        if ($viewerId > 0 && !empty($filters['regular_visibility'])) {
            // regular_user_time_visibility is query-scoped so a crafted user_id cannot widen the list.
            [$visSql, $visParams] = WorkspacePolicy::regularTimeVisibilityClause($viewerId);
            $where[] = $visSql;
            $params = array_merge($params, $visParams);
        }

        return [' WHERE ' . implode(' AND ', $where), $params];
    }

    /**
     * Columns that actually exist on time_entries (older installs may omit schedule_id).
     *
     * @return list<string>
     */
    public static function physicalColumns(): array
    {
        static $columns = null;

        if ($columns === null) {
            try {
                $rows = Database::fetchAll(
                    "SELECT COLUMN_NAME AS name FROM information_schema.columns
                     WHERE table_schema = DATABASE() AND table_name = 'time_entries'"
                );
                $columns = array_values(array_map(
                    static fn (array $row): string => (string) $row['name'],
                    $rows
                ));
            } catch (Throwable) {
                $columns = [];
            }
        }

        return $columns;
    }

    public static function hasColumn(string $name): bool
    {
        return in_array($name, self::physicalColumns(), true);
    }

    /** Physical column for a logical field, or null when the live table has none. */
    public static function column(string $logical): ?string
    {
        foreach (self::COLUMN_ALIASES[$logical] ?? [$logical] as $candidate) {
            if (self::hasColumn($candidate)) {
                return $candidate;
            }
        }

        return self::hasColumn($logical) ? $logical : null;
    }

    private function physicalName(string $logical): ?string
    {
        return self::column($logical);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function filterExisting(array $data): array
    {
        $mapped = [];
        foreach ($data as $key => $value) {
            $physical = $this->physicalName($key);
            if ($physical !== null) {
                $mapped[$physical] = $value;
            }
        }

        return $mapped;
    }

    private function selectSql(): string
    {
        $wanted = [
            'id', 'user_id', 'project_id', 'task_id', 'schedule_id',
            'start_time', 'end_time', 'duration_seconds', 'break_minutes',
            'description', 'is_billable', 'billable_rate', 'status',
            'approved_by', 'approved_at', 'auto_stopped', 'created_at', 'updated_at',
        ];
        $select = [];
        foreach ($wanted as $logical) {
            $physical = $this->physicalName($logical);
            $select[] = $physical !== null
                ? "te.`{$physical}` AS `{$logical}`"
                : "NULL AS `{$logical}`";
        }

        $useTasks = Task::installed() && $this->physicalName('task_id') !== null;
        $taskSelect = $useTasks ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskJoin   = $useTasks ? 'LEFT JOIN tasks tk ON tk.id = te.task_id' : '';

        $approverCol = $this->physicalName('approved_by');
        $approverSelect = $approverCol !== null ? 'approver.name AS approved_by_name' : 'NULL AS approved_by_name';
        $approverJoin   = $approverCol !== null ? "LEFT JOIN users approver ON approver.id = te.`{$approverCol}`" : '';

        $sheetSelect = 'NULL AS timesheet_id, NULL AS timesheet_status';
        $sheetJoin   = '';
        if (class_exists('Timesheet') && Timesheet::installed()) {
            $sheetSelect = 'ts.id AS timesheet_id, ts.status AS timesheet_status';
            $sheetJoin   = "LEFT JOIN timesheet_entries tse ON tse.time_entry_id = te.id
                LEFT JOIN timesheets ts ON ts.id = tse.timesheet_id AND ts.status IN ('Submitted','Approved')";
        }

        return 'SELECT ' . implode(', ', $select) . ",
                       p.name AS project_name, p.project_code,
                       {$taskSelect},
                       u.name AS user_name,
                       {$approverSelect},
                       {$sheetSelect}
                FROM time_entries te
                INNER JOIN projects p ON p.id = te.project_id
                INNER JOIN users u ON u.id = te.user_id
                {$taskJoin}
                {$approverJoin}
                {$sheetJoin}";
    }
}
