<?php
/**
 * Application configuration.
 *
 * Loaded once by public/index.php. Every value can be overridden with an
 * environment variable (Apache SetEnv, php-fpm env[], or .env loaded by your
 * host) so secrets never need to be committed to version control.
 */

declare(strict_types=1);

$env = static fn (string $key, mixed $default = null): mixed =>
    getenv($key) !== false ? getenv($key) : $default;

return [
    'app' => [
        'name'          => 'TimeTrack',
        // 'production' hides error details from users. Use 'development' on XAMPP only.
        'env'           => $env('APP_ENV', 'production'),
        'debug'         => filter_var($env('APP_DEBUG', false), FILTER_VALIDATE_BOOLEAN),
        // Empty = auto-detect from the front controller path. Set APP_BASE_URL=/Dev when hosted in a subfolder.
        'base_url'      => $env('APP_BASE_URL', ''),
        // Process timezone for PHP date functions. Storage is ALWAYS UTC.
        // Display timezone is settings.default_timezone, overridden by users.timezone.
        'timezone'      => 'UTC',
        // Optional Host header allow-list (blocks Host header injection). Empty = allow any.
        // Example: ['tracker.example.com', 'localhost']
        'allowed_hosts' => [],
        // Only set true when running behind a reverse proxy YOU control (Cloudflare, nginx, load balancer).
        'trust_proxy'   => filter_var($env('APP_TRUST_PROXY', false), FILTER_VALIDATE_BOOLEAN),
    ],

    'session' => [
        'name'             => 'TTSESSID',
        'idle_timeout'     => 1800,   // seconds of inactivity before an authenticated session is dropped
        'absolute_timeout' => 28800,  // hard cap on session age (8 hours) regardless of activity
        // Private session directory: shared hosts otherwise share /tmp between all customers.
        'save_path'        => STORAGE_PATH . '/sessions',
        // null = auto (Secure flag whenever the request arrived over HTTPS).
        'cookie_secure'    => null,
        'cookie_samesite'  => 'Lax',
    ],

    'security' => [
        // Verify Origin/Referer host on every state-changing request (defence in depth on top of CSRF tokens).
        'check_origin' => true,
        // Bootstrap is loaded from jsDelivr until you self-host it (recommended for production).
        'csp' => "default-src 'self'; "
               . "script-src 'self' https://cdn.jsdelivr.net; "
               . "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
               . "img-src 'self' data:; "
               . "font-src 'self' https://cdn.jsdelivr.net; "
               . "connect-src 'self'; "
               . "frame-ancestors 'self'; base-uri 'self'; form-action 'self'",
        // Failed-login throttling (used by the auth controller in Phase 3).
        'login_max_attempts'   => 5,
        'login_lockout_minutes' => 15,
    ],
];