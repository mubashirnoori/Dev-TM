<?php
/**
 * Prints declared routes plus expected Step 20 results per role, including client.
 * Integrity: a client account must 403 on timer/timesheet/admin URLs even if
 * the sidebar hides them.
 */
declare(strict_types=1);

$routesFile = dirname(__DIR__) . '/routes/web.php';
$text = file_get_contents($routesFile);
if ($text === false) {
    fwrite(STDERR, "Unable to read routes/web.php\n");
    exit(1);
}

preg_match_all('/\$router->(get|post|put|patch|delete)\(\s*\'([^\']+)\'/i', $text, $m, PREG_SET_ORDER);

$clientBlockedPrefixes = [
    '/time',
    '/timesheets',
    '/users',
    '/workspace',
    '/settings',
    '/import',
    '/agent',
    '/clients',
    '/team',
    '/admin/health',
    '/schedule',
    '/timer',
];

$clientAllowedExact = [
    '/',
    '/health',
    '/login',
    '/logout',
    '/profile',
    '/profile/password',
    '/dashboard',
    '/notifications/read',
    '/notifications/unread',
    '/notifications/read-all',
    '/projects',
    '/reports',
];

$clientWriteAllowed = [
    '/logout',
    '/profile',
    '/profile/password',
    '/notifications/read',
    '/notifications/read-all',
];

$expectClient = static function (string $method, string $path) use ($clientBlockedPrefixes, $clientAllowedExact, $clientWriteAllowed): string {
    $method = strtoupper($method);
    if ($path === '/login' || $path === '/health' || $path === '/') {
        return $method === 'GET' || $path === '/login' ? 'ok (public)' : 'ok (public)';
    }
    foreach ($clientBlockedPrefixes as $prefix) {
        if ($path === $prefix || str_starts_with($path, $prefix . '/') || str_starts_with($path, $prefix . '{')) {
            return '403';
        }
    }
    if ($method !== 'GET' && $method !== 'HEAD') {
        foreach ($clientWriteAllowed as $allowed) {
            if ($path === $allowed || str_starts_with($path, '/notifications/')) {
                return 'ok';
            }
        }
        if (str_starts_with($path, '/api/agent/')) {
            return '403';
        }
        return '403';
    }
    if ($path === '/projects/create' || preg_match('#^/projects/.+/edit$#', $path) === 1) {
        return '403';
    }
    if (in_array($path, $clientAllowedExact, true) || str_starts_with($path, '/projects/') || str_starts_with($path, '/notifications/')) {
        return 'ok (own clients only)';
    }
    if ($path === '/reports/export.csv') {
        return '403';
    }
    return 'review';
};

echo "METHOD\tPATH\tCLIENT\n";
foreach ($m as $row) {
    $method = strtoupper($row[1]);
    $path = $row[2];
    echo $method . "\t" . $path . "\t" . $expectClient($method, $path) . PHP_EOL;
}

echo PHP_EOL . "Logged-out: /health = ok JSON; other app routes redirect to /login.\n";
echo "Employee: /users /settings /workspace /admin/health /reports/export.csv /timesheets/team = 403.\n";
echo "Manager: /settings /workspace /admin/health /users (manage) follow controller RBAC; cannot self-approve.\n";
echo "Admin: /admin/health = details; /health stays public ok/not ok only.\n";
