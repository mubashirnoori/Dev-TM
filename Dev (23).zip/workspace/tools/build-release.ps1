# Build a clean TimeTrack release zip (no sessions, logs, uploads, SQL dumps, or timer/timer).
param(
    [string]$Out = ""
)

$Root = Split-Path -Parent $PSScriptRoot
if ($Out -eq "") {
    $stamp = Get-Date -Format "yyyyMMdd"
    $Out = Join-Path (Split-Path -Parent $Root) "TimeTrack-release-$stamp.zip"
}

$exclude = @(
    '\.git',
    'storage\\sessions\\',
    'storage\\logs\\',
    'public\\uploads\\',
    '\.log$',
    'sess_',
    'u897128490',
    'phase17_sync_live_schema\.sql',
    '\\_dev\\',
    'app\\Views\\timer\\timer\\',
    'database\\phase13\\phase13\\',
    '\.zip$'
)

Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path $Out) { Remove-Item $Out }
$zip = [System.IO.Compression.ZipFile]::Open($Out, 'Create')
Get-ChildItem -Path $Root -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($Root.Length + 1)
    $skip = $false
    foreach ($pat in $exclude) {
        if ($rel -match $pat) { $skip = $true; break }
    }
    if (-not $skip) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, ($rel -replace '\\', '/')) | Out-Null
    }
}
$zip.Dispose()
Write-Host "Wrote $Out"
