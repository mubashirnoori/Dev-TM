#!/usr/bin/env bash
# Build a clean TimeTrack release zip (no sessions, logs, uploads, SQL dumps, or timer/timer).

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date -u +%Y%m%d)"
OUT="${1:-$ROOT/../TimeTrack-release-$STAMP.zip}"

cd "$ROOT"

zip -r "$OUT" . \
  -x '*.git*' \
  -x 'storage/sessions/*' \
  -x 'storage/logs/*' \
  -x 'public/uploads/*' \
  -x '*.log' \
  -x 'sess_*' \
  -x '*u897128490*' \
  -x '*phase17_sync_live_schema.sql' \
  -x '_dev/*' \
  -x 'app/Views/timer/timer/*' \
  -x 'database/phase13/phase13/*' \
  -x 'storage/maintenance.flag' \
  -x '*.zip'

echo "Wrote $OUT"
echo "Verify: unzip -l \"$OUT\" | grep -E 'sess_|\\.log$|timer/timer/|_dev/|u897128490|phase17_sync' && echo FAIL || echo OK"
