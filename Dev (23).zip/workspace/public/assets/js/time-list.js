/*
 * Time page: reload the entries list, totals and submit modal in place.
 * Fetches the current page (same filters/page number) and swaps only the
 * [data-time-region] blocks, keeping expanded groups open.
 */
(function () {
    'use strict';

    if (!document.querySelector('[data-time-region="entries"]')) { return; }

    var loading = false;
    var queued = false;

    function openGroups() {
        return Array.prototype.map.call(
            document.querySelectorAll('[data-time-group-toggle][aria-expanded="true"]'),
            function (b) { return b.getAttribute('data-time-group-toggle'); }
        );
    }

    function restoreGroups(ids) {
        ids.forEach(function (id) {
            var btn = document.querySelector('[data-time-group-toggle="' + id + '"]');
            var panel = document.getElementById(id + '-chunks');
            if (!btn || !panel) { return; }
            panel.hidden = false;
            btn.setAttribute('aria-expanded', 'true');
            btn.classList.add('is-open');
            var group = btn.closest('.time-group');
            if (group) { group.classList.add('is-open'); }
        });
    }

    function refreshEntries() {
        if (loading) { queued = true; return; }
        loading = true;

        fetch(window.location.href, {
            headers: { 'Accept': 'text/html' },
            cache: 'no-store',
            credentials: 'same-origin'
        }).then(function (response) {
            if (!response.ok) { throw new Error('HTTP ' + response.status); }
            return response.text();
        }).then(function (html) {
            var doc = new DOMParser().parseFromString(html, 'text/html');
            var open = openGroups();
            var modalOpen = !!document.querySelector('#submitWorkModal.show');

            ['toolbar', 'kpis', 'entries', 'submit-modal'].forEach(function (name) {
                if (name === 'submit-modal' && modalOpen) { return; }
                var active = document.activeElement;
                if (name === 'entries' && active && active.matches && active.matches('[data-time-desc]') &&
                    active.value !== (active.getAttribute('data-original') || '')) { return; }
                var fresh = doc.querySelector('[data-time-region="' + name + '"]');
                var current = document.querySelector('[data-time-region="' + name + '"]');
                if (fresh && current) { current.replaceWith(fresh); }
            });

            restoreGroups(open);
            window.dispatchEvent(new Event('tt:entries-refreshed'));
        }).catch(function () {
            /* keep the current list; the next change or a manual refresh recovers */
        }).finally(function () {
            loading = false;
            if (queued) { queued = false; refreshEntries(); }
        });
    }

    window.addEventListener('tt:entries-changed', refreshEntries);

    /* ---- inline description editing ---------------------------------- */
    function setValue(input, value) {
        input.value = value;
        input.setAttribute('data-original', value);
    }

    function syncGroupInput(group) {
        if (!group) { return; }
        var main = group.querySelector('.time-row-main [data-time-desc]');
        var chunks = group.querySelectorAll('.time-row-chunk [data-time-desc]');
        if (!main || !chunks.length) { return; }
        var values = Array.prototype.map.call(chunks, function (c) { return c.value; });
        var same = values.every(function (v) { return v === values[0]; });
        setValue(main, same ? values[0] : '');
        main.placeholder = same ? 'Add description' : 'Multiple descriptions';
    }

    function saveDescription(input) {
        var original = input.getAttribute('data-original') || '';
        var value = input.value.trim();
        if (value === original && input.value === original) { return; }

        var ids = (input.getAttribute('data-ids') || '').split(',').map(function (v) { return parseInt(v, 10); }).filter(Boolean);
        if (!ids.length) { return; }

        input.classList.remove('is-error', 'is-saved');
        input.classList.add('is-saving');
        input.readOnly = true;

        fetch(input.getAttribute('data-url'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ description: value, ids: ids })
        }).then(function (response) {
            return response.text().then(function (raw) {
                var data = {};
                try { data = raw ? JSON.parse(raw) : {}; } catch (e) { data = {}; }
                data._ok = response.ok;
                return data;
            });
        }).then(function (data) {
            input.classList.remove('is-saving');
            input.readOnly = false;
            if (!data._ok || !data.ok) {
                input.classList.add('is-error');
                window.alert(data.message || 'Could not save the description.');
                return;
            }
            setValue(input, value);
            (data.saved || ids).forEach(function (id) {
                document.querySelectorAll('[data-time-desc][data-ids="' + id + '"]').forEach(function (chunk) {
                    if (chunk !== input) { setValue(chunk, value); }
                });
            });
            syncGroupInput(input.closest('.time-group'));
            input.classList.add('is-saved');
            window.setTimeout(function () { input.classList.remove('is-saved'); }, 1200);
        }).catch(function () {
            input.classList.remove('is-saving');
            input.readOnly = false;
            input.classList.add('is-error');
            window.alert('Could not save the description.');
        });
    }

    document.addEventListener('change', function (event) {
        var input = event.target.closest ? event.target.closest('[data-time-desc]') : null;
        if (input) { saveDescription(input); }
    });

    document.addEventListener('keydown', function (event) {
        var input = event.target.closest ? event.target.closest('[data-time-desc]') : null;
        if (!input) { return; }
        if (event.key === 'Enter') {
            event.preventDefault();
            input.blur();
        } else if (event.key === 'Escape') {
            input.value = input.getAttribute('data-original') || '';
            input.blur();
        }
    });

})();
