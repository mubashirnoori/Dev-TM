<?php
/**
 * Server-authoritative running timer. One row per user (UNIQUE user_id).
 *
 * Elapsed time is always computed from the server clock against started_at,
 * never from a client-supplied duration.
 */

declare(strict_types=1);

final class Timer extends Model
{
    protected string $table = 'active_timers';

    protected array $columns = [
        'id', 'user_id', 'project_id', 'task_id',
        'started_at', 'last_activity_at', 'paused_at', 'accumulated_seconds', 'description', 'is_billable', 'created_at',
    ];

    protected array $fillable = [
        'user_id', 'project_id', 'task_id',
        'started_at', 'last_activity_at', 'paused_at', 'accumulated_seconds', 'description', 'is_billable',
    ];

    protected bool $timestamps = false;

    /** True when the active_timers table has been installed. */
    public static function installed(): bool
    {
        return SchemaHelper::tableExists('active_timers');
    }

    /**
     * Start a timer for $userId. At most one active timer exists per user:
     * an existing row is rejected (the caller must stop it first).
     *
     * @return array<string, mixed>
     */
    public function start(
        int $userId,
        int $projectId,
        ?int $taskId,
        string $description,
        bool $isBillable
    ): array {
        if ($userId < 1 || $projectId < 1) {
            throw new InvalidArgumentException('A user and project are required to start a timer.');
        }

        $description = mb_substr(trim($description), 0, 255, 'UTF-8');

        return Database::transaction(function (PDO $pdo) use ($userId, $projectId, $taskId, $description, $isBillable): array {
            $this->lockUser($pdo, $userId);
            $existing = $this->lockForUser($pdo, $userId);
            if ($existing !== null) {
                throw new RuntimeException('You already have a timer running. Stop it before starting another.');
            }

            $now = gmdate('Y-m-d H:i:s', time());
            TimeTrackingRules::assertCanTrack(
                $userId,
                $projectId,
                $taskId,
                $now,
                TimeTrackingRules::CONTEXT_START
            );
            (new TimeEntry())->assertWeekUnlocked($userId, $now);

            try {
                Database::execute(
                    'INSERT INTO active_timers
                        (user_id, project_id, task_id, started_at, last_activity_at, paused_at, accumulated_seconds, description, is_billable, created_at)
                     VALUES
                        (:user_id, :project_id, :task_id, :started_at, :last_activity_at, NULL, 0, :description, :is_billable, :created_at)',
                    [
                        'user_id'          => $userId,
                        'project_id'       => $projectId,
                        'task_id'          => $taskId,
                        'started_at'       => $now,
                        'last_activity_at' => $now,
                        'description'      => $description !== '' ? $description : null,
                        'is_billable'      => $isBillable ? 1 : 0,
                        'created_at'       => $now,
                    ]
                );
            } catch (PDOException $e) {
                if ((int) ($e->errorInfo[1] ?? 0) === 1062) {
                    throw new RuntimeException('You already have a timer running. Stop it before starting another.');
                }
                throw $e;
            }

            $row = $this->getActive($userId);
            if ($row === null) {
                throw new RuntimeException('Timer could not be started.');
            }

            return $row;
        });
    }

    /**
     * Fetch the user's running timer with project/task names and server elapsed seconds.
     *
     * @return array<string, mixed>|null
     */
    public function getActive(int $userId): ?array
    {
        if ($userId < 1 || !self::installed()) {
            return null;
        }

        $taskSelect = Task::installed() ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskJoin   = Task::installed() ? 'LEFT JOIN tasks tk ON tk.id = t.task_id' : '';

        $row = Database::fetchOne(
            "SELECT t.id, t.user_id, t.project_id, t.task_id, t.started_at, t.last_activity_at,
                    t.paused_at, t.accumulated_seconds, t.description, t.is_billable, t.created_at,
                    p.name AS project_name, p.project_code, p.hourly_rate, p.is_billable AS project_billable,
                    {$taskSelect}
             FROM active_timers t
             INNER JOIN projects p ON p.id = t.project_id
             {$taskJoin}
             WHERE t.user_id = :user_id
             LIMIT 1",
            ['user_id' => $userId]
        );

        if ($row === null) {
            return null;
        }

        return $this->withElapsed($row);
    }

    /**
     * Fetch timers visible to the current viewer. Regular users see only their
     * own timer; users with time.view_all may see all active timers.
     *
     * @return list<array<string, mixed>>
     */
    public function getVisibleActive(int $viewerId, bool $viewAll = false, ?int $userId = null): array
    {
        if ($viewerId < 1 || !self::installed()) {
            return [];
        }

        $taskSelect = Task::installed() ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskJoin   = Task::installed() ? 'LEFT JOIN tasks tk ON tk.id = t.task_id' : '';
        $where = [];
        $params = [];

        if ($viewAll) {
            if ($userId !== null && $userId > 0) {
                $where[] = 't.user_id = :filter_user_id';
                $params['filter_user_id'] = $userId;
            }
        } elseif (WorkspacePolicy::appliesRegularTimeVisibility()
            && WorkspacePolicy::regularUserTimeVisibility() !== 'own'
        ) {
            [$visSql, $visParams] = WorkspacePolicy::regularTimeVisibilityClause($viewerId, 'p', 't.user_id');
            $where[] = $visSql;
            $params = array_merge($params, $visParams);
            if ($userId !== null && $userId > 0) {
                $where[] = 't.user_id = :filter_user_id';
                $params['filter_user_id'] = $userId;
            }
        } else {
            $where[] = 't.user_id = :viewer_id';
            $params['viewer_id'] = $viewerId;
        }

        $sql = "SELECT t.id, t.user_id, t.project_id, t.task_id, t.started_at, t.last_activity_at,
                       t.paused_at, t.accumulated_seconds, t.description, t.is_billable, t.created_at,
                       u.name AS user_name,
                       p.name AS project_name, p.project_code,
                       {$taskSelect}
                FROM active_timers t
                INNER JOIN users u ON u.id = t.user_id
                INNER JOIN projects p ON p.id = t.project_id
                {$taskJoin}";

        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY t.started_at ASC, t.id ASC';

        $rows = Database::fetchAll($sql, $params);
        return array_map(fn (array $row): array => $this->withElapsed($row), $rows);
    }

    /**
     * Stop the running timer: insert a time_entries row with exact elapsed seconds,
     * delete the active_timers row, return the new entry.
     *
     * @return array<string, mixed>
     */
    public function stop(int $userId): array
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A user is required to stop a timer.');
        }

        return Database::transaction(function (PDO $pdo) use ($userId): array {
            $this->lockUser($pdo, $userId);
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null) {
                throw new RuntimeException('No timer is running.');
            }

            $originalStart = (string) ($row['created_at'] ?? $row['started_at']);
            $originalStartTs = strtotime($originalStart . ' UTC');
            if ($originalStartTs === false) {
                $originalStartTs = time();
                $originalStart = gmdate('Y-m-d H:i:s', $originalStartTs);
            }

            $segmentStartTs = strtotime((string) $row['started_at'] . ' UTC');
            if ($segmentStartTs === false) {
                $segmentStartTs = $originalStartTs;
            }

            $accumulated = max(0, (int) ($row['accumulated_seconds'] ?? 0));
            $isPaused = !empty($row['paused_at']);
            $nowTs = time();
            $elapsed = $accumulated + ($isPaused ? 0 : max(0, $nowTs - $segmentStartTs));
            $elapsed = max(1, $elapsed);
            $endTime = gmdate('Y-m-d H:i:s', $nowTs);
            $wallSeconds = max($elapsed, $nowTs - $originalStartTs);
            $breakMinutes = max(0, (int) floor(($wallSeconds - $elapsed) / 60));
            $rate     = $this->projectRate((int) $row['project_id']);
            $billable = (int) $row['is_billable'] === 1 ? 1 : 0;

            $entry = (new TimeEntry())->createEntry([
                'user_id'          => $userId,
                'project_id'       => (int) $row['project_id'],
                'task_id'          => $row['task_id'] !== null ? (int) $row['task_id'] : null,
                'start_time'       => $originalStart,
                'end_time'         => $endTime,
                'break_minutes'    => $breakMinutes,
                'description'      => $row['description'],
                'is_billable'      => $billable,
                'billable_rate'    => $rate,
                '_context'         => TimeTrackingRules::CONTEXT_START,
            ], false);

            Database::execute(
                'DELETE FROM active_timers WHERE user_id = :user_id',
                ['user_id' => $userId]
            );

            return $entry;
        });
    }

    /**
     * Return the current stop conflict without mutating the timer.
     * The active timer remains untouched so the user can choose a resolution.
     *
     * @return array{timer: array<string,mixed>, conflict: array<string,mixed>}|null
     */
    public function getStopConflict(int $userId): ?array
    {
        if ($userId < 1) {
            return null;
        }

        $timer = $this->getActive($userId);
        if ($timer === null) {
            return null;
        }

        $start = (string) ($timer['created_at'] ?? $timer['started_at']);
        $end = gmdate('Y-m-d H:i:s', time());
        $conflict = (new TimeEntry())->findEntryOverlap($userId, $start, $end, null, false);
        if ($conflict === null) {
            return null;
        }

        return ['timer' => $timer, 'conflict' => $conflict];
    }

    /**
     * Resolve a stop conflict while keeping the operation server-authoritative.
     * trim ends the timer immediately before the first conflicting entry; discard
     * removes the active timer without creating a time entry.
     *
     * @return array<string,mixed>|null Saved entry, or null for discard.
     */
    public function resolveStop(int $userId, string $resolution): ?array
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A user is required to resolve a timer.');
        }

        $resolution = strtolower(trim($resolution));
        if (!in_array($resolution, ['trim', 'discard'], true)) {
            throw new InvalidArgumentException('Choose either trim to the conflict or discard the timer.');
        }

        return Database::transaction(function (PDO $pdo) use ($userId, $resolution): ?array {
            $this->lockUser($pdo, $userId);
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null) {
                throw new RuntimeException('No timer is running.');
            }

            if ($resolution === 'discard') {
                Database::execute('DELETE FROM active_timers WHERE user_id = :user_id', ['user_id' => $userId]);
                return null;
            }

            $originalStart = (string) ($row['created_at'] ?? $row['started_at']);
            $originalStartTs = strtotime($originalStart . ' UTC');
            if ($originalStartTs === false) {
                throw new InvalidArgumentException('The timer start time is invalid and cannot be trimmed safely.');
            }

            $nowTs = time();
            $nowUtc = gmdate('Y-m-d H:i:s', $nowTs);
            $conflict = (new TimeEntry())->findEntryOverlap($userId, $originalStart, $nowUtc, null, true);
            if ($conflict === null) {
                throw new InvalidArgumentException('The conflict is no longer present. Please stop the timer normally.');
            }

            $trimEnd = (string) $conflict['start_time'];
            $trimEndTs = strtotime($trimEnd . ' UTC');
            if ($trimEndTs === false || $trimEndTs <= $originalStartTs) {
                throw new InvalidArgumentException('The conflicting entry begins at or before this timer, so it cannot be trimmed. Choose Discard.');
            }

            $entry = $this->createEntryFromTimerRow($userId, $row, $originalStart, $trimEnd, $trimEndTs);
            Database::execute('DELETE FROM active_timers WHERE user_id = :user_id', ['user_id' => $userId]);

            return $entry;
        });
    }

    /**
     * Auto-stop expired running timers using the single system setting
     * `settings.timer_max_hours`. The saved end time is exactly
     * started_at + the configured limit, never the cleanup request time.
     *
     * @return list<array<string,mixed>> newly created auto-stopped entries
     */
    public function cleanupExpired(?int $userId = null): array
    {
        if (!self::installed()) {
            return [];
        }

        $maxSeconds = $this->maxTimerSeconds();
        if ($maxSeconds < 60) {
            return [];
        }

        $rows = $userId !== null && $userId > 0
            ? Database::fetchAll(
                'SELECT * FROM active_timers
                 WHERE user_id = :user_id AND paused_at IS NULL
                 ORDER BY id ASC',
                ['user_id' => $userId]
            )
            : Database::fetchAll(
                'SELECT * FROM active_timers
                 WHERE paused_at IS NULL
                   AND started_at <= :cutoff
                 ORDER BY user_id ASC, id ASC',
                ['cutoff' => gmdate('Y-m-d H:i:s', time() - $maxSeconds)]
            );

        $expired = [];
        foreach ($rows as $candidate) {
            $startedTs = strtotime((string) ($candidate['started_at'] ?? '') . ' UTC');
            if ($startedTs === false) {
                continue;
            }

            $endTs = $startedTs + $maxSeconds;
            if ($endTs > time()) {
                continue;
            }

            $expired[] = $this->autoStopOne((int) $candidate['user_id'], $endTs);
        }

        return array_values(array_filter($expired, static fn ($entry): bool => is_array($entry)));
    }

    /** @return array<string,mixed>|null */
    private function autoStopOne(int $userId, int $endTs): ?array
    {
        $entry = Database::transaction(function (PDO $pdo) use ($userId, $endTs): ?array {
            $this->lockUser($pdo, $userId);
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null || !empty($row['paused_at'])) {
                return null;
            }

            $startedTs = strtotime((string) ($row['started_at'] ?? '') . ' UTC');
            if ($startedTs === false) {
                throw new RuntimeException('The running timer has an invalid start time.');
            }

            $configuredEndTs = $startedTs + $this->maxTimerSeconds();
            if ($configuredEndTs !== $endTs || $configuredEndTs > time()) {
                return null;
            }

            $endTime = gmdate('Y-m-d H:i:s', $configuredEndTs);
            $originalStart = (string) ($row['created_at'] ?? $row['started_at']);
            $originalStartTs = strtotime($originalStart . ' UTC');
            if ($originalStartTs === false) {
                $originalStart = (string) $row['started_at'];
                $originalStartTs = $startedTs;
            }

            $elapsed = max(1, $configuredEndTs - $startedTs + (int) ($row['accumulated_seconds'] ?? 0));
            $wallSeconds = max($elapsed, $configuredEndTs - $originalStartTs);
            $breakMinutes = max(0, (int) floor(($wallSeconds - $elapsed) / 60));

            $rate = $this->projectRate((int) $row['project_id']);
            $billable = (int) ($row['is_billable'] ?? 0) === 1 ? 1 : 0;

            try {
                $entry = (new TimeEntry())->createEntry([
                    'user_id'       => $userId,
                    'project_id'    => (int) $row['project_id'],
                    'task_id'       => $row['task_id'] !== null ? (int) $row['task_id'] : null,
                    'start_time'    => $originalStart,
                    'end_time'      => $endTime,
                    'break_minutes' => $breakMinutes,
                    'description'   => $row['description'],
                    'is_billable'   => $billable,
                    'billable_rate' => $rate,
                    'auto_stopped'  => 1,
                    '_context'      => TimeTrackingRules::CONTEXT_START,
                ], false);
            } catch (HttpException $e) {
                Database::execute(
                    'DELETE FROM active_timers WHERE user_id = :user_id',
                    ['user_id' => $userId]
                );
                LoggerHelper::warning('Auto-stop discarded a timer that is no longer trackable', [
                    'user_id'    => $userId,
                    'project_id' => (int) $row['project_id'],
                    'task_id'    => $row['task_id'] !== null ? (int) $row['task_id'] : null,
                    'reason'     => $e->getMessage(),
                ]);

                return null;
            }

            Database::execute(
                'DELETE FROM active_timers WHERE user_id = :user_id',
                ['user_id' => $userId]
            );

            return $entry;
        });

        if ($entry !== null) {
            NotificationHelper::timerAutoStopped(
                $userId,
                (float) $this->maxTimerHours(),
                (int) $entry['id']
            );

            LoggerHelper::audit('timer.auto_stopped', 'time_entry', (int) $entry['id'], [
                'project_id'       => (int) $entry['project_id'],
                'duration_seconds' => (int) $entry['duration_seconds'],
                'auto_stopped'     => 1,
            ]);
        }

        return $entry;
    }

    /** Read the timer limit from the single system settings table. */
    public function maxTimerHours(): float
    {
        try {
            $hours = SettingsService::systemFloat('timer_max_hours', 12.0);
        } catch (Throwable $e) {
            LoggerHelper::debug('timer_max_hours setting read failed', ['error' => $e->getMessage()]);
            $hours = 12.0;
        }

        return $hours > 0 ? $hours : 12.0;
    }

    private function maxTimerSeconds(): int
    {
        return max(60, (int) round($this->maxTimerHours() * 3600));
    }

    /** Pause the active timer while preserving accumulated work time. */
    public function pause(int $userId): array
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A user is required to pause a timer.');
        }

        return Database::transaction(function (PDO $pdo) use ($userId): array {
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null) {
                throw new RuntimeException('No timer is running.');
            }
            if (!empty($row['paused_at'])) {
                throw new RuntimeException('The timer is already paused.');
            }

            $startedTs = strtotime((string) $row['started_at'] . ' UTC');
            if ($startedTs === false) {
                $startedTs = time();
            }
            $now = time();
            $accumulated = max(0, (int) ($row['accumulated_seconds'] ?? 0)) + max(0, $now - $startedTs);
            $nowSql = gmdate('Y-m-d H:i:s', $now);

            Database::execute(
                'UPDATE active_timers
                 SET accumulated_seconds = :accumulated_seconds,
                     paused_at = :paused_at,
                     last_activity_at = :last_activity_at
                 WHERE user_id = :user_id',
                [
                    'accumulated_seconds' => $accumulated,
                    'paused_at'           => $nowSql,
                    'last_activity_at'   => $nowSql,
                    'user_id'             => $userId,
                ]
            );

            $updated = $this->getActive($userId);
            if ($updated === null) {
                throw new RuntimeException('Timer could not be paused.');
            }
            return $updated;
        });
    }

    /**
     * Pause only if a timer is running. Returns the paused row, or null when
     * there is no timer / it is already paused. Never throws for those cases.
     *
     * @return array<string, mixed>|null
     */
    public function pauseIfRunning(int $userId): ?array
    {
        if ($userId < 1) {
            return null;
        }

        return Database::transaction(function (PDO $pdo) use ($userId): ?array {
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null || !empty($row['paused_at'])) {
                return null;
            }

            $startedTs = strtotime((string) $row['started_at'] . ' UTC');
            if ($startedTs === false) {
                $startedTs = time();
            }
            $now = time();
            $accumulated = max(0, (int) ($row['accumulated_seconds'] ?? 0)) + max(0, $now - $startedTs);
            $nowSql = gmdate('Y-m-d H:i:s', $now);

            Database::execute(
                'UPDATE active_timers
                 SET accumulated_seconds = :accumulated_seconds,
                     paused_at = :paused_at,
                     last_activity_at = :last_activity_at
                 WHERE user_id = :user_id AND paused_at IS NULL',
                [
                    'accumulated_seconds' => $accumulated,
                    'paused_at'           => $nowSql,
                    'last_activity_at'   => $nowSql,
                    'user_id'             => $userId,
                ]
            );

            return $this->getActive($userId);
        });
    }

    /** Resume a paused timer without counting the break as worked time. */
    public function resume(int $userId): array
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A user is required to resume a timer.');
        }

        return Database::transaction(function (PDO $pdo) use ($userId): array {
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null) {
                throw new RuntimeException('No timer is paused.');
            }
            if (empty($row['paused_at'])) {
                throw new RuntimeException('The timer is already running.');
            }

            $now = time();
            $nowSql = gmdate('Y-m-d H:i:s', $now);
            Database::execute(
                'UPDATE active_timers
                 SET started_at = :started_at,
                     paused_at = NULL,
                     last_activity_at = :last_activity_at
                 WHERE user_id = :user_id',
                [
                    'started_at'       => $nowSql,
                    'last_activity_at'=> $nowSql,
                    'user_id'          => $userId,
                ]
            );

            $updated = $this->getActive($userId);
            if ($updated === null) {
                throw new RuntimeException('Timer could not be resumed.');
            }
            return $updated;
        });
    }

    /** Touch last_activity_at so idle detection can see the user is still around. */
    public function ping(int $userId): bool
    {
        if ($userId < 1 || !self::installed()) {
            return false;
        }

        return Database::execute(
            'UPDATE active_timers SET last_activity_at = :now WHERE user_id = :user_id',
            ['now' => gmdate('Y-m-d H:i:s', time()), 'user_id' => $userId]
        ) > 0;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public function withElapsed(array $row): array
    {
        $startedTs = strtotime((string) $row['started_at'] . ' UTC');
        if ($startedTs === false) {
            $startedTs = time();
        }

        $accumulated = max(0, (int) ($row['accumulated_seconds'] ?? 0));
        $elapsed = $accumulated + (!empty($row['paused_at']) ? 0 : max(0, time() - $startedTs));

        $row['elapsed_seconds'] = $elapsed;
        $row['paused'] = !empty($row['paused_at']);
        $row['elapsed_display'] = FormatHelper::duration($elapsed);
        $row['is_billable']     = (int) ($row['is_billable'] ?? 0);
        $row['project_id']      = (int) $row['project_id'];
        $row['task_id']         = $row['task_id'] !== null ? (int) $row['task_id'] : null;
        $row['user_id']         = (int) $row['user_id'];
        $row['id']              = (int) $row['id'];

        return $row;
    }

    /** @return array<string,mixed> */
    private function createEntryFromTimerRow(int $userId, array $row, string $originalStart, string $endTime, int $endTs): array
    {
        $originalStartTs = strtotime($originalStart . ' UTC');
        if ($originalStartTs === false || $endTs <= $originalStartTs) {
            throw new InvalidArgumentException('Timer duration must be greater than zero.');
        }

        $segmentStartTs = strtotime((string) $row['started_at'] . ' UTC');
        if ($segmentStartTs === false) {
            $segmentStartTs = $originalStartTs;
        }

        $accumulated = max(0, (int) ($row['accumulated_seconds'] ?? 0));
        $isPaused = !empty($row['paused_at']);
        $elapsed = $accumulated + ($isPaused ? 0 : max(0, $endTs - $segmentStartTs));
        $elapsed = max(1, $elapsed);
        $wallSeconds = max($elapsed, $endTs - $originalStartTs);
        $breakMinutes = max(0, (int) floor(($wallSeconds - $elapsed) / 60));
        $rate = $this->projectRate((int) $row['project_id']);
        $billable = (int) $row['is_billable'] === 1 ? 1 : 0;

        return (new TimeEntry())->createEntry([
            'user_id'       => $userId,
            'project_id'    => (int) $row['project_id'],
            'task_id'       => $row['task_id'] !== null ? (int) $row['task_id'] : null,
            'start_time'    => $originalStart,
            'end_time'      => $endTime,
            'break_minutes' => $breakMinutes,
            'description'   => $row['description'],
            'is_billable'   => $billable,
            'billable_rate' => $rate,
            '_context'      => TimeTrackingRules::CONTEXT_START,
        ], false);
    }

    /** Serialize all timer/time-entry writes for one user. */
    private function lockUser(PDO $pdo, int $userId): void
    {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE id = :user_id LIMIT 1 FOR UPDATE');
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        if ($stmt->fetchColumn() === false) {
            throw new InvalidArgumentException('User account was not found.');
        }
    }

    /**
     * Lock the user's timer row (if any) for the rest of the transaction.
     *
     * @return array<string, mixed>|null
     */
    private function lockForUser(PDO $pdo, int $userId): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM active_timers WHERE user_id = :user_id LIMIT 1 FOR UPDATE');
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    private function projectRate(int $projectId): float
    {
        $rate = Database::fetchValue(
            'SELECT hourly_rate FROM projects WHERE id = :id LIMIT 1',
            ['id' => $projectId]
        );

        return $rate !== null ? (float) $rate : 0.0;
    }
}
