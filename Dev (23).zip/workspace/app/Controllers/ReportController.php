<?php
declare(strict_types=1);

final class ReportController extends Controller
{
    private Report $reports;

    public function __construct()
    {
        parent::__construct(true);
        FeatureFlagsHelper::requireReports();
        PermissionHelper::require('reports.view');
        $this->reports = new Report();
    }

    /** GET /reports */
    public function index(Request $request, array $params): void
    {
        $viewerId = (int) AuthHelper::id();
        $role = (string) AuthHelper::role();
        $canViewAll = PermissionHelper::has('time.view_all') && $role !== AuthHelper::ROLE_CLIENT;
        $canBilling = PermissionHelper::has('reports.billing');
        $canExport = PermissionHelper::has('reports.export');

        $filters = $this->filters($request, $canViewAll);
        $summary = $this->reports->summary($filters, $viewerId, $role, $canViewAll);

        $people = $canViewAll ? Database::fetchAll(
            "SELECT u.id, u.name, u.email FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        ) : [];
        $clients = $canViewAll ? Database::fetchAll("SELECT id, name, company FROM clients WHERE status='active' ORDER BY name ASC") : [];
        $projects = $this->filterProjects($viewerId, $canViewAll);
        $tasks = $this->filterTasks($filters['project_id'], $viewerId, $canViewAll);

        $this->render('reports/index', [
            'pageTitle' => 'Reports',
            'summary' => $summary,
            'filters' => $filters,
            'people' => $people,
            'clients' => $clients,
            'projects' => $projects,
            'tasks' => $tasks,
            'canViewAll' => $canViewAll,
            'canBilling' => $canBilling,
            'canExport' => $canExport,
            'role' => $role,
        ]);
    }

    /** GET /reports/export.csv */
    public function exportCsv(Request $request, array $params): void
    {
        PermissionHelper::require('reports.export');
        $viewerId = (int) AuthHelper::id();
        $role = (string) AuthHelper::role();
        $canViewAll = PermissionHelper::has('time.view_all') && $role !== AuthHelper::ROLE_CLIENT;
        $canBilling = PermissionHelper::has('reports.billing');
        $filters = $this->filters($request, $canViewAll);
        $rows = $this->reports->detail($filters, $viewerId, $role, $canViewAll, 10000);

        if (ob_get_length() !== false) { @ob_end_clean(); }
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="timetrack-report-' . gmdate('Y-m-d-His') . '.csv"');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        echo "\xEF\xBB\xBF";

        $headers = ['Date','User','Client','Project','Task','Start','End','Hours','Billable','Status','Note'];
        if ($canBilling) { $headers[] = 'Frozen Rate'; $headers[] = 'Billable Amount'; }
        $this->csvRow($headers);

        foreach ($rows as $row) {
            $values = [
                FormatHelper::date((string) $row['start_time']),
                (string) $row['user_name'],
                (string) $row['client_name'],
                (string) $row['project_name'],
                (string) $row['task_name'],
                FormatHelper::datetime((string) $row['start_time']),
                FormatHelper::datetime((string) $row['end_time']),
                FormatHelper::hours((int) $row['duration_seconds']),
                (int) $row['is_billable'] === 1 ? 'Billable' : 'Non-billable',
                (string) $row['status'],
                (string) ($row['description'] ?? ''),
            ];
            if ($canBilling) {
                $values[] = number_format((float) $row['billable_rate'], 2, '.', '');
                $values[] = number_format((float) $row['billable_amount'], 2, '.', '');
            }
            $this->csvRow($values);
        }
        exit;
    }

    /** @return array<string,mixed> */
    private function filters(Request $request, bool $canViewAll): array
    {
        $validDate = static function(string $v): string { return preg_match('/^\d{4}-\d{2}-\d{2}$/', trim($v)) === 1 ? trim($v) : ''; };
        $from = $validDate((string) $request->input('from',''));
        $to = $validDate((string) $request->input('to',''));
        if ($from !== '' && $to !== '' && $from > $to) { [$from,$to] = [$to,$from]; }
        return [
            'from' => $from,
            'to' => $to,
            'project_id' => (int) $request->input('project_id',0),
            'task_id' => (int) $request->input('task_id',0),
            'user_id' => $canViewAll ? (int) $request->input('user_id',0) : 0,
            'client_id' => $canViewAll ? (int) $request->input('client_id',0) : 0,
            'billable' => in_array((string)$request->input('billable',''), ['0','1'], true) ? (string)$request->input('billable','') : '',
        ];
    }

    /** @return list<array<string,mixed>> */
    private function filterProjects(int $userId, bool $viewAll): array
    {
        if (ClientScope::isClient()) {
            [$clause, $params] = ClientScope::projectClause('p');
            return Database::fetchAll(
                "SELECT p.id,p.name,p.project_code FROM projects p WHERE p.status <> 'Archived' AND {$clause} ORDER BY p.name ASC",
                $params
            );
        }
        if ($viewAll) return Database::fetchAll("SELECT id,name,project_code FROM projects WHERE status <> 'Archived' ORDER BY name ASC");
        return Database::fetchAll(
            "SELECT DISTINCT p.id,p.name,p.project_code FROM projects p
             INNER JOIN project_members pm ON pm.project_id=p.id
             WHERE pm.user_id=:uid AND p.status <> 'Archived' ORDER BY p.name ASC",
            ['uid'=>$userId]
        );
    }

    /** @return list<array<string,mixed>> */
    private function filterTasks(int $projectId, int $userId, bool $viewAll): array
    {
        if ($projectId < 1) return [];
        if ($viewAll) return Database::fetchAll("SELECT id,name FROM tasks WHERE project_id=:pid ORDER BY name ASC", ['pid'=>$projectId]);
        return Database::fetchAll(
            "SELECT DISTINCT t.id,t.name FROM tasks t INNER JOIN task_assignees ta ON ta.task_id=t.id
             WHERE t.project_id=:pid AND ta.user_id=:uid ORDER BY t.name ASC",
            ['pid'=>$projectId,'uid'=>$userId]
        );
    }

    /** @param list<mixed> $values */
    private function csvRow(array $values): void
    {
        CsvHelper::row($values);
    }
}
