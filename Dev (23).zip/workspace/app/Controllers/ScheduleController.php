<?php
/**
 * Planned work: calendar, my schedule, team matrix, conflict-aware create/update.
 *
 * Employees see and edit their own blocks on assigned projects.
 * Managers see the team and can plan work for members of projects they manage.
 * Admins have full access.
 */

declare(strict_types=1);

final class ScheduleController extends Controller
{
    private Schedule $schedules;
    private Project $projects;

    public function __construct()
    {
        parent::__construct(true);
        FeatureFlagsHelper::requireScheduling();
        $this->schedules = new Schedule();
        $this->projects  = new Project();
    }

    /** GET /schedule */
    public function calendar(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');
        FeatureFlagsHelper::requireScheduling();

        $view = (string) $request->input('view', 'week');
        if (!in_array($view, ['month', 'week', 'day'], true)) {
            $view = 'week';
        }

        $this->render('schedule/calendar', $this->pageData([
            'pageTitle'     => 'Schedule',
            'activeTab'     => 'calendar',
            'calendarView'  => $view,
            // Default scope is the logged-in user. ?user_id=all shows everyone, ?user_id=N one person.
            'focusUserId'   => $this->focusUserFromRequest($request),
            // Deep link from a task page: ?project_id=&task_id= opens "Plan work" pre-filled.
            'prefillProjectId' => max(0, (int) $request->input('project_id', 0)),
            'prefillTaskId'    => max(0, (int) $request->input('task_id', 0)),
            'scheduleAssets'=> true,
        ]));
    }

    /** GET /schedule/events */
    public function eventsJson(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');
        FeatureFlagsHelper::requireScheduling();

        [$startUtc, $endUtc] = $this->rangeFromRequest($request);
        $userId    = (int) AuthHelper::id();
        $viewTeam  = PermissionHelper::has('schedule.view_team');
        // Employees are always limited to their own blocks. Team viewers default to their own
        // calendar too; ?user_id=all shows everyone and ?user_id=N shows one person.
        $focusUser = $viewTeam ? $this->focusUserFromRequest($request) : $userId;

        $rows = $this->schedules->inRange(
            $startUtc,
            $endUtc,
            $focusUser > 0 ? $focusUser : null,
            $viewTeam,
            $userId
        );

        $events = [];
        foreach ($rows as $row) {
            if (!$this->schedules->userCanView($row, $userId, $viewTeam)) {
                continue;
            }

            $title = (string) $row['project_name'];
            if (!empty($row['task_name'])) {
                $title .= ' · ' . $row['task_name'];
            }

            $events[] = [
                'id'               => (int) $row['id'],
                'title'            => $title,
                'start'            => $this->toIsoUtc((string) $row['start_datetime']),
                'end'              => $this->toIsoUtc((string) $row['end_datetime']),
                'color'            => (string) $row['color'],
                'status'           => (string) $row['status'],
                'project_id'       => (int) $row['project_id'],
                'project_name'     => (string) $row['project_name'],
                'project_code'     => (string) $row['project_code'],
                'project_priority' => (string) ($row['project_priority'] ?? ''),
                'task_id'          => $row['task_id'],
                'task_name'        => (string) ($row['task_name'] ?? ''),
                'user_id'          => (int) $row['user_id'],
                'user_name'        => (string) $row['user_name'],
                'notes'            => (string) ($row['notes'] ?? ''),
                'estimated_hours'  => (float) $row['estimated_hours'],
                'editable'         => $this->schedules->userCanEdit(
                    $row,
                    $userId,
                    AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
                    AuthHelper::hasRole(AuthHelper::ROLE_MANAGER)
                ),
            ];
        }

        $this->json(['ok' => true, 'events' => $events]);
    }

    /** GET /schedule/my */
    public function mySchedule(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');
        FeatureFlagsHelper::requireScheduling();

        $userId = (int) AuthHelper::id();
        $from   = (new DateTimeImmutable('today', new DateTimeZone('UTC')))->format('Y-m-d 00:00:00');
        $items  = $this->schedules->forUser($userId, $from, 80);
        $groups = $this->groupByLocalDay($items);

        $this->remindApproaching($items);

        $this->render('schedule/my_schedule', $this->pageData([
            'pageTitle'      => 'My schedule',
            'activeTab'      => 'mine',
            'groups'         => $groups,
            'canTimer'       => is_file(APP_PATH . '/Controllers/TimerController.php') && PermissionHelper::has('time.track'),
            'scheduleAssets' => true,
        ]));
    }

    /** GET /schedule/team */
    public function teamSchedule(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view_team');
        FeatureFlagsHelper::requireScheduling();
        FeatureFlagsHelper::requireTeam();

        $anchor = $this->parseLocalDate((string) $request->input('week', ''));
        $weekStart = $anchor->modify(WorkspacePolicy::weekModifier())->setTime(0, 0, 0);
        $weekEnd   = $weekStart->modify('+7 days');

        $startUtc = $weekStart->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        $endUtc   = $weekEnd->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');

        $workload = $this->schedules->teamWorkload($startUtc, $endUtc);
        $events   = $this->schedules->inRange($startUtc, $endUtc, null, true, (int) AuthHelper::id());

        $byUser = [];
        foreach ($events as $event) {
            $byUser[(int) $event['user_id']][] = $event;
        }

        $days = [];
        for ($i = 0; $i < 7; $i++) {
            $days[] = $weekStart->modify('+' . $i . ' day');
        }

        $this->render('schedule/team_schedule', $this->pageData([
            'pageTitle'      => 'Team schedule',
            'activeTab'      => 'team',
            'weekStart'      => $weekStart,
            'weekEnd'        => $weekEnd,
            'days'           => $days,
            'workload'       => $workload,
            'byUser'         => $byUser,
            'prevWeek'       => $weekStart->modify('-7 days')->format('Y-m-d'),
            'nextWeek'       => $weekStart->modify('+7 days')->format('Y-m-d'),
            'scheduleAssets' => true,
        ]));
    }

    /** POST /schedule */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.create');
        FeatureFlagsHelper::requireScheduling();

        $payload = $this->validatedBlock('/schedule');
        $this->assertCanAssign($payload['user_id'], $payload['project_id']);

        $conflicts = $this->schedules->checkConflict(
            $payload['user_id'],
            $payload['start_datetime'],
            $payload['end_datetime']
        );

        if ($conflicts !== [] && !$this->wantsOverride($request)) {
            $this->conflictResponse($conflicts);
        }

        $payload['created_by'] = (int) AuthHelper::id();
        $id = $this->schedules->create($payload);

        $recurrence = $this->postedRecurrence();
        $recurrenceResult = ['created' => [], 'skipped' => []];
        if ($recurrence !== null) {
            $this->schedules->saveRecurrence($id, $recurrence);
            $recurrenceResult = $this->schedules->expandRecurrence($id);
        }

        LoggerHelper::audit('schedule.created', 'schedule', $id, [
            'user_id'    => $payload['user_id'],
            'project_id' => $payload['project_id'],
            'overridden' => $conflicts !== [],
        ]);
        if ($conflicts !== []) {
            LoggerHelper::scheduleConflictOverridden($id, $conflicts);
        }
        $this->notifyScheduleChange($payload, $conflicts, $id);

        if ($request->wantsJson()) {
            $this->json([
                'ok' => true,
                'id' => $id,
                'recurrence' => [
                    'created' => count($recurrenceResult['created']),
                    'skipped' => $recurrenceResult['skipped'],
                ],
            ]);
        }

        $createdCount = count($recurrenceResult['created'] ?? []);
        $skipped = $recurrenceResult['skipped'] ?? [];
        if ($createdCount > 0 || $skipped !== []) {
            $this->flash('success', $this->recurrenceSavedMessage($createdCount, $skipped));
            if ($skipped !== []) {
                $this->flash('warning', $this->recurrenceSkippedMessage($skipped));
            }
        } else {
            $this->flash('success', 'Planned work was saved.');
        }
        $this->redirect('/schedule');
    }

    /** POST /schedule/{id} */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.edit');
        FeatureFlagsHelper::requireScheduling();

        $row = $this->loadEditable((int) ($params['id'] ?? 0));
        $payload = $this->validatedBlock('/schedule');
        $this->assertCanAssign($payload['user_id'], $payload['project_id']);

        $conflicts = $this->schedules->checkConflict(
            $payload['user_id'],
            $payload['start_datetime'],
            $payload['end_datetime'],
            (int) $row['id']
        );

        if ($conflicts !== [] && !$this->wantsOverride($request)) {
            $this->conflictResponse($conflicts);
        }

        unset($payload['created_by']);
        $this->schedules->update((int) $row['id'], $payload);

        $recurrence = $this->postedRecurrence();
        if ($recurrence !== null) {
            $this->schedules->saveRecurrence((int) $row['id'], $recurrence);
        }

        LoggerHelper::audit('schedule.updated', 'schedule', (int) $row['id']);
        LoggerHelper::scheduleChanged((int) $row['id'], [
            'start_datetime' => (string) $row['start_datetime'],
            'end_datetime'   => (string) $row['end_datetime'],
            'status'         => (string) $row['status'],
        ], [
            'start_datetime' => (string) $payload['start_datetime'],
            'end_datetime'   => (string) $payload['end_datetime'],
            'status'         => (string) $payload['status'],
        ]);
        if ($conflicts !== []) {
            LoggerHelper::scheduleConflictOverridden((int) $row['id'], $conflicts);
        }
        $this->notifyScheduleChange($payload, $conflicts, (int) $row['id'], $row);

        if ($request->wantsJson()) {
            $this->json(['ok' => true, 'id' => (int) $row['id']]);
        }

        $this->flash('success', 'Planned work was updated.');
        $this->redirect('/schedule');
    }

    /** POST /schedule/{id}/time  AJAX drag/resize */
    public function updateEventTime(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.edit');
        FeatureFlagsHelper::requireScheduling();

        $row = $this->loadEditable((int) ($params['id'] ?? 0));

        $startRaw = (string) $request->input('start_datetime', $request->input('start', ''));
        $endRaw   = (string) $request->input('end_datetime', $request->input('end', ''));
        $startUtc = $this->parseIncomingDatetime($startRaw);
        $endUtc   = $this->parseIncomingDatetime($endRaw);

        if ($startUtc === null || $endUtc === null || $endUtc <= $startUtc) {
            $this->json(['ok' => false, 'errors' => ['start_datetime' => 'The new time range is not valid.']], 422);
        }

        $conflicts = $this->schedules->checkConflict(
            (int) $row['user_id'],
            $startUtc,
            $endUtc,
            (int) $row['id']
        );

        if ($conflicts !== [] && !$this->wantsOverride($request)) {
            $this->conflictResponse($conflicts);
        }

        $this->schedules->update((int) $row['id'], [
            'start_datetime'  => $startUtc,
            'end_datetime'    => $endUtc,
            'estimated_hours' => Schedule::hoursBetween($startUtc, $endUtc),
            'status'          => (string) $row['status'] === Schedule::STATUS_SCHEDULED
                ? Schedule::STATUS_RESCHEDULED
                : $row['status'],
        ]);

        LoggerHelper::audit('schedule.moved', 'schedule', (int) $row['id'], [
            'overridden' => $conflicts !== [],
        ]);
        if ($conflicts !== []) {
            LoggerHelper::scheduleConflictOverridden((int) $row['id'], $conflicts);
        }
        $this->notifyScheduleChange([
            'user_id'        => (int) $row['user_id'],
            'project_id'     => (int) $row['project_id'],
            'start_datetime' => $startUtc,
        ], $conflicts, (int) $row['id']);

        $this->json(['ok' => true, 'id' => (int) $row['id']]);
    }

    /** POST /schedule/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.delete');
        FeatureFlagsHelper::requireScheduling();

        $row = $this->loadEditable((int) ($params['id'] ?? 0));
        $this->schedules->cancel((int) $row['id']);
        LoggerHelper::audit('schedule.cancelled', 'schedule', (int) $row['id']);
        $this->notifyScheduleCancelled($row);

        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }

        $this->flash('success', 'Planned work was cancelled.');
        $this->redirect('/schedule');
    }

    /** GET /schedule/tasks?project_id= */
    public function tasksJson(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');
        FeatureFlagsHelper::requireScheduling();

        $projectId = (int) $request->input('project_id', 0);
        $this->assertCanViewProject($projectId);

        $this->json(['ok' => true, 'tasks' => $this->tasksForProject($projectId)]);
    }

    /** GET /schedule/assignees?project_id= */
    public function assigneesJson(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');
        FeatureFlagsHelper::requireScheduling();

        $projectId = (int) $request->input('project_id', 0);
        $this->assertCanViewProject($projectId);

        $this->json(['ok' => true, 'users' => $this->assigneesForProject($projectId)]);
    }

    /**
     * Which person's blocks the calendar shows.
     * Returns 0 for "everyone" (team viewers only), otherwise a user id.
     * Missing or invalid input falls back to the logged-in user, so a personal calendar is the default.
     */
    private function focusUserFromRequest(Request $request): int
    {
        $own = (int) AuthHelper::id();

        if (!PermissionHelper::has('schedule.view_team')) {
            return $own;
        }

        $raw = strtolower(trim((string) $request->input('user_id', '')));
        if ($raw === 'all') {
            return 0;
        }

        $id = (int) $raw;
        return $id > 0 ? $id : $own;
    }

    /** @return array<string, mixed> */
    private function pageData(array $extra): array
    {
        $userId   = (int) AuthHelper::id();
        $viewTeam = PermissionHelper::has('schedule.view_team');

        return array_merge([
            'projects'     => $this->visibleProjects($userId, $viewTeam),
            'people'       => $viewTeam ? $this->activePeople() : [],
            'statuses'     => Schedule::STATUSES,
            'canCreate'    => PermissionHelper::has('schedule.create'),
            'canEdit'      => PermissionHelper::has('schedule.edit'),
            'canDelete'    => PermissionHelper::has('schedule.delete'),
            'canTeam'      => $viewTeam,
            'canAssign'    => $viewTeam || AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
            'defaultUser'  => $userId,
            'timezone'     => FormatHelper::displayTimezone(),
            'hasTasks'     => $this->tasksTableExists(),
        ], $extra);
    }

    /** @return array<string, mixed> */
    private function validatedBlock(string $failPath): array
    {
        $rules = [
            'project_id'      => 'required|int|exists:projects,id',
            'user_id'         => 'required|int|exists:users,id',
            'start_datetime'  => 'required|datetime',
            'end_datetime'    => 'required|datetime',
            'status'          => 'required|in:' . implode(',', Schedule::STATUSES),
            'notes'           => 'nullable|string|max:2000',
            'estimated_hours' => 'nullable|numeric|min:0|max:24',
            'task_id'         => 'nullable|int',
        ];

        if ($this->tasksTableExists()) {
            $rules['task_id'] = 'nullable|int|exists:tasks,id';
        }

        $data = $this->validate($rules, $failPath, [
            'project_id'     => 'Project',
            'user_id'        => 'Person',
            'start_datetime' => 'Start',
            'end_datetime'   => 'End',
            'status'         => 'Status',
            'notes'          => 'Notes',
            'task_id'        => 'Task',
        ]);

        $startUtc = $this->parseIncomingDatetime((string) $data['start_datetime']);
        $endUtc   = $this->parseIncomingDatetime((string) $data['end_datetime']);

        if ($startUtc === null || $endUtc === null) {
            $this->failOrJson($failPath, ['start_datetime' => 'Start and end must be valid date and time.']);
        }
        if ($endUtc <= $startUtc) {
            $this->failOrJson($failPath, ['end_datetime' => 'End must be after start.']);
        }

        $hours = $data['estimated_hours'] !== null
            ? (float) $data['estimated_hours']
            : Schedule::hoursBetween($startUtc, $endUtc);

        return [
            'project_id'      => (int) $data['project_id'],
            'task_id'         => $data['task_id'] !== null ? (int) $data['task_id'] : null,
            'user_id'         => (int) $data['user_id'],
            'start_datetime'  => $startUtc,
            'end_datetime'    => $endUtc,
            'estimated_hours' => $hours,
            'status'          => (string) $data['status'],
            'notes'           => $data['notes'],
        ];
    }

    /** @param list<array<string,mixed>> $skipped */
    private function recurrenceSavedMessage(int $createdCount, array $skipped): string
    {
        $parts = ['Planned work was saved.'];
        $parts[] = $createdCount . ' created';
        if ($skipped !== []) {
            $parts[] = count($skipped) . ' skipped because of conflicts';
        }

        return implode(', ', $parts) . '.';
    }

    /** @param list<array<string,mixed>> $skipped */
    private function recurrenceSkippedMessage(array $skipped): string
    {
        $dates = [];
        foreach ($skipped as $item) {
            $date = (string) ($item['date'] ?? '');
            $conflict = (string) ($item['conflict_range'] ?? '');
            if ($date !== '') {
                $dates[] = $date . ($conflict !== '' ? ' (' . $conflict . ')' : '');
            }
        }

        $dates = array_values(array_unique($dates));
        $preview = implode(', ', array_slice($dates, 0, 8));
        if (count($dates) > 8) {
            $preview .= ' and ' . (count($dates) - 8) . ' more';
        }

        return count($skipped) . ' skipped because of conflicts'
            . ($preview !== '' ? ': ' . $preview . '.' : '.');
    }

    private function postedRecurrence(): ?array
    {
        $type = (string) $this->request->input('recurrence_type', '');
        if ($type === '' || $type === 'none') {
            return null;
        }
        if (!in_array($type, Schedule::RECURRENCE_TYPES, true)) {
            return null;
        }

        $until = (string) $this->request->input('repeat_until', '');
        $until = $until !== '' ? $until : null;

        $daysRaw = $this->request->input('days_of_week', []);
        $days = [];
        if (is_array($daysRaw)) {
            foreach ($daysRaw as $day) {
                $n = (int) $day;
                if ($n >= 1 && $n <= 7) {
                    $days[] = $n;
                }
            }
        } elseif (is_string($daysRaw) && $daysRaw !== '') {
            foreach (explode(',', $daysRaw) as $part) {
                $n = (int) trim($part);
                if ($n >= 1 && $n <= 7) {
                    $days[] = $n;
                }
            }
        }

        return [
            'recurrence_type' => $type,
            'repeat_until'    => $until,
            'days_of_week'    => $days === [] ? null : implode(',', array_unique($days)),
        ];
    }

    /** @return array<string, mixed> */
    private function loadEditable(int $id): array
    {
        if ($id < 1) {
            $this->notFound();
        }

        $row = $this->schedules->findWithRelations($id);
        if ($row === null) {
            $this->notFound();
        }

        $userId  = (int) AuthHelper::id();
        $viewTeam = PermissionHelper::has('schedule.view_team');
        if (!$this->schedules->userCanView($row, $userId, $viewTeam)) {
            $this->forbidden();
        }

        if (!$this->schedules->userCanEdit(
            $row,
            $userId,
            AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
            AuthHelper::hasRole(AuthHelper::ROLE_MANAGER)
        )) {
            $this->forbidden();
        }

        return $row;
    }

    private function assertCanAssign(int $userId, int $projectId): void
    {
        $this->assertCanViewProject($projectId);

        $viewer = (int) AuthHelper::id();
        $canAssignOthers = PermissionHelper::has('schedule.view_team') || AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);

        if ($userId !== $viewer && !$canAssignOthers) {
            $this->forbidden();
        }

        $project = $this->projects->find($projectId);
        if ($project === null) {
            $this->notFound();
        }

        $member = (new ProjectMember())->isMember($projectId, $userId)
            || (int) ($project['manager_id'] ?? 0) === $userId
            || (int) ($project['created_by'] ?? 0) === $userId;

        if (!$member && !AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            $this->failOrJson('/schedule', ['user_id' => 'That person is not on this project.']);
        }
    }

    private function assertCanViewProject(int $projectId): void
    {
        if ($projectId < 1) {
            $this->notFound();
        }

        $project = $this->projects->find($projectId);
        if ($project === null) {
            $this->notFound();
        }

        if (!$this->projects->userCanView(
            $project,
            (int) AuthHelper::id(),
            PermissionHelper::has('projects.view_all')
        )) {
            $this->forbidden();
        }
    }

    private function wantsOverride(Request $request): bool
    {
        $raw = $request->input('override_conflict', 0);

        return $raw === 1 || $raw === '1' || $raw === true || $raw === 'true' || $raw === 'on';
    }

    /** @param list<array<string, mixed>> $conflicts */
    private function conflictResponse(array $conflicts): never
    {
        $message = 'This overlaps existing planned work.';

        if ($this->request->wantsJson()) {
            $this->json([
                'ok'        => false,
                'conflict'  => true,
                'message'   => $message,
                'conflicts' => $conflicts,
            ], 409);
        }

        $detail = $conflicts[0]['project_name'] . ' (' . $conflicts[0]['time_range'] . ')';
        $this->flash('warning', $message . ' Conflicting: ' . $detail . '. Save again with override to keep both.');
        $this->redirect('/schedule');
    }

    /** @param array<string, string> $errors */
    private function failOrJson(string $failPath, array $errors): never
    {
        if ($this->request->wantsJson()) {
            $this->json(['ok' => false, 'errors' => $errors], 422);
        }
        $this->backWithErrors($failPath, $errors);
    }

    /** @return array{0: string, 1: string} */
    private function rangeFromRequest(Request $request): array
    {
        $startRaw = (string) $request->input('start', '');
        $endRaw   = (string) $request->input('end', '');

        $startUtc = $this->parseIncomingDatetime($startRaw);
        $endUtc   = $this->parseIncomingDatetime($endRaw);

        if ($startUtc === null || $endUtc === null) {
            $zone = new DateTimeZone(FormatHelper::displayTimezone());
            $today = new DateTimeImmutable('today', $zone);
            $weekStart = $today->modify(WorkspacePolicy::weekModifier())->setTime(0, 0, 0);
            $utc = new DateTimeZone('UTC');
            $startUtc = $weekStart->setTimezone($utc)->format('Y-m-d H:i:s');
            $endUtc   = $weekStart->modify('+7 days')->setTimezone($utc)->format('Y-m-d H:i:s');
        }

        return [$startUtc, $endUtc];
    }

    private function parseIncomingDatetime(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $value = str_replace('T', ' ', $value);
        $value = preg_replace('/Z$/', '', $value) ?? $value;
        $value = preg_replace('/\.\d+$/', '', $value) ?? $value;

        if (preg_match('/[+-]\d{2}:\d{2}$/', $value) === 1 || str_ends_with($value, 'Z')) {
            try {
                $dt = new DateTimeImmutable($value);
                return $dt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
            } catch (Exception) {
                return null;
            }
        }

        $utc = FormatHelper::toUtc($value);
        if ($utc !== null) {
            return $utc;
        }

        foreach (['Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d'] as $format) {
            $parsed = DateTimeImmutable::createFromFormat('!' . $format, $value, new DateTimeZone('UTC'));
            $errors = DateTimeImmutable::getLastErrors();
            if ($parsed !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
                return $parsed->format('Y-m-d H:i:s');
            }
        }

        return null;
    }

    private function toIsoUtc(string $utc): string
    {
        try {
            return (new DateTimeImmutable($utc, new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');
        } catch (Exception) {
            return $utc;
        }
    }

    private function parseLocalDate(string $value): DateTimeImmutable
    {
        $zone = new DateTimeZone(FormatHelper::displayTimezone());
        if ($value !== '') {
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $value, $zone);
            $errors = DateTimeImmutable::getLastErrors();
            if ($parsed !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
                return $parsed;
            }
        }

        return new DateTimeImmutable('today', $zone);
    }

    /**
     * @param list<array<string, mixed>> $items
     * @return array<string, list<array<string, mixed>>>
     */
    private function groupByLocalDay(array $items): array
    {
        $groups = [];
        foreach ($items as $item) {
            $key = FormatHelper::datetime((string) $item['start_datetime'], 'Y-m-d');
            $label = FormatHelper::datetime((string) $item['start_datetime'], 'l, F j');
            $groups[$key]['label'] = $label;
            $groups[$key]['items'][] = $item;
        }

        return $groups;
    }

    /** @return list<array<string, mixed>> */
    private function visibleProjects(int $userId, bool $viewTeam): array
    {
        $sql = "SELECT p.id, p.name, p.project_code, p.status
                FROM projects p
                WHERE p.status NOT IN ('Cancelled','Archived')";
        $params = [];

        if (!PermissionHelper::has('projects.view_all')) {
            $sql .= ' AND (p.manager_id = :uid_m OR p.created_by = :uid_c OR EXISTS (
                SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = :uid_p
            ))';
            $params = ['uid_m' => $userId, 'uid_c' => $userId, 'uid_p' => $userId];
        }

        $sql .= ' ORDER BY p.name ASC';

        return Database::fetchAll($sql, $params);
    }

    /** @return list<array<string, mixed>> */
    private function activePeople(): array
    {
        $sql = "SELECT DISTINCT u.id, u.name, u.email, r.name AS role, u.job_title
                FROM users u
                INNER JOIN roles r ON r.id = u.role_id
                WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')";
        $params = [];

        if (!PermissionHelper::has('projects.view_all')) {
            $viewer = (int) AuthHelper::id();
            $sql .= ' AND EXISTS (
                SELECT 1 FROM projects p
                WHERE (p.manager_id = :uid_mgr OR p.created_by = :uid_own)
                  AND (
                      p.manager_id = u.id
                      OR p.created_by = u.id
                      OR EXISTS (
                          SELECT 1 FROM project_members pm
                          WHERE pm.project_id = p.id AND pm.user_id = u.id
                      )
                  )
            )';
            $params = [
                'uid_mgr' => $viewer,
                'uid_own' => $viewer,
            ];
        }

        $sql .= ' ORDER BY u.name ASC';

        return Database::fetchAll($sql, $params);
    }

    /** @return list<array<string, mixed>> */
    private function assigneesForProject(int $projectId): array
    {
        return Database::fetchAll(
            "SELECT DISTINCT u.id, u.name, u.email, r.name AS role, u.job_title
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             LEFT JOIN project_members pm ON pm.user_id = u.id AND pm.project_id = :pid_m
             LEFT JOIN projects p ON p.id = :pid_p
             WHERE u.status = 'active'
               AND (pm.id IS NOT NULL OR p.manager_id = u.id OR p.created_by = u.id OR r.name = 'admin')
             ORDER BY u.name ASC",
            ['pid_m' => $projectId, 'pid_p' => $projectId]
        );
    }

    /** @return list<array<string, mixed>> */
    private function tasksForProject(int $projectId): array
    {
        if (!$this->tasksTableExists()) {
            return [];
        }

        return Database::fetchAll(
            'SELECT id, name, status FROM tasks WHERE project_id = :id ORDER BY name ASC',
            ['id' => $projectId]
        );
    }

    private function tasksTableExists(): bool
    {
        return SchemaHelper::tableExists('tasks');
    }

    /**
     * Notify the person a block belongs to that it changed, plus a warning when the
     * save overrode an overlap. The acting user is never notified about their own
     * change; when a block is reassigned the previous owner is told too.
     *
     * @param array<string, mixed>       $payload
     * @param list<array<string, mixed>> $conflicts
     * @param array<string, mixed>|null  $previous
     */
    private function notifyScheduleChange(array $payload, array $conflicts, int $scheduleId, ?array $previous = null): void
    {
        $actorId = (int) AuthHelper::id();
        $userId  = (int) ($payload['user_id'] ?? 0);

        if ($userId < 1) {
            return;
        }

        $project     = $this->projects->find((int) ($payload['project_id'] ?? 0));
        $projectName = $project !== null ? (string) $project['name'] : '';
        $startLocal  = FormatHelper::datetime((string) ($payload['start_datetime'] ?? ''), 'M j, H:i');

        if ($userId !== $actorId) {
            NotificationHelper::scheduleChanged($userId, $projectName, $startLocal, '/schedule/my');
        }

        if ($userId !== $actorId && $conflicts !== []) {
            NotificationHelper::scheduleConflict($userId, $conflicts, '/schedule/my');
        }

        if ($previous !== null) {
            $formerId = (int) ($previous['user_id'] ?? $userId);
            if ($formerId !== $userId && $formerId !== $actorId) {
                NotificationHelper::push(
                    $formerId,
                    Notification::TYPE_INFO,
                    'Schedule changed',
                    'Your planned work on ' . ($projectName !== '' ? $projectName : 'a project') . ' was reassigned.',
                    '/schedule/my'
                );
            }
        }
    }

    /** @param array<string, mixed> $row */
    private function notifyScheduleCancelled(array $row): void
    {
        $userId = (int) ($row['user_id'] ?? 0);

        if ($userId < 1 || $userId === (int) AuthHelper::id()) {
            return;
        }

        $projectName = (string) ($row['project_name'] ?? '');

        NotificationHelper::push(
            $userId,
            Notification::TYPE_WARNING,
            'Scheduled work cancelled',
            'Your planned work on ' . ($projectName !== '' ? $projectName : 'a project') . ' was cancelled.',
            '/schedule/my'
        );
    }

    /**
     * Raise one reminder for each of the user's own blocks that starts within the
     * next two hours. NotificationHelper::scheduleApproaching() de-duplicates, so
     * opening the page repeatedly does not spam the bell.
     *
     * @param list<array<string, mixed>> $items
     */
    private function remindApproaching(array $items): void
    {
        $now   = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $until = $now->modify('+2 hours');

        foreach ($items as $item) {
            try {
                $start = new DateTimeImmutable((string) $item['start_datetime'], new DateTimeZone('UTC'));
            } catch (Exception) {
                continue;
            }

            if ($start < $now || $start > $until) {
                continue;
            }

            NotificationHelper::scheduleApproaching(
                (int) $item['user_id'],
                (string) ($item['project_name'] ?? ''),
                FormatHelper::datetime((string) $item['start_datetime'], 'M j, H:i'),
                (int) $item['id'],
                2
            );
        }
    }
}