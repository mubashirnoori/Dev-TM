# TimeTrack database migration order

## Fresh install
1. `database/install.sql` — final schema including Phase 13 fixes 01-11 (indexes/CHECK, must_change_password, no time_entries.status lock columns, one timesheet per user per period, client_users, recurrence_parent_id).
2. Run `database/seed.sql` separately if demo accounts/data are wanted.

## Existing installation upgrade (live dump 2026-10-03)

Run in phpMyAdmin against a copy first. Take a backup before every step.

1. Historical baseline already applied on live (schema through phase 12 / 16). Do not re-run seed.
2. Phase 13, unique numbers only:

| File | Purpose |
|---|---|
| `database/phase13/01_base.sql` | time_entries indexes + CHECK |
| `database/phase13/02_must_change_password.sql` | users.must_change_password |
| `database/phase13/03_timer_auto_stopped.sql` | auto_stopped (already present live; idempotent) |
| `database/phase13/04_drop_entry_status.sql` | copy leftover Approved rows into timesheets, drop status/approved_by/approved_at |
| `database/phase13/06_settings_workspace_ownership.sql` | settings workspace ownership |
| `database/phase13/07_timesheets_1_and_3.preview.sql` then `.cleanup.sql` | merge live sheets 1 and 3; attach entries 8 and 11 |
| `database/phase13/07_restore_timesheet_period_unique.sql` | restore uq_timesheets_user_period |
| `database/phase13/08_remove_role_schema_duplicates.sql` | role_id wins; copy assigned_to; drop record_id |
| `database/phase13/09_client_users.sql` | client_users |
| `database/phase13/10_schedule_bad_rows.preview.sql` then `.cleanup.sql` | inspect then delete known multi-day Test rows 3-16 |
| `database/phase13/10_schedule_recurrence_parent.sql` | recurrence_parent_id |
| `database/phase13/11_enable_scheduling.sql` | scheduling_enabled = 1 where missing |

3. Do **not** run these superseded stubs (they only print SKIPPED):
   - `05_allow_multiple_submission_batches.sql` (replaced by 07)
   - `05_schedule_recurrence_parent.sql` / `05_schedule_bad_rows.*` (replaced by 10)
   - `15_enable_scheduling.sql` (replaced by 11)
4. `database/phase14_step19_reports.sql` (billable_rate / schedule_id / break_minutes and report permissions only; does **not** re-add time_entries.status)
5. `database/phase15_imports.sql`
6. `database/phase16_desktop_idle.sql` (already on live; idempotent)

Rollback: `database/phase13/ROLLBACK_ALL.sql` (reverse order; some steps refuse destructive reversal).

## Verification
Compared against `_dev/u897128490_timetrack_fixed.sql` (dump 2026-10-03). See `docs/LIVE_SCHEMA_DIFF.md`.
