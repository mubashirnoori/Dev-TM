-- TimeTrack Step 19: Reports module + frozen billable_rate / schedule / break.
-- Safe to run on the live dump and on newer installs.
-- Do NOT re-add time_entries.status / approved_by / approved_at: Phase 13
-- migration 04 dropped those. The only lock is timesheet membership.
-- Integrity: running this after 04 must not restore a second lock model.
SET NAMES utf8mb4;

ALTER TABLE time_entries
    ADD COLUMN IF NOT EXISTS schedule_id INT UNSIGNED NULL AFTER task_id,
    ADD COLUMN IF NOT EXISTS break_minutes INT UNSIGNED NOT NULL DEFAULT 0 AFTER duration_seconds,
    ADD COLUMN IF NOT EXISTS billable_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER is_billable;

ALTER TABLE time_entries
    ADD INDEX IF NOT EXISTS idx_time_entries_schedule (schedule_id),
    ADD INDEX IF NOT EXISTS idx_time_entries_billable (is_billable);

-- Snapshot the current project rate exactly once for legacy entries that did not
-- previously have a frozen rate. New timer/manual entries already write their
-- frozen rate through Timer/TimeEntry. Never overwrite a non-zero stored rate.
UPDATE time_entries te
INNER JOIN projects p ON p.id = te.project_id
SET te.billable_rate = CASE
    WHEN te.is_billable = 1 THEN COALESCE(p.hourly_rate,0)
    ELSE 0
END
WHERE COALESCE(te.billable_rate,0) = 0;

-- Add foreign keys only when they do not already exist.
SET @db_name := DATABASE();
SET @sql := IF(
    EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema=@db_name AND table_name='time_entries' AND constraint_name='fk_time_entries_schedule'),
    'SELECT 1',
    'ALTER TABLE time_entries ADD CONSTRAINT fk_time_entries_schedule FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE SET NULL ON UPDATE CASCADE'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
INSERT INTO permissions (name, display_name, module, description) VALUES
('reports.view','View reports','reports','Open reports.'),
('reports.export','Export reports','reports','Download reports as CSV.'),
('reports.billing','View billing figures','reports','See rates and billable amounts.')
ON DUPLICATE KEY UPDATE display_name=VALUES(display_name), module=VALUES(module), description=VALUES(description);

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('admin','manager') AND p.name IN ('reports.view','reports.export','reports.billing');
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('employee','client') AND p.name='reports.view';
