-- TimeTrack Phase 13 / Step 17 rollback.
-- Restores the duplicate columns. Existing task_assignees, users.role_id
-- and activity_logs.entity_id rows are left intact.
-- Idempotent on MariaDB 11.8.

SET @db_name := DATABASE();

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name
          AND table_name = 'tasks'
          AND column_name = 'assigned_to'
    ),
    'SELECT 1',
    'ALTER TABLE `tasks` ADD COLUMN `assigned_to` int UNSIGNED DEFAULT NULL AFTER `priority`'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'tasks'
          AND index_name = 'idx_tasks_assigned'
    ),
    'SELECT 1',
    'ALTER TABLE `tasks` ADD INDEX `idx_tasks_assigned` (`assigned_to`)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_schema = @db_name
          AND table_name = 'tasks'
          AND constraint_name = 'fk_tasks_assigned'
    ),
    'SELECT 1',
    'ALTER TABLE `tasks` ADD CONSTRAINT `fk_tasks_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

UPDATE tasks t
INNER JOIN (
    SELECT ta.task_id, MIN(ta.user_id) AS user_id
    FROM task_assignees ta
    GROUP BY ta.task_id
) x ON x.task_id = t.id
SET t.assigned_to = x.user_id
WHERE t.assigned_to IS NULL;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name
          AND table_name = 'activity_logs'
          AND column_name = 'record_id'
    ),
    'SELECT 1',
    'ALTER TABLE `activity_logs` ADD COLUMN `record_id` int UNSIGNED DEFAULT NULL AFTER `entity_id`'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

UPDATE activity_logs
SET record_id = entity_id
WHERE record_id IS NULL AND entity_id IS NOT NULL;

CREATE OR REPLACE SQL SECURITY INVOKER VIEW `audit_logs` AS
    SELECT `id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `record_id`,
           `ip_address`, `user_agent`, `meta`, `old_value`, `new_value`, `created_at`
    FROM `activity_logs`;

ALTER TABLE `project_members`
    MODIFY `project_role` varchar(60) NOT NULL DEFAULT 'Member';
