-- TimeTrack Phase 13 / FIX 9
-- client_users(user_id, client_id) with FKs and a unique key.
-- Integrity: a client login cannot see another organisation's projects
-- by guessing a URL; membership is explicit and enforced in PHP.

SET @db_name := DATABASE();

CREATE TABLE IF NOT EXISTS `client_users` (
    `user_id` int UNSIGNED NOT NULL,
    `client_id` int UNSIGNED NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`, `client_id`),
    UNIQUE KEY `uq_client_users_user_client` (`user_id`, `client_id`),
    KEY `idx_client_users_client` (`client_id`),
    CONSTRAINT `fk_client_users_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_client_users_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Older seeds granted schedule.view to clients. Controllers already 403 /schedule;
-- drop the leftover grant so a permission check cannot reopen the calendar.
DELETE rp FROM role_permissions rp
INNER JOIN roles r ON r.id = rp.role_id
INNER JOIN permissions p ON p.id = rp.permission_id
WHERE r.name = 'client'
  AND p.name IN (
      'schedule.view', 'schedule.create', 'schedule.edit', 'schedule.delete', 'schedule.view_team',
      'time.track', 'time.view_own', 'time.edit_own', 'time.approve',
      'users.view', 'settings.manage', 'reports.export', 'reports.billing'
  );
