-- TimeTrack Phase 13 / FIX 3
-- READ-ONLY preview of known bad recurrence rows (id 3-16).
-- Expected shape: manager/user "Test" and an approximately 13-day span.
-- Review this result BEFORE running 10_schedule_bad_rows.cleanup.sql.

SELECT
    s.id,
    s.user_id,
    u.name AS user_name,
    s.project_id,
    s.task_id,
    s.start_datetime,
    s.end_datetime,
    TIMESTAMPDIFF(DAY, s.start_datetime, s.end_datetime) AS span_days,
    TIMESTAMPDIFF(HOUR, s.start_datetime, s.end_datetime) AS span_hours,
    s.status,
    s.created_by,
    s.recurrence_parent_id
FROM schedules s
JOIN users u ON u.id = s.user_id
WHERE s.id BETWEEN 3 AND 16
ORDER BY s.id;

SELECT COUNT(*) AS matching_bad_rows
FROM schedules s
JOIN users u ON u.id = s.user_id
WHERE s.id BETWEEN 3 AND 16
  AND u.name = 'Test'
  AND TIMESTAMPDIFF(HOUR, s.start_datetime, s.end_datetime) >= (12 * 24);
