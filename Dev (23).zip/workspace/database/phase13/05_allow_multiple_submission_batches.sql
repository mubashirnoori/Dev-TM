-- SUPERSEDED by 07_restore_timesheet_period_unique.sql.
-- Do not run this file. It dropped uq_timesheets_user_period and allowed
-- overlapping sheets for the same user and period.
-- Kept only so existing run logs and older zip notes still resolve.
-- Integrity: one non-overlapping timesheet period per user is required.

SELECT 'SKIPPED: 05_allow_multiple_submission_batches.sql is superseded by 07_restore_timesheet_period_unique.sql' AS notice;
