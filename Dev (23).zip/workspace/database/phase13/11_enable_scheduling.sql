-- TimeTrack Phase 13 / FIX 3 leftover (was 15_enable_scheduling)
-- Show Schedule in the sidebar for existing workspaces that never flipped the module on.
-- Default for new workspaces is on; this only fills a missing row or upgrades an implicit off.
-- Safe to run more than once.

START TRANSACTION;

INSERT INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id, 'scheduling_enabled', '1', UTC_TIMESTAMP()
FROM workspaces w
WHERE NOT EXISTS (
    SELECT 1 FROM workspace_settings ws
    WHERE ws.workspace_id = w.id AND ws.setting_key = 'scheduling_enabled'
);

UPDATE workspace_settings
SET setting_value = '1', updated_at = UTC_TIMESTAMP()
WHERE setting_key = 'scheduling_enabled'
  AND setting_value IN ('0', '');

COMMIT;
