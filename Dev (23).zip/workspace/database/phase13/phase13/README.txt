This nested database/phase13/phase13/ folder is obsolete.
Canonical migrations live in database/phase13/.
The old copies were moved to _dev/obsolete_phase13_nested/ and must not ship in a release zip.
