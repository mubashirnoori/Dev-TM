-- SUPERSEDED by 11_enable_scheduling.sql.
-- Do not run this file. Kept so older zip notes still resolve.

SELECT 'SKIPPED: 15_enable_scheduling.sql is superseded by 11_enable_scheduling.sql' AS notice;
