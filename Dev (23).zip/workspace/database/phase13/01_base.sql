-- TimeTrack Phase 13 / Step 4
-- Indexes on time_entries(user_id, started_at) and (project_id, started_at)
-- plus CHECK (ended_at IS NULL OR ended_at >= started_at).
-- Idempotent on MariaDB 11.8. Preview invalid rows first; the CHECK is added
-- only when no violating rows remain.
-- Integrity: overlap and report queries must not table-scan; inverted intervals
-- cannot be stored.

SET @db_name := DATABASE();

SELECT te.id, te.user_id, te.started_at, te.ended_at
FROM time_entries te
WHERE te.ended_at IS NOT NULL AND te.ended_at < te.started_at;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'time_entries'
          AND index_name = 'idx_time_entries_user_started'
    ),
    'SELECT 1',
    'ALTER TABLE `time_entries` ADD INDEX `idx_time_entries_user_started` (`user_id`, `started_at`)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'time_entries'
          AND index_name = 'idx_time_entries_project_started'
    ),
    'SELECT 1',
    'ALTER TABLE `time_entries` ADD INDEX `idx_time_entries_project_started` (`project_id`, `started_at`)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @bad := (
    SELECT COUNT(*) FROM time_entries
    WHERE ended_at IS NOT NULL AND ended_at < started_at
);

SET @has_chk := (
    SELECT COUNT(*) FROM information_schema.table_constraints
    WHERE constraint_schema = @db_name
      AND table_name = 'time_entries'
      AND constraint_name = 'chk_time_entries_ended_after_started'
      AND constraint_type = 'CHECK'
);

SET @sql := IF(
    @has_chk > 0 OR @bad > 0,
    'SELECT 1',
    'ALTER TABLE `time_entries` ADD CONSTRAINT `chk_time_entries_ended_after_started` CHECK (`ended_at` IS NULL OR `ended_at` >= `started_at`)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
