-- Rollback of 09_client_users.sql.

DROP TABLE IF EXISTS `client_users`;
