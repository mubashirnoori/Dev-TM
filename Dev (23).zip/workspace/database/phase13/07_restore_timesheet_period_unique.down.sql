-- Rollback of 07_restore_timesheet_period_unique.sql.
-- Drops the unique period key so overlapping sheets can exist again.
-- Does not recreate deleted duplicate timesheet rows.

SET @db_name := DATABASE();

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'timesheets'
          AND index_name = 'uq_timesheets_user_period'
    ),
    'ALTER TABLE `timesheets` DROP INDEX `uq_timesheets_user_period`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
