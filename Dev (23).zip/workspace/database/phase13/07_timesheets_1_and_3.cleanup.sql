-- TimeTrack Phase 13 / FIX 4
-- Merge leftover timesheets 1 and 3 for user 1 into one weekly sheet
-- (2026-09-28..2026-10-04) and attach entries 8 and 11.
-- Run 07_timesheets_1_and_3.preview.sql first. Safe to run twice.

START TRANSACTION;

-- Keep sheet 1 as the weekly sheet for 2026-09-28..2026-10-04.
UPDATE timesheet_entries
SET timesheet_id = 1
WHERE timesheet_id = 3
  AND time_entry_id NOT IN (SELECT time_entry_id FROM (SELECT time_entry_id FROM timesheet_entries WHERE timesheet_id = 1) k);

INSERT IGNORE INTO timesheet_entries (timesheet_id, time_entry_id, created_at)
SELECT 1, te.id, UTC_TIMESTAMP()
FROM time_entries te
WHERE te.id IN (8, 11)
  AND te.user_id = 1;

DELETE FROM timesheets WHERE id = 3 AND user_id = 1;

UPDATE timesheets t
SET total_seconds = (
        SELECT COALESCE(SUM(te.duration_seconds), 0)
        FROM timesheet_entries tse
        INNER JOIN time_entries te ON te.id = tse.time_entry_id
        WHERE tse.timesheet_id = t.id
    ),
    billable_seconds = (
        SELECT COALESCE(SUM(CASE WHEN te.is_billable = 1 THEN te.duration_seconds ELSE 0 END), 0)
        FROM timesheet_entries tse
        INNER JOIN time_entries te ON te.id = tse.time_entry_id
        WHERE tse.timesheet_id = t.id
    ),
    updated_at = UTC_TIMESTAMP()
WHERE t.id = 1 AND t.user_id = 1;

COMMIT;
