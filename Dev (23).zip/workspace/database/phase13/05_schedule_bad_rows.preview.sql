-- SUPERSEDED by 10_schedule_bad_rows.preview.sql.
-- Do not run this file.

SELECT 'SKIPPED: 05_schedule_bad_rows.preview.sql is superseded by 10_schedule_bad_rows.preview.sql' AS notice;
