-- TimeTrack Phase 13 / FIX 4
-- READ-ONLY preview of live timesheets 1 and 3 (user 1) before merge.
-- Expected: sheet 1 is Submitted 2026-09-28..2026-10-04; sheet 3 is Rejected
-- 2026-10-01..2026-10-02. Entries 8 and 11 should be attached to the keeper.

SELECT id, user_id, start_date, end_date, status, submission_token, total_seconds
FROM timesheets
WHERE id IN (1, 3)
ORDER BY id;

SELECT tse.timesheet_id, tse.time_entry_id, te.started_at, te.ended_at, te.duration_seconds
FROM timesheet_entries tse
INNER JOIN time_entries te ON te.id = tse.time_entry_id
WHERE tse.timesheet_id IN (1, 3)
ORDER BY tse.timesheet_id, tse.time_entry_id;

SELECT id, user_id, started_at, ended_at, duration_seconds
FROM time_entries
WHERE id IN (8, 11);
