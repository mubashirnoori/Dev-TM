-- SUPERSEDED by 10_schedule_recurrence_parent.down.sql.

SELECT 'SKIPPED: 05_schedule_recurrence_parent.down.sql is superseded by 10_schedule_recurrence_parent.down.sql' AS notice;
