-- TimeTrack Phase 13 complete rollback, reverse order.
-- Review before running on production. Some rollback steps intentionally refuse
-- destructive reversal when history would be lost.
-- This script does NOT delete user/time/project data.
--
-- Ordered upgrade (live DB) is the reverse of this list:
--   01_base
--   02_must_change_password
--   03_timer_auto_stopped
--   04_drop_entry_status
--   06_settings_workspace_ownership
--   07_restore_timesheet_period_unique
--   08_remove_role_schema_duplicates
--   09_client_users
--   10_schedule_recurrence_parent
--   11_enable_scheduling
-- Do NOT run 05_allow_multiple_submission_batches.sql (replaced by 07).
-- Do NOT run 05_schedule_* or 15_enable_scheduling.sql (replaced by 10 / 11).
-- Live leftover sheets 1+3: run 07_timesheets_1_and_3.preview.sql then .cleanup.sql
-- before 07_restore_timesheet_period_unique.sql.

SOURCE database/phase13/11_enable_scheduling.down.sql;
SOURCE database/phase13/10_schedule_recurrence_parent.down.sql;
SOURCE database/phase13/09_client_users.down.sql;
SOURCE database/phase13/08_remove_role_schema_duplicates.down.sql;
SOURCE database/phase13/07_restore_timesheet_period_unique.down.sql;
SOURCE database/phase13/06_settings_workspace_ownership.down.sql;
SOURCE database/phase13/04_drop_entry_status.down.sql;
SOURCE database/phase13/03_timer_auto_stopped.down.sql;
SOURCE database/phase13/02_must_change_password.down.sql;
SOURCE database/phase13/01_base.down.sql;
