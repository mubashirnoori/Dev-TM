-- SUPERSEDED by 10_schedule_bad_rows.cleanup.sql.
-- Do not run this file.

SELECT 'SKIPPED: 05_schedule_bad_rows.cleanup.sql is superseded by 10_schedule_bad_rows.cleanup.sql' AS notice;
