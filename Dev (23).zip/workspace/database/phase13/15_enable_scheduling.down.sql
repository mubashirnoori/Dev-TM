-- SUPERSEDED by 11_enable_scheduling.down.sql.

SELECT 'SKIPPED: 15_enable_scheduling.down.sql is superseded by 11_enable_scheduling.down.sql' AS notice;
