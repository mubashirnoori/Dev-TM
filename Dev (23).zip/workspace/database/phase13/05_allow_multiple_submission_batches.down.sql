-- SUPERSEDED. 05_allow_multiple_submission_batches.sql is a no-op.
-- Period uniqueness is restored by 07_restore_timesheet_period_unique.sql.
-- Integrity: overlapping timesheets must not be re-enabled.

SELECT 'SKIPPED: 05_allow_multiple_submission_batches.down.sql is superseded by 07_restore_timesheet_period_unique.down.sql' AS notice;
