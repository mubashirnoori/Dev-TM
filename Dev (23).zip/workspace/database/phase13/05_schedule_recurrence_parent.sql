-- SUPERSEDED by 10_schedule_recurrence_parent.sql.
-- Do not run this file. Kept so older zip notes still resolve.
-- Integrity: recurrence copies must keep recurrence_parent_id.

SELECT 'SKIPPED: 05_schedule_recurrence_parent.sql is superseded by 10_schedule_recurrence_parent.sql' AS notice;
