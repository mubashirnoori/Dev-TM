-- Rollback for Step 19 report permissions only.
-- The time-entry columns are retained because the current TimeEntry/timesheet
-- application depends on them; removing them would roll back unrelated phases.
DELETE rp FROM role_permissions rp
INNER JOIN permissions p ON p.id=rp.permission_id
WHERE p.name IN ('reports.view','reports.export','reports.billing');
DELETE FROM permissions WHERE name IN ('reports.view','reports.export','reports.billing');
