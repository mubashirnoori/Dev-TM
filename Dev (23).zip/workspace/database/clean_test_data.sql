-- TimeTrack clean-test-data script.
-- INTENTIONALLY DESTRUCTIVE. Run only against a dedicated test database.
-- Keeps schema, roles, permissions and the workspace row.
-- Truncates application/demo activity and user-created business data.
SET FOREIGN_KEY_CHECKS=0;
TRUNCATE TABLE timesheet_entries;
TRUNCATE TABLE timesheets;
TRUNCATE TABLE time_entries;
TRUNCATE TABLE timer_idle_events;
TRUNCATE TABLE active_timers;
TRUNCATE TABLE task_assignees;
TRUNCATE TABLE tasks;
TRUNCATE TABLE schedule_recurrences;
TRUNCATE TABLE schedules;
TRUNCATE TABLE project_favorites;
TRUNCATE TABLE project_members;
TRUNCATE TABLE projects;
TRUNCATE TABLE client_users;
TRUNCATE TABLE clients;
TRUNCATE TABLE notifications;
TRUNCATE TABLE activity_logs;
TRUNCATE TABLE desktop_agent_devices;
TRUNCATE TABLE desktop_agent_pairing_codes;
TRUNCATE TABLE agent_pair_attempts;
SET FOREIGN_KEY_CHECKS=1;
