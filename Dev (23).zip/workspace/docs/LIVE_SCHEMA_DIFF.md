# Live schema diff

Compared on 2026-10-04 against `_dev/u897128490_timetrack_fixed.sql` (dump 2026-10-03, MariaDB 11.8) and `database/install.sql`.

## Present on live (do not treat as missing)

- `time_entries.auto_stopped` — present
- `time_entries.status`, `approved_by`, `approved_at` — still present (drop via `04_drop_entry_status.sql`)
- `users.role` — still present as a denormalized cache of `roles.name` (role_id is authoritative; 08 syncs them)
- `activity_logs.record_id` — **not** in this dump (already gone)
- `tasks.assigned_to` — **not** in this dump (already gone; task_assignees is canonical)
- `agent_pair_attempts` — **not** in this dump (added by phase 16 / install.sql)

## Missing on live vs install.sql (apply Phase 13)

- `time_entries` indexes `idx_time_entries_user_started`, `idx_time_entries_project_started`
- CHECK `chk_time_entries_ended_after_started`
- `users.must_change_password`
- `client_users` table
- `timesheets.uq_timesheets_user_period` (live has only `idx_timesheets_user_period` after 05 dropped the unique key)
- `schedules.recurrence_parent_id` (confirm; dump may already have it from an earlier 05_schedule file)
- `timesheet_entries.time_entry_id` is `int` on live vs `bigint` in install.sql (matches time_entries.id)

## Live data notes for 07 / 10

- timesheets 1, 4, 5, 6 overlap user 1 period 2026-09-28..2026-10-04; sheet 3 is a Rejected 2026-10-01..2026-10-02 fragment. Preview then merge with `07_timesheets_1_and_3.*.sql` before restoring the unique key.
- timesheet_entries does not currently include time_entries 8 and 11 on a weekly sheet for user 1.

## After applying Phase 13 01-11

```sql
SHOW INDEX FROM time_entries WHERE Key_name IN ('idx_time_entries_user_started','idx_time_entries_project_started');
SHOW COLUMNS FROM users LIKE 'must_change_password';
SHOW COLUMNS FROM time_entries LIKE 'status';
SHOW INDEX FROM timesheets WHERE Key_name = 'uq_timesheets_user_period';
SHOW TABLES LIKE 'client_users';
SHOW COLUMNS FROM schedules LIKE 'recurrence_parent_id';
```
