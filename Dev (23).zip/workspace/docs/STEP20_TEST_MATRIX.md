# Step 20 — TimeTrack test matrix

Run against a clean staging database after `database/install.sql` plus seed, or against a copy of live after Phase 13 01-11. For every route below, also open the URL as each role; expected result is **403** (or login redirect when logged out). Feature-disabled routes may be 404.

## Role matrix

| Area | Admin | Manager | Employee | Client |
|---|---|---|---|---|
| Login / logout | yes | yes | yes | yes |
| Lockout / failed login | yes | yes | yes | yes |
| Forced password change | flag blocks all except /profile /logout | same | same | same |
| Users CRUD | yes | view only where granted | 403 | 403 |
| Client CRUD | yes | yes | 403 | 403 |
| Project CRUD | yes | yes | limited | own clients, read-only |
| Member access | yes | yes | own assignment | 403 |
| Timer start/pause/resume/stop | yes | yes | yes | 403 |
| Second-tab timer | yes | yes | yes | 403 |
| Manual entry/edit/delete | yes | yes | yes | 403 |
| Viewer cannot track or be assigned | yes | yes | yes | n/a |
| Time only on Active projects | yes (admins not exempt) | yes | yes | n/a |
| Time not before project start_date | yes | yes | yes | n/a |
| Completed/Cancelled task blocked on start/add/edit | yes | yes | yes | n/a |
| Overlap rejection | yes | yes | yes | n/a |
| 12-hour auto-stop | yes | yes | yes | n/a |
| Timesheet submit | yes | yes | yes | 403 |
| Approve/reject/resubmit | yes (not self) | own people only | 403 | 403 |
| Backdate into Approved period | 409 | 409 | 409 | n/a |
| Schedule create/recurrence/conflict | yes | yes | granted schedule roles | 403 |
| Notifications | yes | yes | yes | yes |
| Settings on/off | yes | 403 | 403 | 403 |
| /health public ok only | yes | yes | yes | yes |
| /admin/health | yes | 403 | 403 | 403 |
| Dark mode | yes | yes | yes | yes |
| Mobile layout | yes | yes | yes | yes |
| Reports | yes | yes | own only | own client only |
| Report billing money | yes | yes | 403/hidden | 403/hidden |
| Report CSV export | yes | yes | 403 | 403 |

## Functional tests

1. **Login/lockout** — valid login succeeds; repeated invalid passwords lock the account; lockout expires; password change invalidates old password.
2. **Forced password** — set must_change_password=1; every URL except /profile, /profile/password, /logout redirects; after change the flag is 0 and password_changed_at is set.
3. **CRUD** — create/edit/delete a client, project, task and user according to role; direct URLs must not bypass controller checks.
4. **Tracking rules** — a viewer is blocked on timer start, manual add and edit; an entry before start_date is rejected; Completed/Cancelled tasks are rejected on start, add and edit; On Hold/Planning projects are not in the picker and are rejected.
5. **Timer** — start, pause, resume, stop; Pakistan/user-local display and UTC storage. Second tab: only one active timer.
6. **Manual/overlap** — add 01:00-02:00, then overlap; server rejects. Edit/delete unlocked entries; submitted/approved entries stay locked. Description-only edit also fails when locked.
7. **Auto-stop** — timer max 12 hours; cron_auto_stop.php sets auto_stopped=1.
8. **Timesheets** — one sheet per user per period; overlapping create fails; reject then resubmit reuses the same sheet; unsubmitted warning shows; sidebar pending count uses approverScope.
9. **Scheduling** — 5-day weekday recurrence makes 5 one-day rows with recurrence_parent_id; conflicts skipped and reported ("N created, M skipped because of conflicts").
10. **Notifications** — approval/rejection/timer events; unread/read/read-all.
11. **Workspace flags** — scheduling/projects/team/reports/timesheet on/off; sidebar and direct URL.
12. **Reports** — totals match Time page; employee sees self; client sees only linked clients; without reports.billing, money is hidden. CSV cells starting `= + - @` tab or CR get a leading apostrophe.
13. **CSP/assets** — Network tab shows no cdn.jsdelivr.net; console has zero CSP errors.
14. **Health** — public /health is `{ok, status}`; /admin/health details for admin, 403 employee, redirect logged-out.
15. **Maintenance flag** — create `storage/maintenance.flag` shows 503 + Retry-After + maintenance.html; delete restores the site. Other 503s are not rewritten.
16. **golive.php** — CLI only; demo @timetrack.local become inactive; new admin must change password.
17. **Mobile/dark mode** — 360px/390px/768px, navigation, filters, tables, dark theme.

## Direct URL authorization checklist

Test as every role: `/users`, `/clients`, `/projects`, `/team`, `/schedule`, `/schedule/team`, `/timesheets/team`, `/settings`, `/workspace`, `/reports`, `/reports/export.csv`, `/time`, `/timer`, `/timesheets`, `/profile`, `/admin/health`, `/import`, `/agent`.

Generate the client expected-result column with:

```bash
php tools/route_matrix.php
```
