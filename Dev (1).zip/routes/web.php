<?php
/**
 * Route table. Each later phase appends its routes here.
 *
 * Conventions:
 *  - Handlers are [ControllerClass::class, 'method'] and receive (Request $request, array $params).
 *  - State-changing routes (post/put/patch/delete) get automatic CSRF verification.
 *  - Authorization is NOT declared here; it lives in each controller's constructor
 *    so it cannot be forgotten when a route is added.
 */

declare(strict_types=1);

return static function (Router $router): void {
    $router->get('/', [HomeController::class, 'index']);
    $router->get('/health', [HealthController::class, 'index']);

    /* ---- Phase 1: authentication, profile, dashboard ---- */
    $router->get('/login', [AuthController::class, 'login']);
    $router->post('/login', [AuthController::class, 'authenticate']);
    $router->post('/logout', [AuthController::class, 'logout']);

    $router->get('/profile', [AuthController::class, 'profile']);
    $router->post('/profile', [AuthController::class, 'updateProfile']);
    $router->post('/profile/password', [AuthController::class, 'updatePassword']);

    $router->get('/dashboard', [DashboardController::class, 'index']);
    $router->post('/notifications/read', [DashboardController::class, 'markNotificationsRead']);
};
