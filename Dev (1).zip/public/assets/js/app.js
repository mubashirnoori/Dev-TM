/*
 * TimeTrack front-end behaviour.
 *
 * The Content-Security-Policy forbids inline scripts and inline event handlers, so every
 * interaction is wired here through data- attributes:
 *
 *   data-toggle-password="#id"     button that shows/hides a password field
 *   data-password-meter="#id"      password input that feeds a strength meter
 *   data-single-submit             form whose submit button is disabled after the first submit
 *   data-confirm="Message"         form or button that asks for confirmation first
 *   data-auto-dismiss="ms"         alert that closes itself (0 = stay)
 *   data-timer-start="ISO UTC"     element that shows a live elapsed clock (H:MM:SS)
 *
 * It also makes every same-origin fetch()/XHR state-changing request carry the CSRF
 * token from <meta name="csrf-token"> as the X-CSRF-Token header.
 */
(function () {
    'use strict';

    var csrfMeta = document.querySelector('meta[name="csrf-token"]');
    var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

    window.TT = {
        csrf: csrfToken,
        baseUrl: document.body ? (document.body.getAttribute('data-base-url') || '') : ''
    };

    /* ---- CSRF header on fetch() ------------------------------------- */
    if (window.fetch) {
        var nativeFetch = window.fetch.bind(window);

        window.fetch = function (input, init) {
            init = init || {};
            var method = String(init.method || (input && input.method) || 'GET').toUpperCase();
            var target = typeof input === 'string' ? input : (input && input.url) || '';
            var sameOrigin = true;

            try {
                sameOrigin = new URL(target, window.location.href).origin === window.location.origin;
            } catch (e) {
                sameOrigin = true;
            }

            if (sameOrigin && method !== 'GET' && method !== 'HEAD' && method !== 'OPTIONS') {
                var headers = new Headers(init.headers || (input && input.headers) || {});
                if (!headers.has('X-CSRF-Token') && csrfToken) {
                    headers.set('X-CSRF-Token', csrfToken);
                }
                headers.set('X-Requested-With', 'XMLHttpRequest');
                init.headers = headers;
            }

            return nativeFetch(input, init);
        };
    }

    /* ---- CSRF header on XMLHttpRequest ------------------------------ */
    if (window.XMLHttpRequest && csrfToken) {
        var nativeOpen = XMLHttpRequest.prototype.open;
        var nativeSend = XMLHttpRequest.prototype.send;

        XMLHttpRequest.prototype.open = function (method, url) {
            this._ttMethod = String(method || 'GET').toUpperCase();
            this._ttUrl = url;
            return nativeOpen.apply(this, arguments);
        };

        XMLHttpRequest.prototype.send = function () {
            var unsafe = this._ttMethod !== 'GET' && this._ttMethod !== 'HEAD' && this._ttMethod !== 'OPTIONS';
            var same = true;

            try {
                same = new URL(this._ttUrl, window.location.href).origin === window.location.origin;
            } catch (e) {
                same = true;
            }

            if (unsafe && same) {
                this.setRequestHeader('X-CSRF-Token', csrfToken);
                this.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            }

            return nativeSend.apply(this, arguments);
        };
    }

    document.addEventListener('DOMContentLoaded', function () {
        initPasswordToggles();
        initPasswordMeters();
        initSingleSubmit();
        initConfirm();
        initAutoDismiss();
        initTimers();
    });

    /* ---- show / hide password --------------------------------------- */
    function initPasswordToggles() {
        document.querySelectorAll('[data-toggle-password]').forEach(function (button) {
            var input = document.querySelector(button.getAttribute('data-toggle-password'));
            var icon = button.querySelector('i');
            if (!input) { return; }

            button.addEventListener('click', function () {
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                button.setAttribute('aria-pressed', show ? 'true' : 'false');
                button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
                if (icon) {
                    icon.className = show ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye';
                }
            });
        });
    }

    /* ---- password strength ------------------------------------------ */
    function initPasswordMeters() {
        document.querySelectorAll('[data-password-meter]').forEach(function (input) {
            var meter = document.querySelector(input.getAttribute('data-password-meter'));
            if (!meter) { return; }

            var bar = meter.querySelector('.strength-bar');
            var label = meter.querySelector('.strength-text');
            var levels = [
                { text: 'Too weak', color: '#c0392b', width: '20%' },
                { text: 'Weak', color: '#d9652b', width: '40%' },
                { text: 'Fair', color: '#d9a21b', width: '60%' },
                { text: 'Good', color: '#4f9d4a', width: '80%' },
                { text: 'Strong', color: '#1c7c3a', width: '100%' }
            ];

            input.addEventListener('input', function () {
                var value = input.value;

                if (value === '') {
                    meter.classList.remove('is-active');
                    return;
                }

                var score = 0;
                if (value.length >= 10) { score++; }
                if (value.length >= 14) { score++; }
                if (/[a-z]/.test(value) && /[A-Z]/.test(value)) { score++; }
                if (/\d/.test(value)) { score++; }
                if (/[^A-Za-z0-9]/.test(value)) { score++; }
                if (value.length < 10) { score = Math.min(score, 1); }

                var level = levels[Math.max(0, Math.min(score - 1, levels.length - 1))];
                if (score === 0) { level = levels[0]; }

                meter.classList.add('is-active');
                bar.style.setProperty('--score', level.width);
                bar.style.setProperty('--clr', level.color);
                label.textContent = level.text;
            });
        });
    }

    /* ---- prevent double submits ------------------------------------- */
    function initSingleSubmit() {
        document.querySelectorAll('form[data-single-submit]').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (event.defaultPrevented) { return; }

                if (form.getAttribute('data-submitting') === '1') {
                    event.preventDefault();
                    return;
                }

                form.setAttribute('data-submitting', '1');
                var buttons = form.querySelectorAll('button[type="submit"]');

                // Disable after the browser has collected the form data.
                window.setTimeout(function () {
                    buttons.forEach(function (button) {
                        button.disabled = true;
                        button.setAttribute('aria-busy', 'true');
                    });
                }, 0);
            });
        });

        // Coming back with the browser's Back button must not leave a dead form behind.
        window.addEventListener('pageshow', function (event) {
            if (!event.persisted) { return; }
            document.querySelectorAll('form[data-single-submit]').forEach(function (form) {
                form.removeAttribute('data-submitting');
                form.querySelectorAll('button[type="submit"]').forEach(function (button) {
                    button.disabled = false;
                    button.removeAttribute('aria-busy');
                });
            });
        });
    }

    /* ---- confirmation prompts --------------------------------------- */
    function initConfirm() {
        document.addEventListener('submit', function (event) {
            var form = event.target;
            var message = form && form.getAttribute ? form.getAttribute('data-confirm') : null;
            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });

        document.addEventListener('click', function (event) {
            var trigger = event.target.closest ? event.target.closest('button[data-confirm], a[data-confirm]') : null;
            if (trigger && !trigger.form && !window.confirm(trigger.getAttribute('data-confirm'))) {
                event.preventDefault();
            }
        });
    }

    /* ---- self-closing alerts ---------------------------------------- */
    function initAutoDismiss() {
        document.querySelectorAll('.alert[data-auto-dismiss]').forEach(function (alert) {
            var delay = parseInt(alert.getAttribute('data-auto-dismiss'), 10);
            if (!delay || delay < 1) { return; }

            window.setTimeout(function () {
                if (!document.body.contains(alert)) { return; }
                if (window.bootstrap && window.bootstrap.Alert) {
                    window.bootstrap.Alert.getOrCreateInstance(alert).close();
                } else {
                    alert.remove();
                }
            }, delay);
        });
    }

    /* ---- live elapsed clock ----------------------------------------- */
    function initTimers() {
        var clocks = document.querySelectorAll('[data-timer-start]');
        if (!clocks.length) { return; }

        function pad(n) { return n < 10 ? '0' + n : String(n); }

        function tick() {
            var now = Date.now();

            clocks.forEach(function (el) {
                var started = Date.parse(el.getAttribute('data-timer-start'));
                if (isNaN(started)) { return; }

                var seconds = Math.max(0, Math.floor((now - started) / 1000));
                var h = Math.floor(seconds / 3600);
                var m = Math.floor((seconds % 3600) / 60);
                var s = seconds % 60;
                el.textContent = h + ':' + pad(m) + ':' + pad(s);
            });
        }

        tick();
        window.setInterval(tick, 1000);
    }
})();
