<?php
/**
 * Immutable snapshot of the incoming HTTP request.
 *
 * Centralises every read of $_SERVER / $_POST / php://input so the rest of the
 * code never touches superglobals directly.
 */

declare(strict_types=1);

final class Request
{
    private const MAX_JSON_BYTES = 1048576; // 1 MiB cap on JSON bodies

    private static ?self $current = null;

    /** @var array<string, mixed> */
    private array $body;

    /**
     * @param array<string, mixed> $query
     * @param array<string, mixed> $body
     * @param array<string, string> $headers lower-case header name => value
     */
    private function __construct(
        private readonly string $method,
        private readonly string $path,
        private readonly array $query,
        array $body,
        private readonly array $headers,
    ) {
        $this->body = $body;
    }

    /** Build the request from the PHP superglobals. Call once from the front controller. */
    public static function capture(): self
    {
        $path = self::resolvePath();
        $headers = self::collectHeaders();
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        $body = [];

        $contentType = strtolower($headers['content-type'] ?? '');

        if (str_contains($contentType, 'application/json')) {
            $raw = (string) file_get_contents('php://input', false, null, 0, self::MAX_JSON_BYTES + 1);
            if (strlen($raw) > self::MAX_JSON_BYTES) {
                throw new HttpException(413);
            }
            if ($raw !== '') {
                $decoded = json_decode($raw, true);
                if (!is_array($decoded)) {
                    throw new HttpException(400, 'Malformed JSON body.');
                }
                $body = $decoded;
            }
        } else {
            $body = $_POST;
        }

        // Method spoofing for HTML forms: only honoured on POST and only for a fixed allow-list.
        if ($method === 'POST' && isset($body['_method']) && is_string($body['_method'])) {
            $override = strtoupper($body['_method']);
            if (in_array($override, ['PUT', 'PATCH', 'DELETE'], true)) {
                $method = $override;
            }
        }

        return self::$current = new self($method, $path, $_GET, $body, $headers);
    }

    public static function current(): self
    {
        return self::$current ?? throw new LogicException('Request has not been captured yet.');
    }

    public function method(): string
    {
        return $this->method;
    }

    /** Route path relative to the application root, always starting with "/". */
    public function path(): string
    {
        return $this->path;
    }

    public function isSafeMethod(): bool
    {
        return in_array($this->method, ['GET', 'HEAD', 'OPTIONS'], true);
    }

    /** Body value first, then query string. */
    public function input(string $key, mixed $default = null): mixed
    {
        return $this->body[$key] ?? $this->query[$key] ?? $default;
    }

    /** @return array<string, mixed> */
    public function all(): array
    {
        return array_merge($this->query, $this->body);
    }

    /** @return array<string, mixed> */
    public function body(): array
    {
        return $this->body;
    }

    /** @return array<string, mixed> */
    public function query(): array
    {
        return $this->query;
    }

    public function header(string $name): ?string
    {
        return $this->headers[strtolower($name)] ?? null;
    }

    public function isAjax(): bool
    {
        return strtolower($this->header('x-requested-with') ?? '') === 'xmlhttprequest';
    }

    /** True when the client expects JSON back (AJAX, fetch with Accept, or JSON body). */
    public function wantsJson(): bool
    {
        return $this->isAjax()
            || str_contains(strtolower($this->header('accept') ?? ''), 'application/json')
            || str_contains(strtolower($this->header('content-type') ?? ''), 'application/json');
    }

    public function isHttps(): bool
    {
        if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
            return true;
        }
        if ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443) {
            return true;
        }
        // Proxy headers are client-controlled, so they are ignored unless explicitly trusted.
        return Config::get('app.trust_proxy', false)
            && strtolower($this->header('x-forwarded-proto') ?? '') === 'https';
    }

    /** Client IP. Forwarded headers are honoured only when app.trust_proxy is enabled. */
    public function ip(): string
    {
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');

        if (Config::get('app.trust_proxy', false)) {
            $forwarded = $this->header('x-forwarded-for');
            if ($forwarded !== null) {
                $candidate = trim(explode(',', $forwarded)[0]);
                if (filter_var($candidate, FILTER_VALIDATE_IP) !== false) {
                    $ip = $candidate;
                }
            }
        }

        return filter_var($ip, FILTER_VALIDATE_IP) !== false ? $ip : '0.0.0.0';
    }

    public function userAgent(): string
    {
        return substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
    }

    /** Validated "host:port" of this request (Host header, falling back to SERVER_NAME). */
    public function host(): string
    {
        $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        if ($host === '' || !preg_match('/^[a-z0-9.\-]+(:\d{1,5})?$/', $host)) {
            $host = strtolower((string) ($_SERVER['SERVER_NAME'] ?? 'localhost'));
        }
        return $host;
    }

    /** Directory of the front controller as seen by the browser, e.g. "/timetracker/public" or "". */
    public static function basePath(): string
    {
        $dir = str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/index.php')));
        return ($dir === '/' || $dir === '.') ? '' : rtrim($dir, '/');
    }

    /** Parent of basePath(): the project folder when the root .htaccess rewrites into /public. */
    private static function rootPath(): string
    {
        $dir = str_replace('\\', '/', dirname(self::basePath()));
        return ($dir === '/' || $dir === '.') ? '' : rtrim($dir, '/');
    }

    private static function resolvePath(): string
    {
        $uri = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
        $uri = rawurldecode($uri);

        // NUL and control characters have no legitimate place in a route path.
        if (preg_match('/[\x00-\x1F\x7F]/', $uri)) {
            throw new HttpException(400);
        }

        foreach ([self::basePath(), self::rootPath()] as $prefix) {
            if ($prefix !== '' && ($uri === $prefix || str_starts_with($uri, $prefix . '/'))) {
                $uri = substr($uri, strlen($prefix));
                break;
            }
        }

        if ($uri === '/index.php' || str_starts_with($uri, '/index.php/')) {
            $uri = substr($uri, strlen('/index.php'));
        }

        return '/' . trim($uri, '/');
    }

    /** @return array<string, string> */
    private static function collectHeaders(): array
    {
        $headers = [];

        foreach ($_SERVER as $key => $value) {
            if (str_starts_with($key, 'HTTP_')) {
                $headers[strtolower(str_replace('_', '-', substr($key, 5)))] = (string) $value;
            }
        }
        // These two are not prefixed with HTTP_ by PHP.
        if (isset($_SERVER['CONTENT_TYPE'])) {
            $headers['content-type'] = (string) $_SERVER['CONTENT_TYPE'];
        }
        if (isset($_SERVER['CONTENT_LENGTH'])) {
            $headers['content-length'] = (string) $_SERVER['CONTENT_LENGTH'];
        }

        return $headers;
    }
}
