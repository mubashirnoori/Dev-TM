<?php
/**
 * Base model: safe single-table CRUD. Anything more specific (joins, reports,
 * the timer transaction) is written as explicit SQL in the concrete model.
 *
 * SECURITY: column names cannot be bound as parameters, so every column that reaches
 * SQL (filters, sorting, writes) is checked against the allow-lists below. Values are
 * always bound. $fillable also protects against mass assignment: a request that
 * posts "role=admin" is ignored unless "role" is explicitly fillable for that model.
 *
 *   final class Project extends Model
 *   {
 *       protected string $table = 'projects';
 *       protected array $columns  = ['id', 'client_id', 'name', 'status', 'created_at', 'updated_at'];
 *       protected array $fillable = ['client_id', 'name', 'status'];
 *   }
 */

declare(strict_types=1);

abstract class Model
{
    protected string $table = '';
    protected string $primaryKey = 'id';

    /** @var list<string> every column that may be filtered on or sorted by */
    protected array $columns = [];

    /** @var list<string> columns that create()/update() will accept */
    protected array $fillable = [];

    /** Maintain created_at / updated_at (UTC) automatically. */
    protected bool $timestamps = true;

    public function __construct()
    {
        if ($this->table === '' || $this->columns === []) {
            throw new LogicException(static::class . ' must define $table and $columns.');
        }

        foreach ([$this->table, $this->primaryKey, ...$this->columns, ...$this->fillable] as $identifier) {
            if (!preg_match('/^[a-z_][a-z0-9_]*$/', $identifier)) {
                throw new LogicException("Invalid identifier in " . static::class . ": {$identifier}");
            }
        }

        $unknown = array_diff($this->fillable, $this->columns);
        if ($unknown !== []) {
            throw new LogicException(static::class . ' has fillable columns missing from $columns: ' . implode(', ', $unknown));
        }
    }

    /** @return array<string, mixed>|null */
    public function find(int $id): ?array
    {
        return Database::fetchOne(
            "SELECT * FROM `{$this->table}` WHERE `{$this->primaryKey}` = :id LIMIT 1",
            ['id' => $id]
        );
    }

    /** @return array<string, mixed>|null */
    public function findBy(string $column, mixed $value): ?array
    {
        $this->assertColumn($column);

        return Database::fetchOne(
            "SELECT * FROM `{$this->table}` WHERE `{$column}` = :value LIMIT 1",
            ['value' => $value]
        );
    }

    /**
     * Equality filters combined with AND; a null value becomes IS NULL.
     *
     * @param array<string, mixed> $conditions
     * @return list<array<string, mixed>>
     */
    public function where(
        array $conditions = [],
        ?string $orderBy = null,
        string $direction = 'ASC',
        ?int $limit = null,
        int $offset = 0
    ): array {
        [$whereSql, $params] = $this->buildWhere($conditions);
        $sql = "SELECT * FROM `{$this->table}`{$whereSql} ORDER BY " . $this->orderClause($orderBy, $direction);

        if ($limit !== null) {
            $sql .= ' LIMIT :limit OFFSET :offset';
            $params['limit']  = max(1, $limit);
            $params['offset'] = max(0, $offset);
        }

        return Database::fetchAll($sql, $params);
    }

    /** @param array<string, mixed> $conditions */
    public function count(array $conditions = []): int
    {
        [$whereSql, $params] = $this->buildWhere($conditions);

        return (int) Database::fetchValue("SELECT COUNT(*) FROM `{$this->table}`{$whereSql}", $params);
    }

    /**
     * @param array<string, mixed> $conditions
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int}
     */
    public function paginate(
        int $page = 1,
        int $perPage = 20,
        array $conditions = [],
        ?string $orderBy = null,
        string $direction = 'DESC'
    ): array {
        $perPage = min(100, max(1, $perPage));
        $total   = $this->count($conditions);
        $pages   = max(1, (int) ceil($total / $perPage));
        $page    = min(max(1, $page), $pages);

        return [
            'items'    => $this->where($conditions, $orderBy, $direction, $perPage, ($page - 1) * $perPage),
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => $pages,
        ];
    }

    /**
     * Insert a row from fillable columns only; returns the new id.
     *
     * @param array<string, mixed> $data
     */
    public function create(array $data): int
    {
        $data = $this->onlyFillable($data);

        if ($data === []) {
            throw new InvalidArgumentException('No fillable data supplied to create().');
        }

        $columns      = array_map(static fn (string $c): string => "`{$c}`", array_keys($data));
        $placeholders = array_map(static fn (string $c): string => ":{$c}", array_keys($data));

        if ($this->timestamps) {
            array_push($columns, '`created_at`', '`updated_at`');
            array_push($placeholders, 'UTC_TIMESTAMP()', 'UTC_TIMESTAMP()');
        }

        Database::execute(
            "INSERT INTO `{$this->table}` (" . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')',
            $data
        );

        return Database::lastInsertId();
    }

    /**
     * Update fillable columns of one row; returns the number of rows actually changed.
     *
     * @param array<string, mixed> $data
     */
    public function update(int $id, array $data): int
    {
        $data = $this->onlyFillable($data);

        if ($data === []) {
            return 0;
        }

        $assignments = array_map(static fn (string $c): string => "`{$c}` = :{$c}", array_keys($data));

        if ($this->timestamps) {
            $assignments[] = '`updated_at` = UTC_TIMESTAMP()';
        }

        $data['__id'] = $id;

        return Database::execute(
            "UPDATE `{$this->table}` SET " . implode(', ', $assignments) . " WHERE `{$this->primaryKey}` = :__id",
            $data
        );
    }

    public function delete(int $id): bool
    {
        return Database::execute(
            "DELETE FROM `{$this->table}` WHERE `{$this->primaryKey}` = :id",
            ['id' => $id]
        ) > 0;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function onlyFillable(array $data): array
    {
        return array_intersect_key($data, array_flip($this->fillable));
    }

    private function assertColumn(string $column): void
    {
        if (!in_array($column, $this->columns, true)) {
            throw new InvalidArgumentException("Column not allowed on {$this->table}: {$column}");
        }
    }

    private function orderClause(?string $orderBy, string $direction): string
    {
        $column = $orderBy ?? $this->primaryKey;
        $this->assertColumn($column);

        return "`{$column}` " . (strtoupper($direction) === 'DESC' ? 'DESC' : 'ASC');
    }

    /**
     * @param array<string, mixed> $conditions
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function buildWhere(array $conditions): array
    {
        $clauses = [];
        $params  = [];
        $i       = 0;

        foreach ($conditions as $column => $value) {
            $this->assertColumn((string) $column);

            if ($value === null) {
                $clauses[] = "`{$column}` IS NULL";
                continue;
            }

            $clauses[] = "`{$column}` = :w{$i}";
            $params["w{$i}"] = $value;
            $i++;
        }

        return [$clauses === [] ? '' : ' WHERE ' . implode(' AND ', $clauses), $params];
    }
}
