<?php
/**
 * Left navigation, top bar and the opening of <main>. Only used by the "app" layout.
 *
 * Menu items declare the permission needed to see them. An item that points at a
 * controller which does not exist yet (Projects and Clients arrive in Phase 2) is left
 * out until that file is added, so the menu never links to a 404.
 * Hiding a link is cosmetic: each controller enforces access itself.
 *
 * Reads from the page data:  $pageTitle (string, optional)
 *
 * @var string|null $pageTitle
 */

$me       = AuthHelper::user() ?? ['name' => '', 'email' => '', 'role' => ''];
$current  = Request::current()->path();
$appName  = (string) Config::get('app.name', 'TimeTrack');

$menu = [
    ['label' => 'Dashboard', 'icon' => 'fa-gauge-high',      'path' => '/dashboard', 'permission' => 'dashboard.view'],
    ['label' => 'Projects',  'icon' => 'fa-diagram-project', 'path' => '/projects',  'permission' => 'projects.view', 'controller' => 'ProjectController'],
    ['label' => 'Clients',   'icon' => 'fa-address-book',    'path' => '/clients',   'permission' => 'clients.view',  'controller' => 'ClientController'],
];

$visible = array_values(array_filter($menu, static function (array $item): bool {
    if (isset($item['controller']) && !is_file(APP_PATH . '/Controllers/' . $item['controller'] . '.php')) {
        return false;
    }
    return PermissionHelper::has($item['permission']);
}));

$isActive = static fn (string $path): bool => $current === $path || str_starts_with($current, $path . '/');

$initials = '';
foreach (array_slice(preg_split('/\s+/', trim((string) $me['name'])) ?: [], 0, 2) as $part) {
    $initials .= mb_strtoupper(mb_substr($part, 0, 1, 'UTF-8'), 'UTF-8');
}
$initials = $initials !== '' ? $initials : '?';

try {
    $unreadCount = (int) Database::fetchValue(
        'SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0',
        ['id' => (int) AuthHelper::id()]
    );
} catch (Throwable) {
    $unreadCount = 0; // a failing badge must never take the whole page down
}

$roleLabel = ucfirst((string) $me['role']);
?>
    <aside class="app-sidebar offcanvas-lg offcanvas-start" tabindex="-1" id="appSidebar" aria-label="Main navigation">
        <div class="sidebar-brand">
            <a href="<?= e(url('/dashboard')) ?>" class="brand-link">
                <span class="brand-mark" aria-hidden="true"><i class="fa-solid fa-stopwatch"></i></span>
                <span class="brand-name"><?= e($appName) ?></span>
            </a>
            <button type="button" class="btn-close btn-close-white d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#appSidebar" aria-label="Close menu"></button>
        </div>

        <nav class="sidebar-nav">
            <ul class="nav flex-column">
                <?php foreach ($visible as $item): ?>
                    <li class="nav-item">
                        <a class="sidebar-link<?= $isActive($item['path']) ? ' active' : '' ?>"
                           href="<?= e(url($item['path'])) ?>"
                           <?= $isActive($item['path']) ? 'aria-current="page"' : '' ?>>
                            <i class="fa-solid <?= e($item['icon']) ?> fa-fw" aria-hidden="true"></i>
                            <span><?= e($item['label']) ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="sidebar-foot">
            <a class="sidebar-link<?= $isActive('/profile') ? ' active' : '' ?>" href="<?= e(url('/profile')) ?>">
                <i class="fa-solid fa-user-gear fa-fw" aria-hidden="true"></i>
                <span>My profile</span>
            </a>
            <form method="post" action="<?= e(url('/logout')) ?>" class="m-0">
                <?= csrf_field() ?>
                <button type="submit" class="sidebar-link w-100 text-start">
                    <i class="fa-solid fa-arrow-right-from-bracket fa-fw" aria-hidden="true"></i>
                    <span>Sign out</span>
                </button>
            </form>

            <div class="sidebar-user">
                <span class="avatar" aria-hidden="true"><?= e($initials) ?></span>
                <span class="sidebar-user-text">
                    <span class="sidebar-user-name"><?= e($me['name']) ?></span>
                    <span class="sidebar-user-role"><?= e($roleLabel) ?></span>
                </span>
            </div>
        </div>
    </aside>

    <div class="app-main">
        <header class="app-topbar">
            <button class="btn btn-icon d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#appSidebar"
                    aria-controls="appSidebar" aria-label="Open menu">
                <i class="fa-solid fa-bars" aria-hidden="true"></i>
            </button>

            <h1 class="topbar-title"><?= e($pageTitle ?? $appName) ?></h1>

            <div class="topbar-actions">
                <a class="btn btn-icon position-relative" href="<?= e(url('/dashboard')) ?>#notifications"
                   aria-label="Notifications<?= $unreadCount > 0 ? ', ' . $unreadCount . ' unread' : '' ?>">
                    <i class="fa-regular fa-bell" aria-hidden="true"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="badge-dot"><?= $unreadCount > 9 ? '9+' : $unreadCount ?></span>
                    <?php endif; ?>
                </a>

                <div class="dropdown">
                    <button class="btn btn-user dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="avatar avatar-sm" aria-hidden="true"><?= e($initials) ?></span>
                        <span class="d-none d-md-inline"><?= e($me['name']) ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li class="dropdown-header"><?= e($me['email']) ?></li>
                        <li><a class="dropdown-item" href="<?= e(url('/profile')) ?>"><i class="fa-solid fa-user-gear fa-fw me-2" aria-hidden="true"></i>My profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="post" action="<?= e(url('/logout')) ?>" class="m-0">
                                <?= csrf_field() ?>
                                <button type="submit" class="dropdown-item"><i class="fa-solid fa-arrow-right-from-bracket fa-fw me-2" aria-hidden="true"></i>Sign out</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </header>

        <main class="app-content" id="main-content">
