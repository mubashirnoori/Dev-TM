<?php
/**
 * Strip shown at the very top of the page content (inside <main>): the running-timer
 * bar followed by one-time flash messages.
 *
 * The "app" layout in View.php has a fixed list of parts, so this partial also carries
 * the flash messages. The timer bar renders only when a page passes $activeTimer
 * (array: project_name, task_name, started_at as a UTC "Y-m-d H:i:s" string). Phase 1 has no
 * time tracking yet, so nothing passes it and only flash messages appear.
 *
 * @var array{project_name?: string, task_name?: string, started_at?: string}|null $activeTimer
 */

$flashes = flash_pull();
$icons   = ['success' => 'fa-circle-check', 'danger' => 'fa-circle-exclamation', 'warning' => 'fa-triangle-exclamation', 'info' => 'fa-circle-info'];

if (!empty($activeTimer['started_at'])):
    $startedIso = (new DateTimeImmutable((string) $activeTimer['started_at'], new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');
?>
    <div class="timer-bar" role="status">
        <span class="timer-pulse" aria-hidden="true"></span>
        <span class="timer-label">
            <strong><?= e($activeTimer['project_name'] ?? 'Timer running') ?></strong>
            <?php if (!empty($activeTimer['task_name'])): ?>
                <span class="timer-task"><?= e($activeTimer['task_name']) ?></span>
            <?php endif; ?>
        </span>
        <span class="timer-clock" data-timer-start="<?= e($startedIso) ?>">0:00:00</span>
    </div>
<?php endif; ?>

<?php foreach ($flashes as $type => $messages): ?>
    <?php foreach ((array) $messages as $message): ?>
        <div class="alert alert-<?= e($type) ?> d-flex align-items-start gap-2 alert-dismissible fade show" role="<?= $type === 'danger' ? 'alert' : 'status' ?>" data-auto-dismiss="<?= $type === 'success' || $type === 'info' ? '6000' : '0' ?>">
            <i class="fa-solid <?= e($icons[$type] ?? 'fa-circle-info') ?> mt-1" aria-hidden="true"></i>
            <div class="flex-grow-1"><?= e($message) ?></div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Dismiss"></button>
        </div>
    <?php endforeach; ?>
<?php endforeach; ?>
