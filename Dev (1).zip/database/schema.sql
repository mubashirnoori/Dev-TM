-- =====================================================================
--  TimeTrack: database schema (Phase 1)
--  MySQL 8+ / MariaDB 10.4+, InnoDB, utf8mb4.
--
--  Import with phpMyAdmin (select your database first) or:
--      mysql -u USER -p DATABASE < database/schema.sql
--
--  Safe to re-run: every table uses CREATE TABLE IF NOT EXISTS.
--  Timestamps are stored in UTC (the app sets the session time zone to +00:00).
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- roles: admin, manager, employee, client
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`         VARCHAR(30)  NOT NULL,
    `display_name` VARCHAR(60)  NOT NULL,
    `description`  VARCHAR(255) NULL,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- permissions: fine-grained abilities, named "module.action"
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `permissions` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`         VARCHAR(60)  NOT NULL,
    `display_name` VARCHAR(100) NOT NULL,
    `module`       VARCHAR(40)  NOT NULL,
    `description`  VARCHAR(255) NULL,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_permissions_name` (`name`),
    KEY `idx_permissions_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- role_permissions: which role may do what
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `role_permissions` (
    `role_id`       INT UNSIGNED NOT NULL,
    `permission_id` INT UNSIGNED NOT NULL,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`role_id`, `permission_id`),
    KEY `idx_role_permissions_permission` (`permission_id`),
    CONSTRAINT `fk_role_permissions_role`
        FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_role_permissions_permission`
        FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- users
--
-- NOTE: `role_id` is the authoritative link to the roles table (used for
-- permissions). `role` is the same role's name kept alongside it because the
-- existing AuthMiddleware reads users.role on every request. Whenever code
-- changes a user's role it must update BOTH columns together.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `role_id`               INT UNSIGNED NOT NULL,
    `role`                  ENUM('admin','manager','employee','client') NOT NULL DEFAULT 'employee',
    `name`                  VARCHAR(120) NOT NULL,
    `email`                 VARCHAR(190) NOT NULL,
    `password`              VARCHAR(255) NOT NULL,
    `phone`                 VARCHAR(30)  NULL,
    `job_title`             VARCHAR(100) NULL,
    `timezone`              VARCHAR(64)  NOT NULL DEFAULT 'UTC',
    `status`                ENUM('active','inactive','suspended') NOT NULL DEFAULT 'active',
    `failed_login_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `locked_until`          DATETIME     NULL,
    `last_login_at`         DATETIME     NULL,
    `last_login_ip`         VARCHAR(45)  NULL,
    `password_changed_at`   DATETIME     NULL,
    `created_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_email` (`email`),
    KEY `idx_users_status` (`status`),
    KEY `idx_users_role_id` (`role_id`),
    KEY `idx_users_role_status` (`role`, `status`),
    CONSTRAINT `fk_users_role`
        FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- activity_logs: who did what, to which record (audit trail)
-- Column names match what LoggerHelper::audit() inserts.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`     INT UNSIGNED NULL,
    `action`      VARCHAR(100) NOT NULL,
    `entity_type` VARCHAR(60)  NULL,
    `entity_id`   INT UNSIGNED NULL,
    `ip_address`  VARCHAR(45)  NULL,
    `user_agent`  VARCHAR(255) NULL,
    `meta`        LONGTEXT     NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_activity_user` (`user_id`),
    KEY `idx_activity_action` (`action`),
    KEY `idx_activity_entity` (`entity_type`, `entity_id`),
    KEY `idx_activity_created` (`created_at`),
    CONSTRAINT `fk_activity_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- notifications: in-app messages for a user
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`    INT UNSIGNED NOT NULL,
    `type`       VARCHAR(40)  NOT NULL DEFAULT 'info',
    `title`      VARCHAR(160) NOT NULL,
    `message`    VARCHAR(500) NULL,
    `link`       VARCHAR(255) NULL,
    `is_read`    TINYINT(1)   NOT NULL DEFAULT 0,
    `read_at`    DATETIME     NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_notifications_user_read` (`user_id`, `is_read`, `created_at`),
    CONSTRAINT `fk_notifications_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- settings: key/value system configuration
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `setting_key`   VARCHAR(80)  NOT NULL,
    `setting_value` TEXT         NULL,
    `setting_type`  ENUM('string','int','bool','json') NOT NULL DEFAULT 'string',
    `setting_group` VARCHAR(40)  NOT NULL DEFAULT 'general',
    `description`   VARCHAR(255) NULL,
    `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_settings_key` (`setting_key`),
    KEY `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- audit_logs: updatable alias of activity_logs.
-- LoggerHelper::audit() writes to a table called audit_logs; this view lets
-- those inserts land in activity_logs without changing existing code.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW `audit_logs` AS
    SELECT `id`, `user_id`, `action`, `entity_type`, `entity_id`,
           `ip_address`, `user_agent`, `meta`, `created_at`
    FROM `activity_logs`;
