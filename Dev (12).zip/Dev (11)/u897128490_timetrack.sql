-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 03, 2026 at 09:14 AM
-- Server version: 11.8.9-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u897128490_timetrack`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_timers`
--

CREATE TABLE `active_timers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `started_at` datetime NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `paused_at` datetime DEFAULT NULL,
  `accumulated_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `is_billable` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `active_timers`
--

INSERT INTO `active_timers` (`id`, `user_id`, `project_id`, `task_id`, `started_at`, `last_activity_at`, `paused_at`, `accumulated_seconds`, `description`, `is_billable`, `created_at`) VALUES
(24, 4, 1, 1, '2026-10-03 06:43:35', '2026-10-03 06:45:48', NULL, 0, NULL, 1, '2026-10-03 06:43:35');

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(60) DEFAULT NULL,
  `entity_type` varchar(60) DEFAULT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `record_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `record_id`, `ip_address`, `user_agent`, `old_value`, `new_value`, `meta`, `created_at`) VALUES
(1, 1, 'auth.login', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 08:57:37'),
(2, 1, 'auth.login', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 09:52:54'),
(3, 1, 'auth.login', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 10:00:33'),
(4, 1, 'client.created', NULL, 'client', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"AFIC\"}', '2026-10-01 10:02:37'),
(5, 1, 'project.created', NULL, 'project', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"AFIC\",\"code\":\"PRJ-0001\"}', '2026-10-01 10:03:19'),
(6, 1, 'auth.logout', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 10:03:58'),
(7, 3, 'auth.login', NULL, 'user', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 10:04:44'),
(8, 3, 'auth.logout', NULL, 'user', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 10:05:22'),
(9, 1, 'auth.login', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 10:05:28'),
(10, 1, 'schedule.created', NULL, 'schedule', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"user_id\":2,\"project_id\":1,\"overridden\":false}', '2026-10-01 10:31:09'),
(11, 1, 'client.created', NULL, 'client', 2, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"AFIC-NIHD\"}', '2026-10-01 10:48:34'),
(12, 1, 'task.created', NULL, 'task', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"name\":\"CON - Building Envelope\"}', '2026-10-01 10:49:55'),
(13, 1, 'auth.login', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 11:20:32'),
(14, 1, 'timer.started', NULL, 'timer', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":null}', '2026-10-01 11:22:40'),
(15, 1, 'timer.stopped', NULL, 'time_entry', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":1665}', '2026-10-01 11:50:25'),
(16, 1, 'timer.started', NULL, 'timer', 2, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-01 11:50:37'),
(17, 1, 'timer.stopped', NULL, 'time_entry', 2, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":17}', '2026-10-01 11:50:54'),
(18, 1, 'timer.started', NULL, 'timer', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-01 11:51:20'),
(19, 1, 'timer.stopped', NULL, 'time_entry', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":356}', '2026-10-01 11:57:16'),
(20, 1, 'timer.started', NULL, 'timer', 4, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-01 11:57:27'),
(21, 1, 'timer.stopped', NULL, 'time_entry', 4, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":232}', '2026-10-01 12:01:19'),
(22, 1, 'timer.started', NULL, 'timer', 5, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":null}', '2026-10-01 12:01:21'),
(23, 1, 'timer.stopped', NULL, 'time_entry', 5, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":10}', '2026-10-01 12:01:31'),
(24, 1, 'auth.logout', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 12:04:38'),
(25, 3, 'auth.login', NULL, 'user', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 12:04:45'),
(26, 3, 'auth.logout', NULL, 'user', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 12:06:24'),
(27, 1, 'auth.login', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 12:06:30'),
(28, 1, 'auth.login', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 12:41:28'),
(29, 1, 'timesheet.submitted', NULL, 'timesheet', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"start_date\":\"2026-09-28\",\"end_date\":\"2026-10-04\",\"total_seconds\":2280,\"billable_seconds\":2280}', '2026-10-01 12:57:26'),
(30, 1, 'auth.logout', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 12:58:06'),
(31, 3, 'auth.login', NULL, 'user', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 12:58:09'),
(32, 3, 'timer.started', NULL, 'timer', 6, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-01 12:58:17'),
(33, 3, 'timer.stopped', NULL, 'time_entry', 6, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":31}', '2026-10-01 12:58:48'),
(34, 3, 'timesheet.submitted', NULL, 'timesheet', 2, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"start_date\":\"2026-09-28\",\"end_date\":\"2026-10-04\",\"total_seconds\":31,\"billable_seconds\":31}', '2026-10-01 12:58:58'),
(35, 3, 'auth.logout', NULL, 'user', 3, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 13:00:02'),
(36, 1, 'auth.login', NULL, 'user', 1, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 13:00:09'),
(37, 1, 'auth.login', NULL, 'user', 1, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 14:02:21'),
(38, 1, 'auth.login', NULL, 'user', 1, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 14:45:05'),
(39, 1, 'timesheet.approved', NULL, 'timesheet', 2, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"user_id\":3,\"start_date\":\"2026-09-28\",\"total_seconds\":31,\"billable_seconds\":31}', '2026-10-01 15:10:48'),
(40, 1, 'timer.started', NULL, 'timer', 7, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":null}', '2026-10-01 15:24:38'),
(41, 1, 'timer.paused', NULL, 'timer', 7, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 15:24:43'),
(42, 1, 'timer.resumed', NULL, 'timer', 7, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 15:24:53'),
(43, 1, 'timer.stopped', NULL, 'time_entry', 7, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":696}', '2026-10-01 15:36:14'),
(44, 1, 'client.updated', NULL, 'client', 1, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"AFIC\"}', '2026-10-01 16:14:31'),
(45, 1, 'client.deleted', NULL, 'client', 2, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"AFIC-NIHD\"}', '2026-10-01 16:14:38'),
(46, 1, 'client.created', NULL, 'client', 3, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Shifa Eye Hospital\"}', '2026-10-01 16:15:42'),
(47, 1, 'project.created', NULL, 'project', 2, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"CON - Building Envelope\",\"code\":\"PRJ-0002\"}', '2026-10-01 16:17:21'),
(48, 1, 'project.updated', NULL, 'project', 2, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Al Shifa Trust Eye Hospital\"}', '2026-10-01 16:18:55'),
(49, 1, 'task.created', NULL, 'task', 2, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"name\":\"CON - Building Envelope\"}', '2026-10-01 16:27:07'),
(50, 1, 'timer.started', NULL, 'timer', 8, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":2}', '2026-10-01 16:27:35'),
(51, 1, 'timer.stopped', NULL, 'time_entry', 8, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":54}', '2026-10-01 16:28:29'),
(52, 1, 'timer.started', NULL, 'timer', 9, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":2}', '2026-10-01 16:46:16'),
(53, 1, 'timer.stopped', NULL, 'time_entry', 9, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":393}', '2026-10-01 16:52:49'),
(54, 1, 'auth.logout', NULL, 'user', 1, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 16:55:27'),
(55, 3, 'auth.login', NULL, 'user', 3, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 16:55:33'),
(56, 3, 'timer.started', NULL, 'timer', 10, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":2}', '2026-10-01 16:55:59'),
(57, 3, 'auth.logout', NULL, 'user', 3, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 16:56:43'),
(58, 1, 'auth.login', NULL, 'user', 1, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 16:56:49'),
(59, 1, 'client.created', NULL, 'client', 4, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Al Shifa Trust\"}', '2026-10-01 17:10:25'),
(60, 1, 'client.deleted', NULL, 'client', 4, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Al Shifa Trust\"}', '2026-10-01 17:10:33'),
(61, 1, 'auth.login', NULL, 'user', 1, NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 18:10:33'),
(62, 1, 'auth.login', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 19:05:01'),
(63, 1, 'task.created', 'task', 'task', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"name\":\"Test\"}', '2026-10-01 19:31:40'),
(64, 1, 'task.updated', 'task', 'task', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Test\",\"assignees\":1}', '2026-10-01 19:31:55'),
(65, 1, 'task.updated', 'task', 'task', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Test\",\"assignees\":2}', '2026-10-01 19:31:56'),
(66, 1, 'task.assigned', 'task', 'task', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"Test\",\"assignee\":3,\"project_id\":2}', NULL, '2026-10-01 19:31:56'),
(67, 1, 'project.visibility_changed', 'project', 'project', 2, 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"public\":1}', '2026-10-01 19:32:36'),
(68, 1, 'project.visibility_changed', 'project', 'project', 2, 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"public\":0}', '2026-10-01 19:32:39'),
(69, 1, 'timer.started', 'timer', 'timer', 11, 11, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":3}', '2026-10-01 19:48:00'),
(70, 1, 'client.updated', 'client', 'client', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"AFIC\"}', '2026-10-01 19:58:22'),
(71, 1, 'auth.logout', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 19:59:04'),
(72, 3, 'auth.login', 'user', 'user', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 19:59:08'),
(73, 3, 'timer.stopped', 'time_entry', 'time_entry', 10, 10, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":10993}', '2026-10-01 19:59:12'),
(74, 3, 'timer.started', 'timer', 'timer', 12, 12, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":3}', '2026-10-01 19:59:47'),
(75, 3, 'auth.logout', 'user', 'user', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 20:01:00'),
(76, 1, 'auth.login', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-01 20:02:24'),
(77, 1, 'user.created', 'user', 'user', 5, 5, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Ahmer\",\"email\":\"ahmer@gmail.com\",\"role\":\"admin\",\"status\":\"active\"}', NULL, '2026-10-01 20:06:47'),
(78, 1, 'auth.login', 'user', 'user', 1, 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 05:17:08'),
(79, 1, 'timer.stopped', 'time_entry', 'time_entry', 11, 11, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":34151}', '2026-10-02 05:17:11'),
(80, 1, 'auth.login', 'user', 'user', 1, 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 07:06:53'),
(81, 1, 'auth.login', 'user', 'user', 1, 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 08:12:51'),
(82, 1, 'task.status_changed', 'task', 'task', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"from\":\"To Do\",\"to\":\"Completed\"}', '2026-10-02 08:13:51'),
(83, 1, 'task.status_changed', 'task', 'task', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"from\":\"Completed\",\"to\":\"Completed\"}', '2026-10-02 08:17:31'),
(84, 1, 'task.status_changed', 'task', 'task', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"from\":\"Completed\",\"to\":\"To Do\"}', '2026-10-02 08:22:22'),
(85, 1, 'user.deleted', 'user', 'user', 5, 5, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Ahmer\",\"email\":\"ahmer@gmail.com\"}', NULL, NULL, '2026-10-02 08:28:46'),
(86, 1, 'task.status_changed', 'task', 'task', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"from\":\"To Do\",\"to\":\"Completed\"}', '2026-10-02 08:31:56'),
(87, 1, 'task.updated', 'task', 'task', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Test 1\"}', '2026-10-02 08:32:11'),
(88, 1, 'task.updated', 'task', 'task', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Test\"}', '2026-10-02 08:32:15'),
(89, 1, 'client.updated', 'client', 'client', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Al Shifa\"}', '2026-10-02 08:35:22'),
(90, 1, 'client.updated', 'client', 'client', 1, 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"AFIC-NIHD\"}', '2026-10-02 08:36:11'),
(91, 1, 'client.updated', 'client', 'client', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Al Shifa Trust\"}', '2026-10-02 08:36:27'),
(92, 1, 'settings.updated', 'settings', 'settings', NULL, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"company_name\":\"Your Company\",\"currency\":\"USD\",\"currency_symbol\":\"$\",\"default_hourly_rate\":\"0\",\"default_timezone\":\"UTC\",\"working_hours_per_day\":\"8\"}', '{\"company_name\":\"Your Company\",\"currency_symbol\":\"$\",\"currency\":\"USD\",\"default_hourly_rate\":\"0\",\"working_hours_per_day\":\"9\",\"default_timezone\":\"UTC\"}', NULL, '2026-10-02 08:38:09'),
(93, 1, 'settings.updated', 'settings', 'settings', NULL, NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"company_name\":\"Your Company\",\"currency\":\"USD\",\"currency_symbol\":\"$\",\"default_hourly_rate\":\"0\",\"default_timezone\":\"UTC\",\"working_hours_per_day\":\"9\"}', '{\"company_name\":\"Maven Projects LLP\",\"currency_symbol\":\"$\",\"currency\":\"USD\",\"default_hourly_rate\":\"0\",\"working_hours_per_day\":\"9\",\"default_timezone\":\"UTC\"}', NULL, '2026-10-02 08:52:09'),
(94, 1, 'project.updated', 'project', 'project', 2, 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Al Shifa Trust Eye Hospital\",\"status\":\"Active\"}', '{\"name\":\"Al Shifa Trust Eye Hospital\",\"status\":\"Active\"}', NULL, '2026-10-02 09:10:48'),
(95, 1, 'auth.login', 'user', 'user', 1, 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 09:49:38'),
(96, 1, 'timer.started', 'timer', 'timer', 13, 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-02 10:07:43'),
(97, 1, 'timer.stopped', 'time_entry', 'time_entry', 12, 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":6}', '2026-10-02 10:07:49'),
(98, 1, 'timer.started', 'timer', 'timer', 14, 14, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-02 10:07:52'),
(99, 1, 'timer.stopped', 'time_entry', 'time_entry', 13, 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":15}', '2026-10-02 10:08:07'),
(100, 1, 'time_entry.deleted', 'time_entry', 'time_entry', 12, 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1}', '2026-10-02 10:11:28'),
(101, 1, 'auth.logout', 'user', 'user', 1, 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 10:38:10'),
(102, 3, 'auth.login', 'user', 'user', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 10:38:14'),
(103, 3, 'timer.stopped', 'time_entry', 'time_entry', 14, 14, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":52721}', '2026-10-02 10:38:28'),
(104, 3, 'time_entry.created', 'time_entry', 'time_entry', 15, 15, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":3600}', '2026-10-02 10:44:04'),
(105, 3, 'timer.started', 'timer', 'timer', 15, 15, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-02 10:48:32'),
(106, 3, 'timer.stopped', 'time_entry', 'time_entry', 16, 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":9}', '2026-10-02 10:48:41'),
(107, 3, 'timer.started', 'timer', 'timer', 16, 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-02 10:49:00'),
(108, 3, 'timer.stopped', 'time_entry', 'time_entry', 17, 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":5}', '2026-10-02 10:49:05'),
(109, 3, 'timer.started', 'timer', 'timer', 17, 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-02 10:52:01'),
(110, 3, 'timer.stopped', 'time_entry', 'time_entry', 18, 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":4}', '2026-10-02 10:52:05'),
(111, 3, 'auth.login', 'user', 'user', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 11:26:49'),
(112, 3, 'auth.login', 'user', 'user', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 11:39:34'),
(113, 3, 'auth.logout', 'user', 'user', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 11:43:00'),
(114, 1, 'auth.login', 'user', 'user', 1, 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 11:43:06'),
(115, 1, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 3, 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":3,\"total_seconds\":1104}', '2026-10-02 11:53:58'),
(116, 1, 'auth.login', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 14:27:35'),
(117, 1, 'auth.logout', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 14:46:14'),
(118, 1, 'auth.login', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 15:59:35'),
(119, 1, 'timer.started', 'timer', 'timer', 18, 18, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":2}', '2026-10-02 15:59:52'),
(120, 1, 'timer.stopped', 'time_entry', 'time_entry', 19, 19, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":47}', '2026-10-02 16:00:39'),
(121, 1, 'timer.started', 'timer', 'timer', 19, 19, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-02 16:02:06'),
(122, 1, 'timer.stopped', 'time_entry', 'time_entry', 20, 20, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":60}', '2026-10-02 16:03:06'),
(123, 1, 'timer.started', 'timer', 'timer', 20, 20, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-02 16:23:33'),
(124, 1, 'timer.stopped', 'time_entry', 'time_entry', 21, 21, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":154}', '2026-10-02 16:26:07'),
(125, 1, 'schedule.created', 'schedule', 'schedule', 17, 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"user_id\":1,\"project_id\":2,\"overridden\":false}', '2026-10-02 16:34:05'),
(126, 1, 'timer.started', 'timer', 'timer', 21, 21, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":2}', '2026-10-02 16:34:52'),
(127, 1, 'auth.logout', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 16:36:24'),
(128, 3, 'auth.login', 'user', 'user', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 16:36:32'),
(129, 3, 'timer.started', 'timer', 'timer', 22, 22, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-02 16:37:03'),
(130, 3, 'auth.logout', 'user', 'user', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 16:37:18'),
(131, 1, 'auth.login', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 16:37:23'),
(132, 1, 'timer.paused', 'timer', 'timer', 21, 21, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 16:42:39'),
(133, 1, 'timer.resumed', 'timer', 'timer', 21, 21, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-02 16:42:40'),
(134, 1, 'timer.stopped', 'time_entry', 'time_entry', 22, 22, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":901}', '2026-10-02 16:49:53'),
(135, 1, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 4, 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":1,\"total_seconds\":47}', '2026-10-02 16:50:07'),
(136, 1, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 5, 5, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":1,\"total_seconds\":54}', '2026-10-02 16:50:23'),
(137, 1, 'auth.login', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 05:10:41'),
(138, 1, 'auth.logout', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 06:04:16'),
(139, 1, 'auth.login', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 06:23:48'),
(140, 1, 'auth.logout', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 06:41:45'),
(141, 3, 'auth.login', 'user', 'user', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 06:41:59'),
(142, 3, 'timer.started', 'timer', 'timer', 23, 23, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-03 06:42:49'),
(143, 3, 'timer.stopped', 'time_entry', 'time_entry', 24, 24, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":1}', '2026-10-03 06:42:50'),
(144, 3, 'auth.logout', 'user', 'user', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 06:43:03'),
(145, 4, 'auth.login', 'user', 'user', 4, 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 06:43:11'),
(146, 4, 'timer.started', 'timer', 'timer', 24, 24, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-03 06:43:35'),
(147, 4, 'auth.logout', 'user', 'user', 4, 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 06:46:00'),
(148, 1, 'auth.login', 'user', 'user', 1, 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-03 06:53:11'),
(149, 1, 'task.created', 'task', 'task', 4, 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"name\":\"CON - Furniture\"}', '2026-10-03 07:07:33'),
(150, 1, 'client.created', 'client', 'client', 5, 5, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Nova Care\"}', '2026-10-03 07:09:18'),
(151, 1, 'project.created', 'project', 'project', 3, 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Citadel 7 Novacare Hospital\",\"code\":\"PRJ-0003\"}', NULL, '2026-10-03 07:10:31'),
(152, 1, 'project.created', 'project', 'project', 4, 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Novacare Hospital\",\"code\":\"PRJ-0004\"}', NULL, '2026-10-03 07:11:26'),
(153, 1, 'timer.started', 'timer', 'timer', 25, 25, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"task_id\":null}', '2026-10-03 07:12:06'),
(154, 1, 'timer.stopped', 'time_entry', 'time_entry', 25, 25, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"duration_seconds\":4}', '2026-10-03 07:12:10'),
(155, 1, 'timer.started', 'timer', 'timer', 26, 26, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"task_id\":null}', '2026-10-03 07:12:19'),
(156, 1, 'timer.stopped', 'time_entry', 'time_entry', 26, 26, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"duration_seconds\":5}', '2026-10-03 07:12:24'),
(157, 1, 'timer.started', 'timer', 'timer', 27, 27, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":2}', '2026-10-03 07:13:25'),
(158, 1, 'schedule.created', 'schedule', 'schedule', 18, 18, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"user_id\":4,\"project_id\":2,\"overridden\":false}', '2026-10-03 07:26:21'),
(159, 1, 'schedule.created', 'schedule', 'schedule', 19, 19, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"user_id\":4,\"project_id\":2,\"overridden\":true}', '2026-10-03 07:27:33'),
(160, 1, 'schedule.conflict_overridden', 'schedule', 'schedule', 19, 19, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"conflicts\":[{\"id\":18,\"start\":\"2026-10-03 07:00:00\",\"end\":\"2026-10-04 03:30:00\"}]}', NULL, '2026-10-03 07:27:33'),
(161, 1, 'timer.stopped', 'time_entry', 'time_entry', 27, 27, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":1580}', '2026-10-03 07:39:45');

-- --------------------------------------------------------

--
-- Stand-in structure for view `audit_logs`
-- (See below for the actual view)
--
CREATE TABLE `audit_logs` (
`id` bigint(20) unsigned
,`user_id` int(10) unsigned
,`action` varchar(100)
,`module` varchar(60)
,`entity_type` varchar(60)
,`entity_id` int(10) unsigned
,`record_id` int(10) unsigned
,`ip_address` varchar(45)
,`user_agent` varchar(255)
,`meta` longtext
,`old_value` longtext
,`new_value` longtext
,`created_at` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(160) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `company` varchar(160) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `email`, `phone`, `company`, `address`, `status`, `created_at`, `updated_at`) VALUES
(1, 'AFIC-NIHD', 'test@gmail.com', '354564548', 'AFIC', 'RWP', 'active', '2026-10-01 10:02:37', '2026-10-02 08:36:11'),
(3, 'Al Shifa Trust', 'test1@gmail.com', '152132026', 'Al Shifa', 'RWP', 'active', '2026-10-01 16:15:42', '2026-10-02 08:36:27'),
(5, 'Nova Care', 'test2@gmail.com', '546452165', 'Nova Care', 'ISB', 'active', '2026-10-03 07:09:18', '2026-10-03 07:09:18');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` varchar(40) NOT NULL DEFAULT 'info',
  `title` varchar(160) NOT NULL,
  `message` varchar(500) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `message`, `link`, `is_read`, `read_at`, `created_at`) VALUES
(1, 1, 'info', 'Welcome to TimeTrack', 'Your account is ready. Change the default password from your profile before you start.', '/profile', 0, NULL, '2026-10-01 08:55:54'),
(2, 3, 'info', 'Welcome to TimeTrack', 'Your account is ready. Change the default password from your profile before you start.', '/profile', 0, NULL, '2026-10-01 08:55:54'),
(3, 2, 'info', 'Welcome to TimeTrack', 'Your account is ready. Change the default password from your profile before you start.', '/profile', 0, NULL, '2026-10-01 08:55:54'),
(4, 4, 'info', 'Welcome to TimeTrack', 'Your account is ready. Change the default password from your profile before you start.', '/profile', 0, NULL, '2026-10-01 08:55:54'),
(8, 2, 'info', 'Timesheet submitted', 'System Admin submitted a timesheet for Sep 28 – Oct 4, 2026.', '/timesheets/1', 0, NULL, '2026-10-01 12:57:26'),
(9, 1, 'info', 'Timesheet submitted', 'John Carter submitted a timesheet for Sep 28 – Oct 4, 2026.', '/timesheets/2', 0, NULL, '2026-10-01 12:58:58'),
(10, 2, 'info', 'Timesheet submitted', 'John Carter submitted a timesheet for Sep 28 – Oct 4, 2026.', '/timesheets/2', 0, NULL, '2026-10-01 12:58:58'),
(11, 3, 'success', 'Timesheet approved', 'Your timesheet for Sep 28 – Oct 4, 2026 was approved.', '/timesheets/2', 0, NULL, '2026-10-01 15:10:48'),
(12, 3, 'info', 'New task assigned', 'You were assigned \"Test\" on Al Shifa Trust Eye Hospital.', '/projects/2?tab=tasks', 0, NULL, '2026-10-01 19:31:56'),
(14, 2, 'info', 'Work submitted for approval', 'System Admin submitted selected work for Oct 1 – Oct 2, 2026.', '/timesheets/3', 0, NULL, '2026-10-02 11:53:58'),
(15, 2, 'info', 'Work submitted for approval', 'System Admin submitted selected work for Sep 28 – Oct 4, 2026.', '/timesheets/4', 0, NULL, '2026-10-02 16:50:07'),
(16, 2, 'info', 'Work submitted for approval', 'System Admin submitted selected work for Sep 28 – Oct 4, 2026.', '/timesheets/5', 0, NULL, '2026-10-02 16:50:23'),
(17, 4, 'info', 'Schedule changed', 'Your planned work for Al Shifa Trust Eye Hospital moved to Oct 3, 12:00.', '/schedule/my', 0, NULL, '2026-10-03 07:26:21'),
(18, 4, 'info', 'Schedule changed', 'Your planned work for Al Shifa Trust Eye Hospital moved to Oct 3, 12:00.', '/schedule/my', 0, NULL, '2026-10-03 07:27:33'),
(19, 4, 'warning', 'Schedule conflict', 'A new block overlaps an existing planned block.', '/schedule/my', 0, NULL, '2026-10-03 07:27:33');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `module` varchar(40) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`) VALUES
(1, 'dashboard.view', 'View dashboard', 'dashboard', 'Open the dashboard.', '2026-10-01 08:55:54'),
(2, 'notifications.view', 'View notifications', 'notifications', 'See own notifications.', '2026-10-01 08:55:54'),
(3, 'users.view', 'View users', 'users', 'See the user directory.', '2026-10-01 08:55:54'),
(4, 'users.create', 'Create users', 'users', 'Add new users.', '2026-10-01 08:55:54'),
(5, 'users.edit', 'Edit users', 'users', 'Change user details, roles and status.', '2026-10-01 08:55:54'),
(6, 'users.delete', 'Delete users', 'users', 'Remove users.', '2026-10-01 08:55:54'),
(7, 'roles.manage', 'Manage roles', 'users', 'Edit roles and their permissions.', '2026-10-01 08:55:54'),
(8, 'clients.view', 'View clients', 'clients', 'See the client list.', '2026-10-01 08:55:54'),
(9, 'clients.create', 'Create clients', 'clients', 'Add new clients.', '2026-10-01 08:55:54'),
(10, 'clients.edit', 'Edit clients', 'clients', 'Change client details.', '2026-10-01 08:55:54'),
(11, 'clients.delete', 'Delete clients', 'clients', 'Remove clients.', '2026-10-01 08:55:54'),
(12, 'projects.view', 'View projects', 'projects', 'See projects the user is assigned to.', '2026-10-01 08:55:54'),
(13, 'projects.view_all', 'View all projects', 'projects', 'See every project, assigned or not.', '2026-10-01 08:55:54'),
(14, 'projects.create', 'Create projects', 'projects', 'Add new projects.', '2026-10-01 08:55:54'),
(15, 'projects.edit', 'Edit projects', 'projects', 'Change project details.', '2026-10-01 08:55:54'),
(16, 'projects.delete', 'Delete projects', 'projects', 'Remove projects.', '2026-10-01 08:55:54'),
(17, 'projects.archive', 'Archive projects', 'projects', 'Archive and restore projects.', '2026-10-01 08:55:54'),
(18, 'projects.manage_members', 'Manage project members', 'projects', 'Assign and remove project members.', '2026-10-01 08:55:54'),
(19, 'tasks.view', 'View tasks', 'tasks', 'See tasks on assigned projects.', '2026-10-01 08:55:54'),
(20, 'tasks.create', 'Create tasks', 'tasks', 'Add tasks to projects.', '2026-10-01 08:55:54'),
(21, 'tasks.edit', 'Edit tasks', 'tasks', 'Change tasks.', '2026-10-01 08:55:54'),
(22, 'tasks.delete', 'Delete tasks', 'tasks', 'Remove tasks.', '2026-10-01 08:55:54'),
(23, 'tasks.assign', 'Assign tasks', 'tasks', 'Assign tasks to people.', '2026-10-01 08:55:54'),
(24, 'time.track', 'Track time', 'time', 'Start and stop timers.', '2026-10-01 08:55:54'),
(25, 'time.view_own', 'View own time', 'time', 'See own time entries.', '2026-10-01 08:55:54'),
(26, 'time.view_all', 'View all time', 'time', 'See everyone\'s time entries.', '2026-10-01 08:55:54'),
(27, 'time.edit_own', 'Edit own time', 'time', 'Add and edit own time entries.', '2026-10-01 08:55:54'),
(28, 'time.edit_all', 'Edit all time', 'time', 'Edit anyone\'s time entries.', '2026-10-01 08:55:54'),
(29, 'time.approve', 'Approve timesheets', 'time', 'Approve or reject submitted timesheets.', '2026-10-01 08:55:54'),
(30, 'reports.view', 'View reports', 'reports', 'Open reports.', '2026-10-01 08:55:54'),
(31, 'reports.export', 'Export reports', 'reports', 'Download reports as CSV/PDF.', '2026-10-01 08:55:54'),
(32, 'reports.billing', 'View billing figures', 'reports', 'See rates, budgets and billable amounts.', '2026-10-01 08:55:54'),
(33, 'activity.view', 'View activity log', 'system', 'Read the audit trail.', '2026-10-01 08:55:54'),
(34, 'settings.manage', 'Manage settings', 'system', 'Change system settings.', '2026-10-01 08:55:54'),
(35, 'schedule.view', 'View schedule', 'schedule', 'See planned work on assigned projects.', '2026-10-01 10:28:52'),
(36, 'schedule.create', 'Create schedule', 'schedule', 'Add planned work blocks.', '2026-10-01 10:28:52'),
(37, 'schedule.edit', 'Edit schedule', 'schedule', 'Change planned work blocks.', '2026-10-01 10:28:52'),
(38, 'schedule.delete', 'Delete schedule', 'schedule', 'Remove planned work blocks.', '2026-10-01 10:28:52'),
(39, 'schedule.view_team', 'View team schedule', 'schedule', 'See planned work for the whole team.', '2026-10-01 10:28:52'),
(57, 'workspace.manage', 'Manage workspace', 'workspace', 'Change workspace identity, policies and workspace permissions.', '2026-10-02 08:51:16');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `project_code` varchar(50) NOT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('Planning','Active','On Hold','Completed','Cancelled','Archived') NOT NULL DEFAULT 'Planning',
  `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `budget` decimal(14,2) NOT NULL DEFAULT 0.00,
  `hourly_rate` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_billable` tinyint(1) NOT NULL DEFAULT 1,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#03A9F4',
  `estimate_type` enum('none','time','budget') NOT NULL DEFAULT 'none',
  `manager_id` int(10) UNSIGNED DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `client_id`, `project_code`, `name`, `description`, `start_date`, `due_date`, `status`, `priority`, `estimated_hours`, `budget`, `hourly_rate`, `is_billable`, `is_public`, `color`, `estimate_type`, `manager_id`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'PRJ-0001', 'AFIC', NULL, '2026-10-02', '2026-10-15', 'Planning', 'High', 154.00, 0.00, 0.00, 1, 0, '#03A9F4', 'time', 2, 1, '2026-10-01 10:03:19', '2026-10-01 19:30:53'),
(2, 3, 'PRJ-0002', 'Al Shifa Trust Eye Hospital', NULL, NULL, NULL, 'Active', 'Urgent', 120.00, 0.00, 0.00, 1, 0, '#03A9F4', 'time', 1, 1, '2026-10-01 16:17:21', '2026-10-02 09:10:48'),
(3, 5, 'PRJ-0003', 'Citadel 7 Novacare Hospital', NULL, NULL, NULL, 'Active', 'Urgent', 30.00, 0.00, 0.00, 1, 0, '#03A9F4', 'none', 1, 1, '2026-10-03 07:10:31', '2026-10-03 07:10:31'),
(4, 5, 'PRJ-0004', 'Novacare Hospital', NULL, NULL, NULL, 'Planning', 'Medium', 145.00, 0.00, 0.00, 1, 0, '#03A9F4', 'none', 2, 1, '2026-10-03 07:11:26', '2026-10-03 07:11:26');

-- --------------------------------------------------------

--
-- Table structure for table `project_favorites`
--

CREATE TABLE `project_favorites` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_members`
--

CREATE TABLE `project_members` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_role` varchar(60) NOT NULL DEFAULT 'Member',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_members`
--

INSERT INTO `project_members` (`id`, `project_id`, `user_id`, `project_role`, `created_at`) VALUES
(1, 1, 3, 'member', '2026-10-01 10:03:19'),
(2, 1, 2, 'manager', '2026-10-01 10:03:19'),
(3, 1, 4, 'viewer', '2026-10-01 10:03:19'),
(4, 1, 1, 'member', '2026-10-01 10:03:19'),
(5, 2, 3, 'member', '2026-10-01 16:17:21'),
(6, 2, 4, 'member', '2026-10-01 16:17:21'),
(7, 2, 1, 'manager', '2026-10-01 16:17:21'),
(8, 3, 3, 'member', '2026-10-03 07:10:31'),
(9, 3, 2, 'member', '2026-10-03 07:10:31'),
(10, 3, 4, 'member', '2026-10-03 07:10:31'),
(11, 3, 1, 'manager', '2026-10-03 07:10:31'),
(12, 4, 3, 'member', '2026-10-03 07:11:26'),
(13, 4, 4, 'member', '2026-10-03 07:11:26'),
(14, 4, 2, 'manager', '2026-10-03 07:11:26'),
(15, 4, 1, 'member', '2026-10-03 07:11:26');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `display_name` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', 'Full access to every module and setting.', '2026-10-01 08:55:54', '2026-10-01 08:55:54'),
(2, 'manager', 'Manager', 'Manages clients, projects, teams and approvals.', '2026-10-01 08:55:54', '2026-10-01 08:55:54'),
(3, 'employee', 'Employee', 'Tracks time on the projects they are assigned to.', '2026-10-01 08:55:54', '2026-10-01 08:55:54'),
(4, 'client', 'Client', 'Read-only view of their own projects and reports.', '2026-10-01 08:55:54', '2026-10-01 08:55:54');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `created_at`) VALUES
(1, 1, '2026-10-01 08:55:54'),
(1, 2, '2026-10-01 08:55:54'),
(1, 3, '2026-10-01 08:55:54'),
(1, 4, '2026-10-01 08:55:54'),
(1, 5, '2026-10-01 08:55:54'),
(1, 6, '2026-10-01 08:55:54'),
(1, 7, '2026-10-01 08:55:54'),
(1, 8, '2026-10-01 08:55:54'),
(1, 9, '2026-10-01 08:55:54'),
(1, 10, '2026-10-01 08:55:54'),
(1, 11, '2026-10-01 08:55:54'),
(1, 12, '2026-10-01 08:55:54'),
(1, 13, '2026-10-01 08:55:54'),
(1, 14, '2026-10-01 08:55:54'),
(1, 15, '2026-10-01 08:55:54'),
(1, 16, '2026-10-01 08:55:54'),
(1, 17, '2026-10-01 08:55:54'),
(1, 18, '2026-10-01 08:55:54'),
(1, 19, '2026-10-01 08:55:54'),
(1, 20, '2026-10-01 08:55:54'),
(1, 21, '2026-10-01 08:55:54'),
(1, 22, '2026-10-01 08:55:54'),
(1, 23, '2026-10-01 08:55:54'),
(1, 24, '2026-10-01 08:55:54'),
(1, 25, '2026-10-01 08:55:54'),
(1, 26, '2026-10-01 08:55:54'),
(1, 27, '2026-10-01 08:55:54'),
(1, 28, '2026-10-01 08:55:54'),
(1, 29, '2026-10-01 08:55:54'),
(1, 30, '2026-10-01 08:55:54'),
(1, 31, '2026-10-01 08:55:54'),
(1, 32, '2026-10-01 08:55:54'),
(1, 33, '2026-10-01 08:55:54'),
(1, 34, '2026-10-01 08:55:54'),
(1, 35, '2026-10-01 10:28:52'),
(1, 36, '2026-10-01 10:28:52'),
(1, 37, '2026-10-01 10:28:52'),
(1, 38, '2026-10-01 10:28:52'),
(1, 39, '2026-10-01 10:28:52'),
(1, 57, '2026-10-02 08:51:16'),
(2, 1, '2026-10-01 08:55:54'),
(2, 2, '2026-10-01 08:55:54'),
(2, 3, '2026-10-01 08:55:54'),
(2, 8, '2026-10-01 08:55:54'),
(2, 9, '2026-10-01 08:55:54'),
(2, 10, '2026-10-01 08:55:54'),
(2, 12, '2026-10-01 08:55:54'),
(2, 14, '2026-10-01 08:55:54'),
(2, 15, '2026-10-01 08:55:54'),
(2, 17, '2026-10-01 08:55:54'),
(2, 18, '2026-10-01 08:55:54'),
(2, 19, '2026-10-01 08:55:54'),
(2, 20, '2026-10-01 08:55:54'),
(2, 21, '2026-10-01 08:55:54'),
(2, 22, '2026-10-01 08:55:54'),
(2, 23, '2026-10-01 08:55:54'),
(2, 24, '2026-10-01 08:55:54'),
(2, 25, '2026-10-01 08:55:54'),
(2, 26, '2026-10-01 08:55:54'),
(2, 27, '2026-10-01 08:55:54'),
(2, 29, '2026-10-01 08:55:54'),
(2, 30, '2026-10-01 08:55:54'),
(2, 31, '2026-10-01 08:55:54'),
(2, 32, '2026-10-01 08:55:54'),
(2, 33, '2026-10-01 08:55:54'),
(2, 35, '2026-10-01 10:28:52'),
(2, 36, '2026-10-01 10:28:52'),
(2, 37, '2026-10-01 10:28:52'),
(2, 38, '2026-10-01 10:28:52'),
(2, 39, '2026-10-01 10:28:52'),
(3, 1, '2026-10-01 08:55:54'),
(3, 2, '2026-10-01 08:55:54'),
(3, 12, '2026-10-01 08:55:54'),
(3, 19, '2026-10-01 08:55:54'),
(3, 21, '2026-10-01 08:55:54'),
(3, 24, '2026-10-01 08:55:54'),
(3, 25, '2026-10-01 08:55:54'),
(3, 27, '2026-10-01 08:55:54'),
(3, 30, '2026-10-01 08:55:54'),
(3, 35, '2026-10-01 10:28:52'),
(3, 36, '2026-10-01 10:28:52'),
(3, 37, '2026-10-01 10:28:52'),
(4, 1, '2026-10-01 08:55:54'),
(4, 2, '2026-10-01 08:55:54'),
(4, 12, '2026-10-01 08:55:54'),
(4, 30, '2026-10-01 08:55:54'),
(4, 35, '2026-10-01 10:28:52');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `recurrence_parent_id` int(10) UNSIGNED DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `estimated_hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `status` enum('Scheduled','In Progress','Completed','Missed','Cancelled','Rescheduled') NOT NULL DEFAULT 'Scheduled',
  `notes` text DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `project_id`, `task_id`, `user_id`, `recurrence_parent_id`, `start_datetime`, `end_datetime`, `estimated_hours`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 3, NULL, '2026-10-01 09:00:00', '2026-10-01 12:00:00', 3.00, 'Scheduled', 'Homepage layout and CMS mapping.', 2, '2026-10-01 10:28:52', '2026-10-01 10:28:52'),
(2, 1, NULL, 4, NULL, '2026-10-01 10:00:00', '2026-10-01 14:00:00', 4.00, 'In Progress', 'Visual system and template polish.', 2, '2026-10-01 10:28:52', '2026-10-01 10:28:52'),
(17, 2, 2, 1, NULL, '2026-10-02 16:34:00', '2026-10-02 16:36:00', 0.03, 'Scheduled', NULL, 1, '2026-10-02 16:34:05', '2026-10-02 16:34:05'),
(18, 2, 2, 4, NULL, '2026-10-03 07:00:00', '2026-10-04 03:30:00', 20.50, 'In Progress', NULL, 1, '2026-10-03 07:26:21', '2026-10-03 07:26:21'),
(19, 2, 3, 4, NULL, '2026-10-03 07:00:00', '2026-10-04 08:00:00', 24.00, 'In Progress', NULL, 1, '2026-10-03 07:27:33', '2026-10-03 07:27:33');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_recurrences`
--

CREATE TABLE `schedule_recurrences` (
  `id` int(10) UNSIGNED NOT NULL,
  `schedule_id` int(10) UNSIGNED NOT NULL,
  `recurrence_type` enum('daily','weekly','weekdays','custom') NOT NULL DEFAULT 'weekly',
  `repeat_until` date DEFAULT NULL,
  `days_of_week` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','int','bool','json') NOT NULL DEFAULT 'string',
  `setting_group` varchar(40) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`, `updated_at`) VALUES
(1, 'app_name', 'TimeTrack', 'string', 'general', 'Name shown in the header and emails.', '2026-10-01 08:55:54'),
(3, 'company_email', 'hello@timetrack.local', 'string', 'general', 'Contact address for system emails.', '2026-10-01 08:55:54'),
(4, 'default_timezone', 'UTC', 'string', 'general', 'Timezone used when a user has not chosen one.', '2026-10-02 08:52:09'),
(5, 'date_format', 'M j, Y', 'string', 'general', 'PHP date() format for dates.', '2026-10-01 08:55:54'),
(6, 'time_format', 'H:i', 'string', 'general', 'PHP date() format for times.', '2026-10-01 08:55:54'),
(8, 'currency', 'USD', 'string', 'billing', 'ISO currency code for rates and budgets.', '2026-10-02 08:52:09'),
(9, 'default_hourly_rate', '0', 'string', 'billing', 'Rate applied to billable projects without their own rate.', '2026-10-02 08:52:09'),
(11, 'allow_manual_time_entries', '1', 'bool', 'time', 'Let employees add time entries by hand.', '2026-10-01 08:55:54'),
(13, 'timer_max_hours', '12', 'int', 'time', 'Stop a running timer automatically after this many hours.', '2026-10-01 08:55:54'),
(14, 'notifications_enabled', '1', 'bool', 'system', 'Create in-app notifications.', '2026-10-01 08:55:54'),
(15, 'maintenance_mode', '0', 'bool', 'system', 'Block non-admin sign-ins while maintenance is under way.', '2026-10-01 08:55:54'),
(16, 'currency_symbol', '$', 'string', 'billing', 'Symbol shown next to money amounts.', '2026-10-02 08:52:09'),
(30, 'company_name', 'Maven Projects LLP', 'string', 'general', 'Legacy company name restored from workspace name.', '2026-10-02 17:16:16'),
(31, 'week_start_day', '1', 'int', 'general', 'Legacy week start restored from workspace policy.', '2026-10-02 17:16:16'),
(32, 'working_hours_per_day', '8', 'string', 'general', 'Legacy working hours restored from workspace daily capacity.', '2026-10-02 17:16:16'),
(33, 'time_rounding_minutes', '1', 'int', 'time', 'Legacy rounding restored from workspace policy.', '2026-10-02 17:16:16'),
(34, 'timesheet_approval', '0', 'bool', 'time', 'Legacy approval switch restored from workspace policy.', '2026-10-02 17:16:16');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `parent_task_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('To Do','In Progress','On Hold','Review','Completed','Cancelled') NOT NULL DEFAULT 'To Do',
  `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `assigned_to` int(10) UNSIGNED DEFAULT NULL,
  `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `completion_percent` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `is_billable` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_id`, `parent_task_id`, `name`, `description`, `status`, `priority`, `assigned_to`, `estimated_hours`, `completion_percent`, `start_date`, `due_date`, `is_billable`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'CON - Building Envelope', NULL, 'In Progress', 'Medium', NULL, 154.00, 0, NULL, '2026-10-15', 0, 1, '2026-10-01 10:49:55', '2026-10-01 10:49:55'),
(2, 2, NULL, 'CON - Building Envelope', NULL, 'To Do', 'Medium', NULL, 24.00, 0, NULL, '2026-10-05', 0, 1, '2026-10-01 16:27:07', '2026-10-02 08:17:19'),
(3, 2, NULL, 'Test', NULL, 'Completed', 'Medium', NULL, 0.00, 100, NULL, NULL, 0, 1, '2026-10-01 19:31:40', '2026-10-02 08:32:15'),
(4, 1, NULL, 'CON - Furniture', NULL, 'To Do', 'Medium', NULL, 0.00, 0, NULL, NULL, 1, 1, '2026-10-03 07:07:33', '2026-10-03 07:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `task_assignees`
--

CREATE TABLE `task_assignees` (
  `id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `task_assignees`
--

INSERT INTO `task_assignees` (`id`, `task_id`, `user_id`, `created_at`) VALUES
(1, 1, 2, '2026-10-01 10:49:55'),
(2, 1, 3, '2026-10-01 10:49:55'),
(3, 1, 1, '2026-10-01 10:49:55'),
(4, 1, 4, '2026-10-01 10:49:55'),
(6, 3, 1, '2026-10-01 19:31:56'),
(7, 3, 3, '2026-10-01 19:31:56');

-- --------------------------------------------------------

--
-- Table structure for table `timesheets`
--

CREATE TABLE `timesheets` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `submission_token` varchar(64) DEFAULT NULL,
  `total_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `billable_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` enum('Draft','Submitted','Approved','Rejected') NOT NULL DEFAULT 'Draft',
  `submitted_at` datetime DEFAULT NULL,
  `approved_by` int(10) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `rejection_reason` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timesheets`
--

INSERT INTO `timesheets` (`id`, `user_id`, `start_date`, `end_date`, `submission_token`, `total_seconds`, `billable_seconds`, `status`, `submitted_at`, `approved_by`, `approved_at`, `rejection_reason`, `created_at`, `updated_at`) VALUES
(1, 1, '2026-09-28', '2026-10-04', 'legacy-1', 2280, 2280, 'Submitted', '2026-10-01 12:57:26', NULL, NULL, NULL, '2026-10-01 12:57:26', '2026-10-02 16:49:39'),
(2, 3, '2026-09-28', '2026-10-04', 'legacy-2', 31, 31, 'Approved', '2026-10-01 12:58:58', 1, '2026-10-01 15:10:48', NULL, '2026-10-01 12:58:58', '2026-10-02 16:49:39'),
(3, 1, '2026-10-01', '2026-10-02', 'legacy-3', 1104, 1104, 'Submitted', '2026-10-02 11:53:58', NULL, NULL, NULL, '2026-10-02 11:53:58', '2026-10-02 16:49:39'),
(4, 1, '2026-09-28', '2026-10-04', 'a0e7b8a9480845ba8835d21d51d78537', 47, 47, 'Submitted', '2026-10-02 16:50:07', NULL, NULL, NULL, '2026-10-02 16:50:07', '2026-10-02 16:50:07'),
(5, 1, '2026-09-28', '2026-10-04', '66f8954c29d7db5b98071b6eeed16c58', 54, 54, 'Submitted', '2026-10-02 16:50:23', NULL, NULL, NULL, '2026-10-02 16:50:23', '2026-10-02 16:50:23');

-- --------------------------------------------------------

--
-- Table structure for table `timesheet_entries`
--

CREATE TABLE `timesheet_entries` (
  `timesheet_id` int(10) UNSIGNED NOT NULL,
  `time_entry_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timesheet_entries`
--

INSERT INTO `timesheet_entries` (`timesheet_id`, `time_entry_id`, `created_at`) VALUES
(1, 1, '2026-10-01 12:57:26'),
(1, 2, '2026-10-01 12:57:26'),
(1, 3, '2026-10-01 12:57:26'),
(1, 4, '2026-10-01 12:57:26'),
(1, 5, '2026-10-01 12:57:26'),
(2, 6, '2026-10-01 12:58:58'),
(3, 7, '2026-10-02 11:53:58'),
(3, 9, '2026-10-02 11:53:58'),
(3, 13, '2026-10-02 11:53:58'),
(4, 19, '2026-10-02 16:50:07'),
(5, 8, '2026-10-02 16:50:23');

-- --------------------------------------------------------

--
-- Table structure for table `time_entries`
--

CREATE TABLE `time_entries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `started_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  `duration_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_billable` tinyint(1) NOT NULL DEFAULT 0,
  `auto_stopped` tinyint(1) NOT NULL DEFAULT 0,
  `description` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `time_entries`
--

INSERT INTO `time_entries` (`id`, `project_id`, `task_id`, `user_id`, `started_at`, `ended_at`, `duration_seconds`, `is_billable`, `auto_stopped`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 1, '2026-10-01 11:22:40', '2026-10-01 11:50:25', 1665, 1, 0, NULL, '2026-10-01 11:50:25', '2026-10-01 11:50:25'),
(2, 1, 1, 1, '2026-10-01 11:50:37', '2026-10-01 11:50:54', 17, 1, 0, NULL, '2026-10-01 11:50:54', '2026-10-01 11:50:54'),
(3, 1, 1, 1, '2026-10-01 11:51:20', '2026-10-01 11:57:16', 356, 1, 0, NULL, '2026-10-01 11:57:16', '2026-10-01 11:57:16'),
(4, 1, 1, 1, '2026-10-01 11:57:27', '2026-10-01 12:01:19', 232, 1, 0, NULL, '2026-10-01 12:01:19', '2026-10-01 12:01:19'),
(5, 1, NULL, 1, '2026-10-01 12:01:21', '2026-10-01 12:01:31', 10, 1, 0, 'Working on Master Drawings', '2026-10-01 12:01:31', '2026-10-01 12:01:31'),
(6, 1, 1, 3, '2026-10-01 12:58:17', '2026-10-01 12:58:48', 31, 1, 0, NULL, '2026-10-01 12:58:48', '2026-10-01 12:58:48'),
(7, 1, NULL, 1, '2026-10-01 15:24:38', '2026-10-01 15:36:14', 696, 1, 0, 'General', '2026-10-01 15:36:14', '2026-10-01 15:36:14'),
(8, 2, 2, 1, '2026-10-01 16:27:35', '2026-10-01 16:28:29', 54, 1, 0, NULL, '2026-10-01 16:28:29', '2026-10-01 16:28:29'),
(9, 2, 2, 1, '2026-10-01 16:46:16', '2026-10-01 16:52:49', 393, 1, 0, NULL, '2026-10-01 16:52:49', '2026-10-01 16:52:49'),
(10, 2, 2, 3, '2026-10-01 16:55:59', '2026-10-01 19:59:12', 10993, 1, 0, NULL, '2026-10-01 19:59:12', '2026-10-01 19:59:12'),
(11, 2, 3, 1, '2026-10-01 19:48:00', '2026-10-02 05:17:11', 34151, 1, 0, NULL, '2026-10-02 05:17:11', '2026-10-02 05:17:11'),
(13, 1, 1, 1, '2026-10-02 10:07:52', '2026-10-02 10:08:07', 15, 1, 0, NULL, '2026-10-02 10:08:07', '2026-10-02 10:08:07'),
(14, 2, 3, 3, '2026-10-01 19:59:47', '2026-10-02 10:38:28', 52721, 1, 0, NULL, '2026-10-02 10:38:28', '2026-10-02 10:38:28'),
(15, 1, 1, 3, '2026-10-02 08:43:00', '2026-10-02 09:43:00', 3600, 1, 0, NULL, '2026-10-02 10:44:04', '2026-10-02 10:44:04'),
(16, 1, 1, 3, '2026-10-02 10:48:32', '2026-10-02 10:48:41', 9, 1, 0, NULL, '2026-10-02 10:48:41', '2026-10-02 10:48:41'),
(17, 1, 1, 3, '2026-10-02 10:49:00', '2026-10-02 10:49:05', 5, 1, 0, NULL, '2026-10-02 10:49:05', '2026-10-02 10:49:05'),
(18, 1, 1, 3, '2026-10-02 10:52:01', '2026-10-02 10:52:05', 4, 1, 0, NULL, '2026-10-02 10:52:05', '2026-10-02 10:52:05'),
(19, 2, 2, 1, '2026-10-02 15:59:52', '2026-10-02 16:00:39', 47, 1, 0, NULL, '2026-10-02 16:00:39', '2026-10-02 16:00:39'),
(20, 1, 1, 1, '2026-10-02 16:02:06', '2026-10-02 16:03:06', 60, 1, 0, NULL, '2026-10-02 16:03:06', '2026-10-02 16:03:06'),
(21, 1, 1, 1, '2026-10-02 16:23:33', '2026-10-02 16:26:07', 154, 1, 0, NULL, '2026-10-02 16:26:07', '2026-10-02 16:26:07'),
(22, 2, 2, 1, '2026-10-02 16:34:52', '2026-10-02 16:49:53', 901, 1, 0, NULL, '2026-10-02 16:49:53', '2026-10-02 16:49:53'),
(23, 1, 1, 3, '2026-10-02 16:37:03', '2026-10-03 04:37:03', 43200, 1, 1, NULL, '2026-10-03 06:42:00', '2026-10-03 06:42:00'),
(24, 1, 1, 3, '2026-10-03 06:42:49', '2026-10-03 06:42:50', 1, 1, 0, NULL, '2026-10-03 06:42:50', '2026-10-03 06:42:50'),
(25, 3, NULL, 1, '2026-10-03 07:12:06', '2026-10-03 07:12:10', 4, 1, 0, 'test', '2026-10-03 07:12:10', '2026-10-03 07:12:10'),
(26, 4, NULL, 1, '2026-10-03 07:12:19', '2026-10-03 07:12:24', 5, 1, 0, 'test 2', '2026-10-03 07:12:24', '2026-10-03 07:12:24'),
(27, 2, 2, 1, '2026-10-03 07:13:25', '2026-10-03 07:39:45', 1580, 1, 0, NULL, '2026-10-03 07:39:45', '2026-10-03 07:39:45');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `role` enum('admin','manager','employee','client') NOT NULL DEFAULT 'employee',
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `timezone` varchar(64) NOT NULL DEFAULT 'UTC',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `failed_login_attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `role`, `name`, `email`, `password`, `phone`, `job_title`, `hourly_rate`, `timezone`, `status`, `failed_login_attempts`, `locked_until`, `last_login_at`, `last_login_ip`, `password_changed_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'System Admin', 'admin@timetrack.local', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', NULL, 'Administrator', 0.00, 'Asia/Karachi', 'active', 0, NULL, '2026-10-03 06:53:11', '58.65.217.235', '2026-10-01 08:55:54', '2026-10-01 08:55:54', '2026-10-03 06:53:11'),
(2, 2, 'manager', 'Morgan Lee', 'manager@timetrack.local', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', NULL, 'Project Manager', 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, '2026-10-01 08:55:54', '2026-10-01 08:55:54', '2026-10-01 15:29:35'),
(3, 3, 'employee', 'John Carter', 'john@timetrack.local', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', NULL, 'Developer', 0.00, 'Asia/Karachi', 'active', 0, NULL, '2026-10-03 06:41:59', '58.65.217.235', '2026-10-01 08:55:54', '2026-10-01 08:55:54', '2026-10-03 06:41:59'),
(4, 3, 'employee', 'Sarah Khan', 'sarah@timetrack.local', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', NULL, 'Designer', 0.00, 'Asia/Karachi', 'active', 0, NULL, '2026-10-03 06:43:11', '58.65.217.235', '2026-10-01 08:55:54', '2026-10-01 08:55:54', '2026-10-03 06:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `workspaces`
--

CREATE TABLE `workspaces` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(160) NOT NULL,
  `logo_path` varchar(500) DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workspaces`
--

INSERT INTO `workspaces` (`id`, `name`, `logo_path`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Maven Projects LLP.', '/uploads/workspace/logo-a14157ace63e7d5fb1f9.png', 1, '2026-10-02 08:51:16', '2026-10-02 17:39:24');

-- --------------------------------------------------------

--
-- Table structure for table `workspace_settings`
--

CREATE TABLE `workspace_settings` (
  `workspace_id` int(10) UNSIGNED NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` varchar(1000) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workspace_settings`
--

INSERT INTO `workspace_settings` (`workspace_id`, `setting_key`, `setting_value`, `updated_at`) VALUES
(1, 'activity_monitoring_enabled', '1', '2026-10-03 06:29:26'),
(1, 'approval_period', 'weekly', '2026-10-03 06:29:26'),
(1, 'audit_log_enabled', '1', '2026-10-03 06:29:26'),
(1, 'billable_hours_enabled', '1', '2026-10-03 06:29:26'),
(1, 'breaks_enabled', '1', '2026-10-03 06:29:26'),
(1, 'daily_capacity', '8', '2026-10-03 06:29:26'),
(1, 'default_project_visibility', 'private', '2026-10-03 06:29:26'),
(1, 'duration_format', 'clock_seconds', '2026-10-03 06:29:26'),
(1, 'edit_time_others_policy', 'admins_team_managers', '2026-10-03 06:29:26'),
(1, 'expense_approval_enabled', '0', '2026-10-03 06:29:26'),
(1, 'expenses_enabled', '0', '2026-10-03 06:29:26'),
(1, 'favorite_entries_enabled', '1', '2026-10-03 06:29:26'),
(1, 'favorites_enabled', '1', '2026-10-03 06:29:26'),
(1, 'force_timer', '0', '2026-10-03 06:29:26'),
(1, 'gps_enabled', '1', '2026-10-03 06:29:26'),
(1, 'hide_projects', '0', '2026-10-03 06:29:26'),
(1, 'hide_reports', '0', '2026-10-03 06:29:26'),
(1, 'hide_team', '0', '2026-10-03 06:29:26'),
(1, 'hide_tracker', '0', '2026-10-03 06:29:26'),
(1, 'invoice_manager_policy', 'admins', '2026-10-03 06:29:26'),
(1, 'invoicing_enabled', '0', '2026-10-03 06:29:26'),
(1, 'kiosk_enabled', '1', '2026-10-03 06:29:26'),
(1, 'lock_time_enabled', '0', '2026-10-03 06:29:26'),
(1, 'organize_time_by', 'project_task', '2026-10-03 06:29:26'),
(1, 'project_creation_policy', 'admins_project_managers', '2026-10-03 06:29:26'),
(1, 'project_status_visibility', 'anyone', '2026-10-03 06:29:26'),
(1, 'regular_user_time_visibility', 'own', '2026-10-03 06:29:26'),
(1, 'required_fields', '', '2026-10-03 06:29:26'),
(1, 'scheduling_enabled', '1', '2026-10-03 06:29:26'),
(1, 'screenshots_enabled', '1', '2026-10-03 06:29:26'),
(1, 'tag_creation_policy', 'anyone', '2026-10-03 06:29:26'),
(1, 'task_creation_policy', 'admins_project_managers', '2026-10-03 06:29:26'),
(1, 'time_approval_enabled', '1', '2026-10-03 06:29:26'),
(1, 'time_off_enabled', '1', '2026-10-03 06:29:26'),
(1, 'time_rounding_minutes', '1', '2026-10-03 06:29:26'),
(1, 'timesheet_approver_policy', 'admins_team_managers', '2026-10-03 06:29:26'),
(1, 'timesheet_enabled', '1', '2026-10-03 06:29:26'),
(1, 'week_start', 'monday', '2026-10-03 06:29:26'),
(1, 'working_days', 'Mon,Tue,Wed,Thu,Fri', '2026-10-03 06:29:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_timers`
--
ALTER TABLE `active_timers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_active_timers_user` (`user_id`),
  ADD KEY `idx_active_timers_project` (`project_id`),
  ADD KEY `idx_active_timers_task` (`task_id`);

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_activity_user` (`user_id`),
  ADD KEY `idx_activity_action` (`action`),
  ADD KEY `idx_activity_entity` (`entity_type`,`entity_id`),
  ADD KEY `idx_activity_created` (`created_at`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_clients_name` (`name`),
  ADD KEY `idx_clients_email` (`email`),
  ADD KEY `idx_clients_status` (`status`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_notifications_user_read` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_permissions_name` (`name`),
  ADD KEY `idx_permissions_module` (`module`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_projects_code` (`project_code`),
  ADD KEY `idx_projects_client` (`client_id`),
  ADD KEY `idx_projects_status` (`status`),
  ADD KEY `idx_projects_manager` (`manager_id`),
  ADD KEY `idx_projects_due` (`due_date`),
  ADD KEY `fk_projects_created_by` (`created_by`);

--
-- Indexes for table `project_favorites`
--
ALTER TABLE `project_favorites`
  ADD PRIMARY KEY (`user_id`,`project_id`),
  ADD KEY `idx_project_favorites_project` (`project_id`);

--
-- Indexes for table `project_members`
--
ALTER TABLE `project_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_project_members_project_user` (`project_id`,`user_id`),
  ADD KEY `idx_project_members_user` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_roles_name` (`name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `idx_role_permissions_permission` (`permission_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_schedules_user_time` (`user_id`,`start_datetime`,`end_datetime`),
  ADD KEY `idx_schedules_project` (`project_id`),
  ADD KEY `idx_schedules_task` (`task_id`),
  ADD KEY `idx_schedules_status` (`status`),
  ADD KEY `idx_schedules_created_by` (`created_by`),
  ADD KEY `idx_schedules_recurrence_parent` (`recurrence_parent_id`);

--
-- Indexes for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_recurrence_schedule` (`schedule_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_settings_key` (`setting_key`),
  ADD KEY `idx_settings_group` (`setting_group`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tasks_project` (`project_id`),
  ADD KEY `idx_tasks_parent` (`parent_task_id`),
  ADD KEY `idx_tasks_assigned` (`assigned_to`),
  ADD KEY `idx_tasks_status` (`status`),
  ADD KEY `idx_tasks_priority` (`priority`),
  ADD KEY `idx_tasks_due` (`due_date`),
  ADD KEY `fk_tasks_created_by` (`created_by`);

--
-- Indexes for table `task_assignees`
--
ALTER TABLE `task_assignees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_task_assignees` (`task_id`,`user_id`),
  ADD KEY `idx_task_assignees_user` (`user_id`);

--
-- Indexes for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_timesheets_submission_token` (`submission_token`),
  ADD KEY `idx_timesheets_status` (`status`),
  ADD KEY `idx_timesheets_submitted` (`submitted_at`),
  ADD KEY `idx_timesheets_approved_by` (`approved_by`),
  ADD KEY `idx_timesheets_user` (`user_id`),
  ADD KEY `idx_timesheets_user_period` (`user_id`,`start_date`,`end_date`);

--
-- Indexes for table `timesheet_entries`
--
ALTER TABLE `timesheet_entries`
  ADD PRIMARY KEY (`timesheet_id`,`time_entry_id`),
  ADD UNIQUE KEY `uq_timesheet_entries_entry` (`time_entry_id`),
  ADD KEY `idx_timesheet_entries_timesheet` (`timesheet_id`);

--
-- Indexes for table `time_entries`
--
ALTER TABLE `time_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_time_entries_project` (`project_id`),
  ADD KEY `idx_time_entries_task` (`task_id`),
  ADD KEY `idx_time_entries_user` (`user_id`),
  ADD KEY `idx_time_entries_running` (`user_id`,`ended_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD KEY `idx_users_status` (`status`),
  ADD KEY `idx_users_role_id` (`role_id`),
  ADD KEY `idx_users_role_status` (`role`,`status`);

--
-- Indexes for table `workspaces`
--
ALTER TABLE `workspaces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_workspaces_created_by` (`created_by`);

--
-- Indexes for table `workspace_settings`
--
ALTER TABLE `workspace_settings`
  ADD PRIMARY KEY (`workspace_id`,`setting_key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `active_timers`
--
ALTER TABLE `active_timers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `project_members`
--
ALTER TABLE `project_members`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `task_assignees`
--
ALTER TABLE `task_assignees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `timesheets`
--
ALTER TABLE `timesheets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `time_entries`
--
ALTER TABLE `time_entries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `workspaces`
--
ALTER TABLE `workspaces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

-- --------------------------------------------------------

--
-- Structure for view `audit_logs`
--
DROP TABLE IF EXISTS `audit_logs`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u897128490_timetracker`@`127.0.0.1` SQL SECURITY DEFINER VIEW `audit_logs`  AS SELECT `activity_logs`.`id` AS `id`, `activity_logs`.`user_id` AS `user_id`, `activity_logs`.`action` AS `action`, `activity_logs`.`module` AS `module`, `activity_logs`.`entity_type` AS `entity_type`, `activity_logs`.`entity_id` AS `entity_id`, `activity_logs`.`record_id` AS `record_id`, `activity_logs`.`ip_address` AS `ip_address`, `activity_logs`.`user_agent` AS `user_agent`, `activity_logs`.`meta` AS `meta`, `activity_logs`.`old_value` AS `old_value`, `activity_logs`.`new_value` AS `new_value`, `activity_logs`.`created_at` AS `created_at` FROM `activity_logs` ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `active_timers`
--
ALTER TABLE `active_timers`
  ADD CONSTRAINT `fk_active_timers_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_active_timers_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_active_timers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `fk_projects_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_projects_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_projects_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `project_favorites`
--
ALTER TABLE `project_favorites`
  ADD CONSTRAINT `fk_project_favorites_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_project_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_members`
--
ALTER TABLE `project_members`
  ADD CONSTRAINT `fk_project_members_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_project_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `fk_schedules_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_recurrence_parent` FOREIGN KEY (`recurrence_parent_id`) REFERENCES `schedules` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  ADD CONSTRAINT `fk_recurrence_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `fk_tasks_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_parent` FOREIGN KEY (`parent_task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `task_assignees`
--
ALTER TABLE `task_assignees`
  ADD CONSTRAINT `fk_task_assignees_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_task_assignees_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD CONSTRAINT `fk_timesheets_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_timesheets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `time_entries`
--
ALTER TABLE `time_entries`
  ADD CONSTRAINT `fk_time_entries_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_time_entries_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_time_entries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `workspaces`
--
ALTER TABLE `workspaces`
  ADD CONSTRAINT `fk_workspaces_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `workspace_settings`
--
ALTER TABLE `workspace_settings`
  ADD CONSTRAINT `fk_workspace_settings_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
