/* Reports: stacked day bars, share donut, print, auto-submit selects. Data comes from data-* attributes (CSP forbids inline scripts). */
(function () {
    'use strict';

    var hms = function (s) {
        s = Math.max(0, Math.round(s));
        var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
        return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m + ':' + (x < 10 ? '0' : '') + x;
    };
    var read = function (el, attr) {
        try { return JSON.parse(el.getAttribute(attr) || '[]'); } catch (e) { return []; }
    };

    document.querySelectorAll('select[data-autosubmit]').forEach(function (sel) {
        sel.addEventListener('change', function () { if (sel.form) { sel.form.submit(); } });
    });
    document.querySelectorAll('[data-report-print]').forEach(function (btn) {
        btn.addEventListener('click', function () { window.print(); });
    });
    document.querySelectorAll('[data-collapse-all]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var rows = document.querySelectorAll('.rk-child');
            var anyOpen = Array.prototype.some.call(rows, function (r) { return r.classList.contains('show'); });
            rows.forEach(function (r) { r.classList.toggle('show', !anyOpen); });
        });
    });

    if (typeof Chart === 'undefined') { return; }

    var dark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    var text = dark ? '#dfe6ed' : '#2b3a4a';
    var muted = '#8a97a4';
    var grid = dark ? '#333c46' : '#e3e8ec';

    // Total label above each bar ("00:00:00" above empty days), like Clockify.
    var topLabels = {
        id: 'topLabels',
        afterDatasetsDraw: function (chart, args, opts) {
            var ctx = chart.ctx, area = chart.chartArea, ys = chart.scales.y;
            ctx.save();
            ctx.fillStyle = text;
            ctx.font = '13px Roboto, "IBM Plex Sans", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            var meta = chart.getDatasetMeta(0);
            meta.data.forEach(function (bar, i) {
                var total = opts.totals[i] || 0;
                var y = total > 0 ? ys.getPixelForValue(total / 3600) : area.bottom;
                ctx.fillText(hms(total), bar.x, y - 6);
            });
            ctx.restore();
        }
    };

    var bar = document.querySelector('[data-report-bar]');
    if (bar) {
        var days = read(bar, 'data-report-bar');
        var max = 0;
        days.forEach(function (d) { max = Math.max(max, d.seconds / 3600); });
        new Chart(bar.querySelector('canvas'), {
            type: 'bar',
            data: {
                labels: days.map(function (d) { return d.label; }),
                datasets: [
                    { label: 'Billable', data: days.map(function (d) { return d.billable / 3600; }), backgroundColor: '#8bc34a', maxBarThickness: 150, stack: 's' },
                    { label: 'Non-billable', data: days.map(function (d) { return (d.seconds - d.billable) / 3600; }), backgroundColor: '#03a9f4', maxBarThickness: 150, stack: 's' }
                ]
            },
            options: {
                maintainAspectRatio: false,
                layout: { padding: { top: 24 } },
                plugins: {
                    legend: { display: false },
                    topLabels: { totals: days.map(function (d) { return d.seconds; }) },
                    tooltip: { callbacks: { label: function (c) { return c.dataset.label + ': ' + hms(c.parsed.y * 3600); } } }
                },
                scales: {
                    y: {
                        beginAtZero: true, stacked: true, suggestedMax: max > 0 ? max * 1.12 : 8,
                        border: { display: false }, grid: { color: grid, borderDash: [3, 3] },
                        ticks: { color: muted, maxTicksLimit: 10, callback: function (v) { return v > 0 ? (Math.round(v * 10) / 10) + 'h' : ''; } }
                    },
                    x: { stacked: true, grid: { display: false }, border: { color: grid }, ticks: { color: text } }
                }
            },
            plugins: [topLabels]
        });
    }

    var donut = document.querySelector('[data-report-donut]');
    if (donut) {
        var groups = read(donut, 'data-report-donut');
        if (groups.length) {
            new Chart(donut.querySelector('canvas'), {
                type: 'doughnut',
                data: {
                    labels: groups.map(function (g) { return g.label; }),
                    datasets: [{ data: groups.map(function (g) { return g.seconds; }), backgroundColor: groups.map(function (g) { return g.color; }), borderWidth: 2, borderColor: dark ? '#1f262d' : '#fff' }]
                },
                options: {
                    maintainAspectRatio: false,
                    cutout: '52%',
                    plugins: {
                        legend: { display: false },
                        tooltip: { callbacks: { label: function (c) { return c.label + ': ' + hms(c.parsed); } } }
                    }
                }
            });
        } else {
            var center = donut.querySelector('.rk-donut-center');
            if (center) { center.textContent = 'No data'; }
        }
    }
})();
