<?php
/**
 * Create / edit client modal. Fields are filled by assets/js/app.js from data-client-edit.
 *
 * @var bool $canCreate
 * @var bool $canEdit
 */

$canCreate = $canCreate ?? false;
$canEdit   = $canEdit ?? false;
?>
<div class="modal fade" id="clientModal" tabindex="-1" aria-labelledby="clientModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form method="post" action="<?= e(url('/clients')) ?>" id="clientForm" class="modal-content" novalidate data-single-submit>
            <?= csrf_field() ?>
            <div class="modal-header">
                <h2 class="modal-title h5" id="clientModalTitle">New client</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-12">
                        <label for="client_name" class="form-label">Name</label>
                        <input type="text" id="client_name" name="name" maxlength="160" required
                               class="form-control<?= field_error('name') ? ' is-invalid' : '' ?>"
                               value="<?= e(old('name')) ?>">
                        <?php if (field_error('name')): ?><div class="invalid-feedback"><?= e(field_error('name')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="client_email" class="form-label">Email</label>
                        <input type="email" id="client_email" name="email" maxlength="190"
                               class="form-control<?= field_error('email') ? ' is-invalid' : '' ?>"
                               value="<?= e(old('email')) ?>">
                        <?php if (field_error('email')): ?><div class="invalid-feedback"><?= e(field_error('email')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="client_phone" class="form-label">Phone</label>
                        <input type="tel" id="client_phone" name="phone" maxlength="30"
                               class="form-control<?= field_error('phone') ? ' is-invalid' : '' ?>"
                               value="<?= e(old('phone')) ?>">
                        <?php if (field_error('phone')): ?><div class="invalid-feedback"><?= e(field_error('phone')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-8">
                        <label for="client_address" class="form-label">Address</label>
                        <input type="text" id="client_address" name="address" maxlength="255"
                               class="form-control<?= field_error('address') ? ' is-invalid' : '' ?>"
                               value="<?= e(old('address')) ?>">
                        <?php if (field_error('address')): ?><div class="invalid-feedback"><?= e(field_error('address')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <label for="client_status" class="form-label">Status</label>
                        <select id="client_status" name="status" class="form-select<?= field_error('status') ? ' is-invalid' : '' ?>" required>
                            <?php $st = old('status', 'active'); ?>
                            <option value="active"<?= $st === 'active' ? ' selected' : '' ?>>Active</option>
                            <option value="inactive"<?= $st === 'inactive' ? ' selected' : '' ?>>Inactive</option>
                        </select>
                        <?php if (field_error('status')): ?><div class="invalid-feedback"><?= e(field_error('status')) ?></div><?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <?php if ($canCreate || $canEdit): ?>
                    <button type="submit" class="btn btn-primary" id="clientSubmit">Save client</button>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
