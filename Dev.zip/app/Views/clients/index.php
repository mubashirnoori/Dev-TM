<?php
/**
 * Client directory.
 *
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int} $result
 * @var string $status
 * @var string $search
 * @var bool   $canCreate
 * @var bool   $canEdit
 * @var bool   $canDelete
 */

$items  = $result['items'];
$query  = static function (array $extra = []) use ($status, $search): string {
    $q = array_filter([
        'status' => $extra['status'] ?? $status,
        'q'      => $extra['q'] ?? $search,
        'page'   => $extra['page'] ?? null,
    ], static fn ($v) => $v !== null && $v !== '' && $v !== 0 && $v !== '0');
    return $q === [] ? '' : '?' . http_build_query($q);
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Clients</h2>
        <p class="page-lead">Companies and contacts that own the work you track.</p>
    </div>
    <?php if ($canCreate): ?>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#clientModal" data-client-new>
            <i class="fa-solid fa-plus me-1" aria-hidden="true"></i>New client
        </button>
    <?php endif; ?>
</div>

<form method="get" action="<?= e(url('/clients')) ?>" class="filter-bar">
    <div class="filter-search">
        <label for="client-q" class="visually-hidden">Search clients</label>
        <input type="search" id="client-q" name="q" class="form-control" placeholder="Search name or email"
               value="<?= e($search) ?>">
    </div>
    <div>
        <label for="client-status" class="visually-hidden">Status</label>
        <select id="client-status" name="status" class="form-select">
            <option value="">All statuses</option>
            <option value="active"<?= $status === 'active' ? ' selected' : '' ?>>Active</option>
            <option value="inactive"<?= $status === 'inactive' ? ' selected' : '' ?>>Inactive</option>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">
            Directory
            <span class="count-pill"><?= (int) $result['total'] ?></span>
        </h2>
    </div>

    <?php if ($items === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-address-book" aria-hidden="true"></i>
            <p><?= $search !== '' || $status !== '' ? 'No clients match these filters.' : 'No clients yet. Add one to start attaching projects.' ?></p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Projects</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $client): ?>
                        <?php
                        $payload = [
                            'id'      => (int) $client['id'],
                            'name'    => (string) $client['name'],
                            'email'   => (string) ($client['email'] ?? ''),
                            'phone'   => (string) ($client['phone'] ?? ''),
                            'address' => (string) ($client['address'] ?? ''),
                            'status'  => (string) $client['status'],
                        ];
                        ?>
                        <tr>
                            <td>
                                <strong><?= e($client['name']) ?></strong>
                                <?php if (!empty($client['address'])): ?>
                                    <div class="text-secondary small"><?= e($client['address']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($client['email'])): ?>
                                    <a href="mailto:<?= e($client['email']) ?>"><?= e($client['email']) ?></a>
                                <?php endif; ?>
                            </td>
                            <td><?= e($client['phone'] ?? '') ?></td>
                            <td><?= (int) $client['project_count'] ?></td>
                            <td>
                                <span class="status-badge status-<?= e($client['status']) ?>"><?= e(ucfirst((string) $client['status'])) ?></span>
                            </td>
                            <td class="text-end text-nowrap">
                                <?php if ($canEdit): ?>
                                    <button type="button" class="btn btn-sm btn-outline-secondary"
                                            data-bs-toggle="modal" data-bs-target="#clientModal"
                                            data-client-edit="<?= e(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)) ?>"
                                            data-client-action="<?= e(url('/clients/' . (int) $client['id'])) ?>">
                                        Edit
                                    </button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <form method="post" action="<?= e(url('/clients/' . (int) $client['id'] . '/delete')) ?>" class="d-inline"
                                          data-confirm="Delete client <?= e($client['name']) ?>? This cannot be undone.">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"<?= (int) $client['project_count'] > 0 ? ' disabled title="Has projects"' : '' ?>>Delete</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($result['pages'] > 1): ?>
            <nav class="pager" aria-label="Client pages">
                <?php for ($p = 1; $p <= $result['pages']; $p++): ?>
                    <a class="btn btn-sm <?= $p === (int) $result['page'] ? 'btn-primary' : 'btn-outline-secondary' ?>"
                       href="<?= e(url('/clients') . $query(['page' => $p])) ?>"><?= $p ?></a>
                <?php endfor; ?>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>

<?php require APP_PATH . '/Views/clients/form_modal.php'; ?>
