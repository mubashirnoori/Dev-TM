<?php
/**
 * Time report > Detailed.
 *
 * @var list<array<string,mixed>> $rows
 */
require APP_PATH . '/Views/reports/_header.php';
$money = static fn(float $a): string => FormatHelper::money($a, SettingsService::systemString('currency', 'USD'));
$pageUrl = static fn(int $p): string => $tabUrl('detailed') . (str_contains($tabUrl('detailed'), '?') ? '&' : '?') . 'page=' . $p;
?>
<div class="rk-panel">
    <div class="rk-kpis">
        <div class="rk-kpi"><small>Total:</small><strong><?= e($hms($seconds)) ?></strong></div>
        <div class="rk-kpi"><small>Entries:</small><strong><?= (int) $total ?></strong></div>
        <?php if ($canBilling): ?><div class="rk-kpi"><small>Amount:</small><strong><?= e($money($amount)) ?></strong></div><?php endif; ?>
    </div>
</div>
<div class="rk-box">
    <div class="rk-scroll">
    <table class="rk-table">
        <thead><tr><th class="rk-l">Description <i class="fa-solid fa-sort"></i></th><?php if ($canViewAll): ?><th class="rk-l">User</th><?php endif; ?><th class="rk-l">Project</th><th class="rk-l">Task</th><th class="rk-l">Date</th><th class="rk-l">Time</th><th class="rk-c">Billable</th><th class="rk-l">Status</th><th class="rk-r">Duration</th><?php if ($canBilling): ?><th class="rk-r">Amount</th><?php endif; ?></tr></thead>
        <tbody>
        <?php if ($rows === []): ?><tr><td colspan="10" class="rk-empty">No time entries match these filters.</td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td><?= e(FormatHelper::truncate((string) ($r['description'] ?? ''), 80)) ?: '<span class="rk-dash">(No description)</span>' ?></td>
                <?php if ($canViewAll): ?><td><?= e((string) $r['user_name']) ?></td><?php endif; ?>
                <td><?= e((string) $r['project_name']) ?><span class="rk-sub"><?= e((string) $r['client_name']) ?></span></td>
                <td><?= e((string) $r['task_name']) ?: '<span class="rk-dash">–</span>' ?></td>
                <td class="rk-r rk-l"><?= e(FormatHelper::date((string) $r['start_time'])) ?></td>
                <td class="rk-l" style="white-space:nowrap"><?= e(FormatHelper::datetime((string) $r['start_time'], 'H:i')) ?> – <?= e(FormatHelper::datetime((string) $r['end_time'], 'H:i')) ?></td>
                <td class="rk-c"><?= (int) $r['is_billable'] === 1 ? '<i class="fa-solid fa-dollar-sign" style="color:#8bc34a" title="Billable"></i>' : '<span class="rk-dash">–</span>' ?></td>
                <td><?= e((string) $r['status']) ?></td>
                <td class="rk-r"><?= e($hms((int) $r['duration_seconds'])) ?></td>
                <?php if ($canBilling): ?><td class="rk-r"><?= e($money((float) $r['billable_amount'])) ?></td><?php endif; ?>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <div class="rk-pager"><span>Page <?= (int) $page ?> of <?= (int) $pages ?> · <?= (int) $total ?> entries</span>
        <?php if ($page > 1): ?><a href="<?= e($pageUrl($page - 1)) ?>">Previous</a><?php endif; ?>
        <?php if ($page < $pages): ?><a href="<?= e($pageUrl($page + 1)) ?>">Next</a><?php endif; ?>
    </div>
</div>
</div>
