<?php
/**
 * Reporting queries. Reports deliberately use the same time-entry source and
 * date semantics as the Time page. Billing uses the frozen rate stored on the
 * time entry, never the current project/user rate.
 */
declare(strict_types=1);

final class Report extends Model
{
    protected string $table = 'time_entries';
    protected array $columns = ['id'];
    protected array $fillable = [];

    /**
     * @param array<string,mixed> $filters
     * @return array{totals:array<string,mixed>,projects:list<array<string,mixed>>,tasks:list<array<string,mixed>>,users:list<array<string,mixed>>,clients:list<array<string,mixed>>,billable:list<array<string,mixed>>}
     */
    public function summary(array $filters, int $viewerId, string $viewerRole, bool $canViewAll): array
    {
        $startCol = TimeEntry::column('start_time') ?? 'start_time';
        $endCol = TimeEntry::column('end_time') ?? 'end_time';
        $rateCol = TimeEntry::column('billable_rate');
        $descCol = TimeEntry::column('description');
        [$where, $params] = $this->whereClause($filters, $viewerId, $viewerRole, $canViewAll, $startCol);
        $rateExpr = $rateCol !== null ? "COALESCE(te.`{$rateCol}`,0)" : '0';
        $base = ' FROM time_entries te
                  INNER JOIN projects p ON p.id = te.project_id
                  INNER JOIN clients c ON c.id = p.client_id
                  INNER JOIN users u ON u.id = te.user_id
                  LEFT JOIN tasks tk ON tk.id = te.task_id';

        $duration = 'COALESCE(te.duration_seconds,0)';
        $billable = '(CASE WHEN te.is_billable = 1 THEN ' . $duration . ' ELSE 0 END)';
        $money = '(CASE WHEN te.is_billable = 1 THEN (' . $duration . ' / 3600.0) * ' . $rateExpr . ' ELSE 0 END)';

        $totals = Database::fetchOne(
            'SELECT COUNT(*) AS entry_count,
                    COALESCE(SUM(' . $duration . '),0) AS seconds,
                    COALESCE(SUM(' . $billable . '),0) AS billable_seconds,
                    COALESCE(SUM(CASE WHEN te.is_billable = 0 THEN ' . $duration . ' ELSE 0 END),0) AS nonbillable_seconds,
                    COALESCE(SUM(' . $money . '),0) AS billable_amount
             ' . $base . $where,
            $params
        ) ?: [];

        $group = function(string $select, string $groupBy, string $orderBy) use ($base, $where, $params, $duration, $billable, $money): array {
            return Database::fetchAll(
                'SELECT ' . $select . ',
                        COUNT(*) AS entry_count,
                        COALESCE(SUM(' . $duration . '),0) AS seconds,
                        COALESCE(SUM(' . $billable . '),0) AS billable_seconds,
                        COALESCE(SUM(CASE WHEN te.is_billable = 0 THEN ' . $duration . ' ELSE 0 END),0) AS nonbillable_seconds,
                        COALESCE(SUM(' . $money . '),0) AS billable_amount
                 ' . $base . $where . '
                 GROUP BY ' . $groupBy . '
                 ORDER BY ' . $orderBy,
                $params
            );
        };

        $projects = $group('p.id AS project_id, p.name AS project_name, p.project_code, c.id AS client_id, c.name AS client_name', 'p.id, p.name, p.project_code, c.id, c.name', 'seconds DESC, project_name ASC');
        $tasks = $group('tk.id AS task_id, COALESCE(tk.name, \'(No task)\') AS task_name, p.id AS project_id, p.name AS project_name', 'tk.id, tk.name, p.id, p.name', 'seconds DESC, task_name ASC');
        $users = $group('u.id AS user_id, u.name AS user_name, u.email AS user_email', 'u.id, u.name, u.email', 'seconds DESC, user_name ASC');
        $clients = $group('c.id AS client_id, c.name AS client_name', 'c.id, c.name', 'seconds DESC, client_name ASC');

        $billableRows = Database::fetchAll(
            'SELECT CASE WHEN te.is_billable = 1 THEN \'Billable\' ELSE \'Non-billable\' END AS category,
                    COUNT(*) AS entry_count,
                    COALESCE(SUM(' . $duration . '),0) AS seconds,
                    COALESCE(SUM(' . $money . '),0) AS billable_amount
             ' . $base . $where . '
             GROUP BY te.is_billable
             ORDER BY te.is_billable DESC',
            $params
        );

        return [
            'totals' => [
                'entry_count' => (int) ($totals['entry_count'] ?? 0),
                'seconds' => (int) ($totals['seconds'] ?? 0),
                'billable_seconds' => (int) ($totals['billable_seconds'] ?? 0),
                'nonbillable_seconds' => (int) ($totals['nonbillable_seconds'] ?? 0),
                'billable_amount' => (float) ($totals['billable_amount'] ?? 0),
            ],
            'projects' => $this->normalize($projects),
            'tasks' => $this->normalize($tasks),
            'users' => $this->normalize($users),
            'clients' => $this->normalize($clients),
            'billable' => $this->normalize($billableRows),
        ];
    }

    /** @param array<string,mixed> $filters */
    public function detail(array $filters, int $viewerId, string $viewerRole, bool $canViewAll, ?int $limit = null): array
    {
        $startCol = TimeEntry::column('start_time') ?? 'start_time';
        $endCol = TimeEntry::column('end_time') ?? 'end_time';
        $rateCol = TimeEntry::column('billable_rate');
        $descCol = TimeEntry::column('description');
        $rateExpr = $rateCol !== null ? "COALESCE(te.`{$rateCol}`,0)" : '0';
        $descExpr = $descCol !== null ? "te.`{$descCol}`" : "''";
        $statusExpr = "COALESCE(ts.status, 'Unsubmitted')";
        [$where, $params] = $this->whereClause($filters, $viewerId, $viewerRole, $canViewAll, $startCol);

        $sql = 'SELECT te.id, te.user_id, u.name AS user_name, u.email AS user_email,
                       te.project_id, p.name AS project_name, p.project_code,
                       te.task_id, COALESCE(tk.name, \'\') AS task_name,
                       c.id AS client_id, c.name AS client_name,
                       te.`' . $startCol . '` AS start_time, te.`' . $endCol . '` AS end_time, te.duration_seconds,
                       te.is_billable, ' . $rateExpr . ' AS billable_rate,
                       CASE WHEN te.is_billable = 1 THEN (te.duration_seconds / 3600.0) * ' . $rateExpr . ' ELSE 0 END AS billable_amount,
                        ' . $descExpr . ' AS description, ' . $statusExpr . ' AS status
                 FROM time_entries te
                 INNER JOIN projects p ON p.id = te.project_id
                 INNER JOIN clients c ON c.id = p.client_id
                 INNER JOIN users u ON u.id = te.user_id
                 LEFT JOIN tasks tk ON tk.id = te.task_id
                 LEFT JOIN timesheet_entries tse ON tse.time_entry_id = te.id
                 LEFT JOIN timesheets ts ON ts.id = tse.timesheet_id
                 ' . $where . ' ORDER BY te.`' . $startCol . '` DESC, te.id DESC';
        if ($limit !== null) {
            $sql .= ' LIMIT :limit';
            $params['limit'] = max(1, min(10000, $limit));
        }
        return $this->normalize(Database::fetchAll($sql, $params));
    }

    /**
     * Light row set used by the Summary, Weekly, Attendance and Assignments reports.
     * Same filters and visibility rules as detail(); one row per time entry.
     *
     * @param array<string,mixed> $filters
     * @return list<array<string,mixed>>
     */
    public function lean(array $filters, int $viewerId, string $viewerRole, bool $canViewAll, int $limit = 20000): array
    {
        $startCol = TimeEntry::column('start_time') ?? 'start_time';
        $endCol = TimeEntry::column('end_time') ?? 'end_time';
        $descCol = TimeEntry::column('description');
        $breakCol = TimeEntry::column('break_minutes');
        $descExpr = $descCol !== null ? "COALESCE(te.`{$descCol}`,'')" : "''";
        $breakExpr = $breakCol !== null ? "COALESCE(te.`{$breakCol}`,0)" : '0';
        [$where, $params] = $this->whereClause($filters, $viewerId, $viewerRole, $canViewAll, $startCol);

        $sql = 'SELECT te.id, te.user_id, u.name AS user_name,
                       te.project_id, p.name AS project_name,
                       c.id AS client_id, c.name AS client_name,
                       te.task_id, COALESCE(tk.name, \'\') AS task_name,
                       te.`' . $startCol . '` AS start_time, te.`' . $endCol . '` AS end_time,
                       COALESCE(te.duration_seconds,0) AS seconds, te.is_billable,
                       ' . $descExpr . ' AS description, ' . $breakExpr . ' AS break_minutes
                FROM time_entries te
                INNER JOIN projects p ON p.id = te.project_id
                INNER JOIN clients c ON c.id = p.client_id
                INNER JOIN users u ON u.id = te.user_id
                LEFT JOIN tasks tk ON tk.id = te.task_id
                ' . $where . ' ORDER BY te.`' . $startCol . '` ASC, te.id ASC LIMIT ' . max(1, min(50000, $limit));

        $rows = Database::fetchAll($sql, $params);
        foreach ($rows as &$row) {
            foreach (['id', 'user_id', 'project_id', 'client_id', 'task_id', 'seconds', 'break_minutes', 'is_billable'] as $key) {
                if ($row[$key] !== null) { $row[$key] = (int) $row[$key]; }
            }
        }
        unset($row);

        return $rows;
    }

    /**
     * Planned hours per person and project between two local dates (inclusive).
     *
     * @return list<array{user_id:int,user_name:string,project_id:int,project_name:string,seconds:int}>
     */
    public function scheduled(string $from, string $to, int $viewerId, bool $canViewAll, int $userId = 0, int $projectId = 0): array
    {
        $fromUtc = FormatHelper::toUtc($from . ' 00:00:00');
        $toUtc = FormatHelper::toUtc($to . ' 23:59:59');
        if ($fromUtc === null || $toUtc === null || !SchemaHelper::tableExists('schedules')) {
            return [];
        }

        $where = ['s.start_datetime >= :from_at', 's.start_datetime <= :to_at', "s.status <> 'Cancelled'"];
        $params = ['from_at' => $fromUtc, 'to_at' => $toUtc];
        if (!$canViewAll) {
            $where[] = 's.user_id = :viewer';
            $params['viewer'] = $viewerId;
        } elseif ($userId > 0) {
            $where[] = 's.user_id = :uid';
            $params['uid'] = $userId;
        }
        if ($projectId > 0) {
            $where[] = 's.project_id = :pid';
            $params['pid'] = $projectId;
        }

        $rows = Database::fetchAll(
            'SELECT s.user_id, u.name AS user_name, s.project_id, p.name AS project_name,
                    COALESCE(SUM(s.estimated_hours),0) AS hours
             FROM schedules s
             INNER JOIN users u ON u.id = s.user_id
             INNER JOIN projects p ON p.id = s.project_id
             WHERE ' . implode(' AND ', $where) . '
             GROUP BY s.user_id, u.name, s.project_id, p.name',
            $params
        );

        return array_map(static fn(array $r): array => [
            'user_id' => (int) $r['user_id'],
            'user_name' => (string) $r['user_name'],
            'project_id' => (int) $r['project_id'],
            'project_name' => (string) $r['project_name'],
            'seconds' => (int) round((float) $r['hours'] * 3600),
        ], $rows);
    }

    /** @return array{0:string,1:array<string,mixed>} */
    private function whereClause(array $filters, int $viewerId, string $viewerRole, bool $canViewAll, string $startCol): array
    {
        $where = ['1=1'];
        $params = [];
        $from = (string) ($filters['from'] ?? '');
        $to = (string) ($filters['to'] ?? '');

        if ($from !== '') {
            $utc = FormatHelper::toUtc($from . ' 00:00:00');
            if ($utc !== null) { $where[] = 'te.`' . $startCol . '` >= :from_at'; $params['from_at'] = $utc; }
        }
        if ($to !== '') {
            $utc = FormatHelper::toUtc($to . ' 23:59:59');
            if ($utc !== null) { $where[] = 'te.`' . $startCol . '` <= :to_at'; $params['to_at'] = $utc; }
        }

        if ($viewerRole === AuthHelper::ROLE_CLIENT) {
            [$clause, $scopeParams] = ClientScope::projectClause('p');
            $where[] = $clause;
            $params = array_merge($params, $scopeParams);
        } elseif (!$canViewAll) {
            $where[] = 'te.user_id = :viewer_user_id';
            $params['viewer_user_id'] = $viewerId;
        }

        if ($canViewAll) {
            $userId = (int) ($filters['user_id'] ?? 0);
            if ($userId > 0) { $where[] = 'te.user_id = :filter_user_id'; $params['filter_user_id'] = $userId; }
            $clientId = (int) ($filters['client_id'] ?? 0);
            if ($clientId > 0) { $where[] = 'c.id = :filter_client_id'; $params['filter_client_id'] = $clientId; }
        }

        $projectId = (int) ($filters['project_id'] ?? 0);
        if ($projectId > 0) { $where[] = 'te.project_id = :filter_project_id'; $params['filter_project_id'] = $projectId; }
        $taskId = (int) ($filters['task_id'] ?? 0);
        if ($taskId > 0) { $where[] = 'te.task_id = :filter_task_id'; $params['filter_task_id'] = $taskId; }

        $billable = (string) ($filters['billable'] ?? '');
        if ($billable === '1') { $where[] = 'te.is_billable = 1'; }
        elseif ($billable === '0') { $where[] = 'te.is_billable = 0'; }

        return [' WHERE ' . implode(' AND ', $where), $params];
    }

    /** @param list<array<string,mixed>> $rows */
    private function normalize(array $rows): array
    {
        return array_map(static function(array $row): array {
            foreach (['entry_count','seconds','billable_seconds','nonbillable_seconds','project_id','task_id','user_id','client_id'] as $key) {
                if (array_key_exists($key, $row) && $row[$key] !== null && is_numeric($row[$key])) $row[$key] = (int) $row[$key];
            }
            foreach (['billable_amount','billable_rate'] as $key) {
                if (array_key_exists($key, $row) && $row[$key] !== null) $row[$key] = (float) $row[$key];
            }
            return $row;
        }, $rows);
    }
}
