<?php
/**
 * GET /health : public liveness (ok / not ok only).
 * GET /admin/health : admin diagnostics (PHP, extensions, writable dirs, DB, schema).
 *
 * Integrity: a public probe must not fingerprint PHP, the database or debug
 * state, even when app.debug is on.
 */

declare(strict_types=1);

final class HealthController extends Controller
{
    public function __construct()
    {
        parent::__construct(false);
    }

    /** @param array<string, string> $params */
    public function index(Request $request, array $params): void
    {
        AuthHelper::releaseSession();

        $healthy = true;
        try {
            Database::fetchValue('SELECT 1');
        } catch (Throwable $e) {
            $healthy = false;
            LoggerHelper::exception($e);
        }

        $this->json(['ok' => $healthy, 'status' => $healthy ? 'ok' : 'not ok'], $healthy ? 200 : 503);
    }

    /** @param array<string, string> $params */
    public function admin(Request $request, array $params): void
    {
        if (!AuthHelper::check()) {
            throw new HttpException(401);
        }
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            throw new HttpException(403);
        }

        $requiredPhp = '8.2.0';
        $phpOk = version_compare(PHP_VERSION, $requiredPhp, '>=');

        $extensions = [
            'pdo'        => extension_loaded('pdo'),
            'pdo_mysql'  => extension_loaded('pdo_mysql'),
            'mbstring'   => extension_loaded('mbstring'),
            'json'       => extension_loaded('json'),
            'intl'       => extension_loaded('intl'),
        ];

        $paths = [
            'storage/sessions' => STORAGE_PATH . '/sessions',
            'storage/logs'     => STORAGE_PATH . '/logs',
            'public/uploads'   => PUBLIC_PATH . '/uploads',
        ];
        $writable = [];
        foreach ($paths as $label => $path) {
            $writable[$label] = is_dir($path) && is_writable($path);
        }

        $dbOk = false;
        $dbTime = null;
        $phpTime = gmdate('Y-m-d H:i:s');
        $driftSeconds = null;
        try {
            $dbTime = (string) Database::fetchValue('SELECT UTC_TIMESTAMP()');
            $dbOk = $dbTime !== '';
            if ($dbOk) {
                $driftSeconds = strtotime($dbTime . ' UTC') - strtotime($phpTime . ' UTC');
            }
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }

        $missing = [];
        if ($dbOk) {
            try {
                $missing = SchemaHelper::requiredMissing();
            } catch (Throwable $e) {
                LoggerHelper::exception($e);
                $missing = ['schema-check-failed'];
            }
        }

        // Desktop-agent pairing needs a real APP_KEY (config/config.php). Empty or placeholder = not ok.
        $appKeyOk = DesktopAgent::keyConfigured();
        $bindBrowser = (bool) Config::get('security.bind_session_to_browser', true);

        $allOk = $phpOk
            && $appKeyOk
            && $extensions['pdo']
            && $extensions['pdo_mysql']
            && $extensions['mbstring']
            && $extensions['json']
            && !in_array(false, $writable, true)
            && $dbOk
            && $missing === [];

        $payload = [
            'ok'               => $allOk,
            'php_version'      => PHP_VERSION,
            'php_required'     => $requiredPhp,
            'php_ok'           => $phpOk,
            'extensions'       => $extensions,
            'writable'         => $writable,
            'database_ok'      => $dbOk,
            'php_time_utc'     => $phpTime,
            'database_time_utc'=> $dbTime,
            'time_drift_seconds' => $driftSeconds,
            'schema_missing'   => $missing,
            'app_key_ok'       => $appKeyOk,
            'bind_session_to_browser' => $bindBrowser,
        ];

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json($payload, $allOk ? 200 : 503);
        }

        $this->render('settings/health', [
            'pageTitle' => 'Health',
            'health'    => $payload,
        ]);
    }
}
