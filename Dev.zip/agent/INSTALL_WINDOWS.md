# Install the TimeTrack Windows Agent

## Server first

1. Upload the TimeTrack project.
2. Run `database/UPGRADE_LIVE.sql` in the TimeTrack database (phpMyAdmin > Import).
3. Set `APP_KEY` in `config/config.php` (replace the `CHANGE_ME...` placeholder with a random 32+ character secret). Pairing codes are not issued without it.
4. Go to **Workspace → Features & policies**.
5. Turn on **Computer activity / idle detection**.
6. Set **Idle after** to `10` minutes.
7. Set **No response → pause** to `60` seconds.
8. Add a Hostinger cron job to run `tools/cron_auto_stop.php` every minute.

## Build on Windows

Install the .NET 8 SDK, open PowerShell in this `agent` folder, and run:

```powershell
.\build.ps1
```

The self-contained Windows executable is created in `agent\publish\TimeTrackAgent.exe`.

## Connect a PC

1. Run `TimeTrackAgent.exe`.
2. Right-click its tray icon and choose **Configure / Pair**.
3. Enter your HTTPS TimeTrack URL, for example:
   `https://akhoonzadaholdings.com/Dev/public`
4. In TimeTrack, open **Desktop Agent**.
5. Click **Generate pairing code**.
6. Enter the displayed 8-digit code into the agent.
7. The agent connects and adds itself to Windows startup for that user.

## Test

Start a TimeTrack timer and use another application such as AutoCAD or Excel. The timer should continue because Windows input activity is being detected.

Then stop using the computer for 10 minutes. TimeTrack should display **Are you still on?**. Click **Yes, I’m still working** to continue. If you do nothing for the configured warning period, the timer becomes **Paused**, never **Stopped**.
